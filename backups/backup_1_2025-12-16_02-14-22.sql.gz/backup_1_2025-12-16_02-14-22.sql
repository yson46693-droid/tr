-- Backup created by db_backup.php
-- Database: 1
-- Generated: 2025-12-16 02:14:22 (Africa/Cairo)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------------
-- Table structure for table `accountant_transactions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `accountant_transactions`;
CREATE TABLE `accountant_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_type` enum('collection_from_sales_rep','expense','income','transfer','payment','other') NOT NULL COMMENT 'نوع المعاملة',
  `amount` decimal(15,2) NOT NULL COMMENT 'المبلغ',
  `sales_rep_id` int(11) DEFAULT NULL COMMENT 'معرف المندوب (للتحصيل)',
  `description` text NOT NULL COMMENT 'الوصف',
  `reference_number` varchar(50) DEFAULT NULL COMMENT 'رقم مرجعي',
  `payment_method` enum('cash','bank_transfer','check','other') DEFAULT 'cash' COMMENT 'طريقة الدفع',
  `status` enum('pending','approved','rejected') DEFAULT 'approved' COMMENT 'الحالة',
  `approved_by` int(11) DEFAULT NULL COMMENT 'من وافق',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT 'تاريخ الموافقة',
  `notes` text DEFAULT NULL COMMENT 'ملاحظات إضافية',
  `created_by` int(11) NOT NULL COMMENT 'من أنشأ السجل',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'تاريخ الإنشاء',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp() COMMENT 'تاريخ التحديث',
  PRIMARY KEY (`id`),
  KEY `transaction_type` (`transaction_type`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  KEY `created_at` (`created_at`),
  KEY `reference_number` (`reference_number`),
  CONSTRAINT `accountant_transactions_ibfk_1` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `accountant_transactions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accountant_transactions_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول المعاملات المحاسبية';

LOCK TABLES `accountant_transactions` WRITE;
/*!40000 ALTER TABLE `accountant_transactions` DISABLE KEYS */;
INSERT INTO `accountant_transactions` (`id`, `transaction_type`, `amount`, `sales_rep_id`, `description`, `reference_number`, `payment_method`, `status`, `approved_by`, `approved_at`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'collection_from_sales_rep', '10000.00', '10', 'تحصيل من مندوب: مبيعات1', 'COL-REP-10-20251209034138', 'cash', 'approved', '1', '2025-12-08 17:41:38', NULL, '1', '2025-12-08 17:41:38', NULL),
('2', 'expense', '300.00', NULL, 'تسوية راتب موظف: المحاسب الأول (الراتب #6 - 0/2025)', 'SAL-SETTLE-6-20251209034216', 'cash', 'approved', '1', '2025-12-08 17:42:16', NULL, '1', '2025-12-08 17:42:16', NULL),
('3', 'expense', '100.00', NULL, 'سلفة موظف: المحاسب الأول (السلفة #2)', 'ADV-2-20251209034254', 'cash', 'approved', '1', '2025-12-08 17:42:54', NULL, '1', '2025-12-08 17:42:54', NULL),
('4', 'expense', '500.00', NULL, 'سلفة موظف: انتاج 2 (السلفة #3)', 'ADV-3-20251209100754', 'cash', 'approved', '1', '2025-12-09 00:07:54', NULL, '1', '2025-12-09 00:07:54', NULL),
('5', 'expense', '500.00', NULL, 'تسوية راتب موظف: مبيعات 2 (تسوية #8 - راتب #116)', 'SAL-SETTLE-8-20251210041307', 'cash', 'approved', '1', '2025-12-09 18:13:07', NULL, '1', '2025-12-09 18:13:07', NULL),
('6', '', '500.00', NULL, 'تسوية راتب موظف: انتاج 3 (تسوية #9 - راتب #119)', 'SAL-SETTLE-9-20251210041725', 'cash', 'approved', '1', '2025-12-09 18:17:25', NULL, '1', '2025-12-09 18:17:25', NULL),
('7', 'payment', '100.00', NULL, 'تسوية راتب موظف: انتاج 2 (تسوية #10 - راتب #118)', 'SAL-SETTLE-10-20251210043403', 'cash', 'approved', '1', '2025-12-09 18:34:03', NULL, '1', '2025-12-09 18:34:03', NULL),
('8', 'payment', '100.00', NULL, 'تسوية راتب موظف: انتاج 2 (تسوية #11 - راتب #118)', 'SAL-SETTLE-11-20251210050151', 'cash', 'approved', '1', '2025-12-09 19:01:51', NULL, '1', '2025-12-09 19:01:51', NULL),
('9', 'expense', '100.00', NULL, 'سلفة موظف: عامل الإنتاج الأول (السلفة #4)', 'ADV-4-20251210050256', 'cash', 'approved', '1', '2025-12-09 19:02:56', NULL, '1', '2025-12-09 19:02:56', NULL),
('10', 'payment', '100.00', NULL, 'تسوية راتب - سلفة موظف: عامل الإنتاج الأول (السلفة #5)', 'ADV-5-20251210051246', 'cash', 'approved', '1', '2025-12-09 19:12:46', NULL, '1', '2025-12-09 19:12:46', NULL),
('11', 'payment', '50.00', NULL, 'تسوية راتب - سلفة موظف: عامل الإنتاج الأول (السلفة #6)', 'ADV-6-20251210051332', 'cash', 'approved', '1', '2025-12-09 19:13:32', NULL, '1', '2025-12-09 19:13:32', NULL),
('12', 'payment', '500.00', NULL, 'تسوية راتب موظف: مبيعات 2 (تسوية #12 - راتب #116)', 'SAL-SETTLE-12-20251210060225', 'cash', 'approved', '1', '2025-12-09 20:02:25', NULL, '1', '2025-12-09 20:02:25', NULL),
('13', 'payment', '10.00', NULL, 'تسوية راتب - سلفة موظف: مبيعات 2 (السلفة #7)', 'ADV-7-20251210063850', 'cash', 'approved', '1', '2025-12-09 20:38:50', NULL, '1', '2025-12-09 20:38:50', NULL),
('14', 'payment', '20.00', NULL, 'تسوية راتب موظف: مبيعات 2 (تسوية #13 - راتب #116)', 'SAL-SETTLE-13-20251210063937', 'cash', 'approved', '1', '2025-12-09 20:39:37', NULL, '1', '2025-12-09 20:39:37', NULL),
('15', 'payment', '20.00', NULL, 'تسوية راتب موظف: مبيعات 2 (تسوية #14 - راتب #116)', 'SAL-SETTLE-14-20251210065137', 'cash', 'approved', '1', '2025-12-09 20:51:37', NULL, '1', '2025-12-09 20:51:37', NULL),
('16', 'payment', '100.00', NULL, 'تسوية راتب موظف: مبيعات1 (تسوية #15 - راتب #117)', 'SAL-SETTLE-15-20251210072902', 'cash', 'approved', '1', '2025-12-09 21:29:02', NULL, '1', '2025-12-09 21:29:02', NULL),
('17', 'expense', '1000.00', NULL, 'تسوية رصيد دائن لعميل مندوب: 2', 'CUST-CREDIT-SETTLE-REP-5-20251210094515', 'cash', 'approved', '1', '2025-12-09 23:45:15', NULL, '1', '2025-12-09 23:45:15', NULL),
('18', 'income', '1000.00', NULL, 'بيع كامل من نقطة بيع المدير - فاتورة INV-202512-0018 - عميل: 1', 'POS-FULL-18', 'cash', 'approved', '1', '2025-12-09 23:47:36', NULL, '1', '2025-12-09 23:47:36', NULL),
('19', 'income', '500.00', '10', 'تحصيل من عميل: 1 (مندوب: مبيعات1)', 'COL-CUST-4-20251210095046', 'cash', 'approved', '1', '2025-12-09 23:50:46', 'تحصيل من قبل المدير العام - لا يتم احتساب نسبة للمندوب', '1', '2025-12-09 23:50:46', NULL),
('20', 'income', '500.00', NULL, 'تحصيل جزئي من نقطة بيع المدير - فاتورة INV-202512-0022 - عميل: 3', 'POS-PARTIAL-22', 'cash', 'approved', '1', '2025-12-09 23:56:21', NULL, '1', '2025-12-09 23:56:21', NULL),
('21', 'expense', '1000.00', NULL, 'تسوية رصيد دائن لعميل مندوب: 3', 'CUST-CREDIT-SETTLE-REP-6-20251210095811', 'cash', 'approved', '1', '2025-12-09 23:58:11', NULL, '1', '2025-12-09 23:58:11', NULL),
('22', 'expense', '500.00', NULL, 'تسوية رصيد دائن لعميل مندوب: 4', 'CUST-CREDIT-SETTLE-REP-7-20251210095914', 'cash', 'approved', '1', '2025-12-09 23:59:14', NULL, '1', '2025-12-09 23:59:14', NULL),
('23', 'income', '1000.00', NULL, 'تحصيل من عميل محلي: 2', 'LOC-COL-202512-0001', 'cash', 'approved', '1', '2025-12-10 00:18:37', NULL, '1', '2025-12-10 00:18:37', NULL),
('24', 'income', '500.00', NULL, 'تحصيل جزئي من نقطة بيع المدير - فاتورة INV-202512-0024 - عميل: 3', 'POS-PARTIAL-24', 'cash', 'approved', '1', '2025-12-10 00:25:40', NULL, '1', '2025-12-10 00:25:40', NULL),
('25', 'income', '500.00', '10', 'تحصيل من عميل: 1 (مندوب: مبيعات1)', 'COL-CUST-4-20251210114847', 'cash', 'approved', '1', '2025-12-10 01:48:47', 'تحصيل من قبل المدير العام - لا يتم احتساب نسبة للمندوب', '1', '2025-12-10 01:48:47', NULL),
('26', 'expense', '500.00', NULL, 'تسوية رصيد دائن لعميل مندوب: 4', 'CUST-CREDIT-SETTLE-REP-7-20251210150036', 'cash', 'approved', '1', '2025-12-10 05:00:36', NULL, '1', '2025-12-10 05:00:36', NULL),
('27', 'collection_from_sales_rep', '1500.00', '18', 'تحصيل من مندوب: 3', 'COL-REP-18-20251210150210', 'cash', 'approved', '1', '2025-12-10 05:02:10', NULL, '1', '2025-12-10 05:02:10', NULL),
('28', 'income', '500.00', '10', 'تحصيل من عميل: مايكل (مندوب: مبيعات1)', 'COL-CUST-14-20251210163946', 'cash', 'approved', '2', '2025-12-10 06:39:46', 'تحصيل من قبل المحاسب الأول - لا يتم احتساب نسبة للمندوب', '2', '2025-12-10 06:39:46', NULL),
('29', 'income', '150.00', NULL, 'تحصيل جزئي من نقطة بيع المدير - فاتورة INV-202512-0029 - عميل: 12', 'POS-PARTIAL-29', 'cash', 'approved', '1', '2025-12-10 06:57:04', NULL, '1', '2025-12-10 06:57:04', NULL),
('30', 'expense', '1000.00', NULL, 'تسوية رصيد دائن لعميل محلي: عمر', 'CUST-CREDIT-SETTLE-LOCAL-4-20251210170408', 'cash', 'approved', '1', '2025-12-10 07:04:08', NULL, '1', '2025-12-10 07:04:08', NULL),
('31', 'expense', '1000.00', NULL, 'تسوية رصيد دائن لعميل مندوب: 2', 'CUST-CREDIT-SETTLE-REP-5-20251210170448', 'cash', 'approved', '1', '2025-12-10 07:04:48', NULL, '1', '2025-12-10 07:04:48', NULL),
('32', 'collection_from_sales_rep', '2000.00', '17', 'تحصيل من مندوب: مبيعات 2', 'COL-REP-17-20251210170812', 'cash', 'approved', '2', '2025-12-10 07:08:13', NULL, '2', '2025-12-10 07:08:13', NULL),
('33', 'income', '100.00', '10', 'تحصيل من عميل: مايكل (مندوب: مبيعات1)', 'COL-CUST-14-20251211104840', 'cash', 'approved', '1', '2025-12-11 00:48:40', 'تحصيل من قبل المدير العام - لا يتم احتساب نسبة للمندوب', '1', '2025-12-11 00:48:40', NULL),
('34', 'income', '32000.00', NULL, 'بيع كامل من نقطة بيع المدير - فاتورة INV-202512-0032 - عميل: 1', 'POS-FULL-32', 'cash', 'approved', '1', '2025-12-11 02:37:47', NULL, '1', '2025-12-11 02:37:47', NULL),
('35', 'income', '100.00', '18', 'تحصيل من عميل: 1 (مندوب: 3)', 'COL-CUST-13-20251211130944', 'cash', 'approved', '1', '2025-12-11 03:09:43', 'تحصيل من قبل المدير العام - لا يتم احتساب نسبة للمندوب', '1', '2025-12-11 03:09:43', NULL),
('36', 'income', '1000.00', NULL, 'تحصيل من عميل محلي: احمد', 'LOC-COL-202512-0002', 'cash', 'approved', '2', '2025-12-11 05:55:23', NULL, '2', '2025-12-11 05:55:23', NULL);
/*!40000 ALTER TABLE `accountant_transactions` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `advance_requests`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `advance_requests`;
CREATE TABLE `advance_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `requested_month` int(2) NOT NULL,
  `requested_year` int(4) NOT NULL,
  `salary_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `salary_id` (`salary_id`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  KEY `requested_month_year` (`requested_month`,`requested_year`),
  CONSTRAINT `advance_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `advance_requests_ibfk_2` FOREIGN KEY (`salary_id`) REFERENCES `salaries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `advance_requests_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `advance_requests`

-- --------------------------------------------------------
-- Table structure for table `approvals`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `approvals`;
CREATE TABLE `approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('financial','sales','production','inventory','other','return_request','collection','salary','warehouse_transfer','exchange_request','invoice_return_company','salary_modification') NOT NULL,
  `reference_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approval_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`reference_id`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `approvals_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `approvals` WRITE;
/*!40000 ALTER TABLE `approvals` DISABLE KEYS */;
INSERT INTO `approvals` (`id`, `type`, `reference_id`, `status`, `requested_by`, `approved_by`, `approval_notes`, `created_at`, `approved_at`) VALUES
('1', 'warehouse_transfer', '1', 'approved', '4', '1', 'الموافقة على طلب نقل المنتجات.', '2025-12-09 19:39:35', NULL),
('2', 'return_request', '1', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-09 22:32:44', NULL),
('3', 'return_request', '2', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-09 22:34:03', NULL),
('4', 'return_request', '3', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-09 23:06:31', NULL),
('5', 'return_request', '4', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-09 23:15:34', NULL),
('6', 'return_request', '5', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-09 23:18:17', NULL),
('7', 'return_request', '6', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-09 23:23:46', NULL),
('8', 'return_request', '7', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-10 00:24:17', NULL),
('9', 'return_request', '8', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-10 00:34:57', NULL),
('10', 'return_request', '9', 'approved', '10', '1', 'تمت الموافقة على طلب المرتجع', '2025-12-10 00:38:12', NULL),
('11', 'financial', '6', 'approved', '2', '1', 'مصروف سريع\nالمبلغ: 100.00 ج.م ج.م\nالوصف: مكنسه\nالرقم المرجعي: REF-946512', '2025-12-10 07:06:18', NULL),
('12', 'warehouse_transfer', '20', 'approved', '4', '1', 'الموافقة على طلب نقل المنتجات.', '2025-12-11 08:22:14', NULL),
('13', 'warehouse_transfer', '21', 'approved', '4', '1', 'طلب نقل رقم: TRF-202512-0021\n', '2025-12-15 02:49:12', NULL),
('14', 'warehouse_transfer', '23', 'approved', '4', '1', 'طلب نقل رقم: TRF-202512-0023\n', '2025-12-15 03:00:30', '2025-12-15 03:38:53');
/*!40000 ALTER TABLE `approvals` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `attendance`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `status` enum('present','absent','late','half_day') DEFAULT 'present',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_date` (`user_id`,`date`),
  KEY `date` (`date`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `attendance`

-- --------------------------------------------------------
-- Table structure for table `attendance_event_notification_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `attendance_event_notification_logs`;
CREATE TABLE `attendance_event_notification_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `attendance_record_id` int(11) DEFAULT NULL,
  `event_type` enum('checkin','checkout') NOT NULL,
  `sent_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_event_date` (`user_id`,`event_type`,`sent_date`),
  KEY `attendance_record_idx` (`attendance_record_id`),
  CONSTRAINT `attendance_event_log_record_fk` FOREIGN KEY (`attendance_record_id`) REFERENCES `attendance_records` (`id`) ON DELETE SET NULL,
  CONSTRAINT `attendance_event_log_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `attendance_event_notification_logs` WRITE;
/*!40000 ALTER TABLE `attendance_event_notification_logs` DISABLE KEYS */;
INSERT INTO `attendance_event_notification_logs` (`id`, `user_id`, `attendance_record_id`, `event_type`, `sent_date`, `created_at`, `updated_at`) VALUES
('1', '10', '1', 'checkin', '2025-12-09', '2025-12-08 17:31:47', NULL),
('2', '4', '1', 'checkin', '2025-12-09', '2025-12-08 17:32:11', '2025-12-08 21:48:35'),
('3', '2', '3', 'checkin', '2025-12-09', '2025-12-08 17:32:13', NULL),
('4', '4', '1', 'checkout', '2025-12-09', '2025-12-08 17:35:30', '2025-12-08 21:49:21'),
('5', '10', '1', 'checkout', '2025-12-09', '2025-12-08 17:35:42', NULL),
('6', '2', '3', 'checkout', '2025-12-09', '2025-12-08 17:35:48', NULL),
('11', '11', '4', 'checkin', '2025-12-09', '2025-12-09 00:15:16', '2025-12-09 00:21:01'),
('12', '11', '4', 'checkout', '2025-12-09', '2025-12-09 00:19:27', '2025-12-09 00:21:30'),
('17', '4', '5', 'checkin', '2025-12-10', '2025-12-09 19:34:41', NULL),
('18', '10', '9', 'checkin', '2025-12-10', '2025-12-09 21:25:08', '2025-12-10 06:16:43'),
('19', '10', '8', 'checkout', '2025-12-10', '2025-12-09 21:25:45', '2025-12-09 21:27:38'),
('25', '2', '10', 'checkin', '2025-12-11', '2025-12-10 22:16:57', NULL),
('26', '4', '12', 'checkin', '2025-12-11', '2025-12-11 00:08:54', '2025-12-11 07:13:14'),
('27', '4', '12', 'checkout', '2025-12-11', '2025-12-11 07:05:02', '2025-12-11 08:27:09'),
('29', '11', '13', 'checkin', '2025-12-11', '2025-12-11 07:17:05', NULL),
('30', '16', '14', 'checkin', '2025-12-11', '2025-12-11 07:23:01', NULL),
('32', '4', '15', 'checkin', '2025-12-14', '2025-12-14 15:23:51', NULL),
('33', '4', '17', 'checkin', '2025-12-15', '2025-12-15 18:13:22', '2025-12-15 18:17:28'),
('35', '4', '17', 'checkout', '2025-12-15', '2025-12-15 18:18:24', NULL);
/*!40000 ALTER TABLE `attendance_event_notification_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `attendance_monthly_report_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `attendance_monthly_report_logs`;
CREATE TABLE `attendance_monthly_report_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_key` char(7) NOT NULL COMMENT 'YYYY-MM',
  `month_number` tinyint(2) NOT NULL,
  `year_number` smallint(4) NOT NULL,
  `sent_via` varchar(32) NOT NULL COMMENT 'telegram_auto, telegram_manual, manual_export, ...',
  `triggered_by` int(11) DEFAULT NULL COMMENT 'المستخدم الذي أنشأ التقرير يدوياً (إن وجد)',
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `report_snapshot` longtext DEFAULT NULL COMMENT 'نسخة JSON من التقرير',
  PRIMARY KEY (`id`),
  KEY `month_key_idx` (`month_key`),
  KEY `sent_via_idx` (`sent_via`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `attendance_monthly_report_logs`

-- --------------------------------------------------------
-- Table structure for table `attendance_notification_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `attendance_notification_logs`;
CREATE TABLE `attendance_notification_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notification_kind` enum('checkin','checkout') NOT NULL,
  `sent_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_kind_date` (`user_id`,`notification_kind`,`sent_date`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `attendance_notification_logs` WRITE;
/*!40000 ALTER TABLE `attendance_notification_logs` DISABLE KEYS */;
INSERT INTO `attendance_notification_logs` (`id`, `user_id`, `notification_kind`, `sent_date`, `created_at`) VALUES
('1', '11', 'checkin', '2025-12-09', '2025-12-09 00:03:18'),
('2', '18', 'checkin', '2025-12-10', '2025-12-10 00:43:27'),
('3', '2', 'checkin', '2025-12-10', '2025-12-10 01:49:57'),
('4', '19', 'checkin', '2025-12-10', '2025-12-10 02:05:27'),
('5', '4', 'checkin', '2025-12-11', '2025-12-11 00:08:41'),
('6', '10', 'checkin', '2025-12-11', '2025-12-11 00:25:06'),
('7', '11', 'checkin', '2025-12-11', '2025-12-11 07:15:07'),
('8', '16', 'checkin', '2025-12-11', '2025-12-11 07:20:46'),
('9', '11', 'checkin', '2025-12-12', '2025-12-12 02:11:05'),
('10', '4', 'checkin', '2025-12-14', '2025-12-14 12:51:47'),
('11', '11', 'checkin', '2025-12-14', '2025-12-14 12:56:09'),
('12', '16', 'checkin', '2025-12-14', '2025-12-14 12:58:11');
/*!40000 ALTER TABLE `attendance_notification_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `attendance_records`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `attendance_records`;
CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in_time` datetime NOT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `delay_minutes` int(11) DEFAULT 0,
  `work_hours` decimal(5,2) DEFAULT 0.00,
  `photo_path` varchar(255) DEFAULT NULL,
  `checkout_photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`),
  KEY `user_date` (`user_id`,`date`),
  KEY `check_in_time` (`check_in_time`),
  CONSTRAINT `attendance_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `attendance_records` WRITE;
/*!40000 ALTER TABLE `attendance_records` DISABLE KEYS */;
INSERT INTO `attendance_records` (`id`, `user_id`, `date`, `check_in_time`, `check_out_time`, `delay_minutes`, `work_hours`, `photo_path`, `checkout_photo_path`, `created_at`, `updated_at`) VALUES
('1', '4', '2025-12-09', '2025-12-08 07:48:35', '2025-12-09 07:49:20', '0', '24.01', 'deleted_after_send', 'deleted_after_send', '2025-12-08 21:48:35', '2025-12-08 21:49:21'),
('2', '11', '2025-12-09', '2025-12-08 10:15:16', '2025-12-09 10:19:26', '75', '24.07', 'deleted_after_send', 'deleted_after_send', '2025-12-09 00:15:16', '2025-12-09 00:19:27'),
('3', '11', '2025-12-09', '2025-12-09 10:20:32', '2025-12-09 10:20:40', '81', '0.00', 'deleted_after_send', 'deleted_after_send', '2025-12-09 00:20:32', '2025-12-09 00:20:41'),
('4', '11', '2025-12-09', '2025-12-01 10:21:00', '2025-12-09 10:21:29', '81', '192.01', 'deleted_after_send', 'deleted_after_send', '2025-12-09 00:21:00', '2025-12-09 00:21:30'),
('5', '4', '2025-12-10', '2025-12-10 05:34:41', NULL, '0', '0.00', 'deleted_after_send', NULL, '2025-12-09 19:34:41', '2025-12-09 19:34:41'),
('6', '10', '2025-12-10', '2025-12-07 07:25:08', '2025-12-10 07:25:44', '0', '24.01', 'deleted_after_send', 'deleted_after_send', '2025-12-09 21:25:08', '2025-12-09 21:26:18'),
('7', '10', '2025-12-10', '2025-12-10 07:26:34', '2025-12-10 07:26:43', '0', '0.00', 'deleted_after_send', 'deleted_after_send', '2025-12-09 21:26:34', '2025-12-09 21:26:43'),
('8', '10', '2025-12-10', '2025-12-09 07:27:03', '2025-12-10 07:27:38', '0', '24.01', 'deleted_after_send', 'deleted_after_send', '2025-12-09 21:27:03', '2025-12-09 21:27:38'),
('9', '10', '2025-12-10', '2025-12-10 16:16:43', NULL, '377', '0.00', 'deleted_after_send', NULL, '2025-12-10 06:16:43', '2025-12-10 06:16:43'),
('10', '2', '2025-12-11', '2025-12-11 08:16:57', NULL, '0', '0.00', 'deleted_after_send', NULL, '2025-12-10 22:16:57', '2025-12-10 22:16:57'),
('11', '4', '2025-12-11', '2025-12-11 10:08:53', '2025-12-11 17:05:01', '69', '6.94', 'deleted_after_send', 'deleted_after_send', '2025-12-11 00:08:53', '2025-12-11 07:05:02'),
('12', '4', '2025-12-11', '2025-12-11 17:13:13', '2025-12-11 18:27:06', '493', '1.23', 'deleted_after_send', 'deleted_after_send', '2025-12-11 07:13:13', '2025-12-11 08:27:09'),
('13', '11', '2025-12-11', '2025-12-11 17:17:04', NULL, '497', '0.00', 'deleted_after_send', NULL, '2025-12-11 07:17:04', '2025-12-11 07:17:05'),
('14', '16', '2025-12-11', '2025-12-11 17:23:01', NULL, '503', '0.00', 'deleted_after_send', NULL, '2025-12-11 07:23:01', '2025-12-11 07:23:01'),
('15', '4', '2025-12-15', '2025-12-15 15:23:50', '2025-12-15 23:10:56', '384', '0.00', 'deleted_after_send', NULL, '2025-12-14 15:23:50', '2025-12-15 18:12:04'),
('16', '4', '2025-12-15', '2025-12-15 01:13:21', NULL, '553', '0.00', 'deleted_after_send', NULL, '2025-12-15 18:13:21', '2025-12-15 18:13:55'),
('17', '4', '2025-12-15', '2025-12-15 03:17:26', '2025-12-15 18:18:23', '557', '0.02', 'deleted_after_send', 'deleted_after_send', '2025-12-15 18:17:26', '2025-12-15 18:19:30');
/*!40000 ALTER TABLE `attendance_records` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `audit_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `old_data` text DEFAULT NULL,
  `new_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `entity_type` (`entity_type`,`entity_id`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `old_value`, `new_value`, `old_data`, `new_data`, `ip_address`, `user_agent`, `created_at`) VALUES
('1', '1', 'delete', 'product_template', '11', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:02:18'),
('2', '1', 'delete', 'product_template', '10', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:02:27'),
('3', '1', 'delete', 'product_template', '9', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:02:32'),
('4', '1', 'create', 'product_template', '12', NULL, '{\"product_name\":\"1\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:03:39'),
('5', '4', 'create_from_template', 'production', '27', NULL, '{\"template_id\":12,\"quantity\":12,\"batch_number\":\"251215-836983\",\"honey_supplier_id\":2,\"packaging_supplier_id\":4}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-15 18:04:54'),
('6', '4', 'add_packaging_quantity', 'packaging_materials', '1', '{\"quantity_before\":987}', '{\"quantity_after\":1000,\"added_quantity\":13}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-15 18:06:50'),
('7', '1', 'create', 'product_template', '13', NULL, '{\"product_name\":\"2\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:07:30'),
('8', '4', 'create_from_template', 'production', '28', NULL, '{\"template_id\":13,\"quantity\":1,\"batch_number\":\"251215-539325\",\"honey_supplier_id\":1,\"packaging_supplier_id\":4}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-15 18:08:03'),
('9', '4', 'create_from_template', 'production', '29', NULL, '{\"template_id\":13,\"quantity\":2,\"batch_number\":\"251215-241987\",\"honey_supplier_id\":1,\"packaging_supplier_id\":4}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-15 18:08:15'),
('10', '1', 'logout', 'user', '1', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:12:41'),
('11', '4', 'logout', 'user', '4', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-15 18:12:48'),
('12', '4', 'login', 'user', '4', NULL, '{\"method\":\"password\",\"remember_me\":\"no\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:12:54'),
('13', '4', 'check_in', 'attendance', '16', NULL, '{\"delay_minutes\":553}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:13:22'),
('14', '4', 'check_in', 'attendance', '17', NULL, '{\"delay_minutes\":557}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:17:28'),
('15', '4', 'check_out', 'attendance', NULL, NULL, '{\"work_hours\":0.02}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:18:24'),
('16', '4', 'logout', 'user', '4', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:28:57'),
('17', '1', 'login', 'user', '1', NULL, '{\"method\":\"password\",\"remember_me\":\"no\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-15 18:29:02'),
('18', '2', 'login', 'user', '2', NULL, '{\"method\":\"password\",\"remember_me\":\"no\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:03:44'),
('19', '1', 'logout', 'user', '1', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:04:16'),
('20', '1', 'login', 'user', '1', NULL, '{\"method\":\"password\",\"remember_me\":\"no\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:04:24'),
('21', '1', 'logout', 'user', '1', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:31'),
('22', '2', 'logout', 'user', '2', NULL, NULL, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:56'),
('23', '2', 'login', 'user', '2', NULL, '{\"method\":\"password\",\"remember_me\":\"no\"}', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:06');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `auto_salary_init_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `auto_salary_init_logs`;
CREATE TABLE `auto_salary_init_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `status` enum('executed','skipped','error') NOT NULL DEFAULT 'skipped',
  `reason` varchar(255) DEFAULT NULL,
  `created_count` int(11) DEFAULT 0,
  `skipped_count` int(11) DEFAULT 0,
  `error_count` int(11) DEFAULT 0,
  `month` int(2) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `request_uri` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `call_time` (`call_time`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `month_year` (`month`,`year`),
  KEY `status_date` (`status`,`call_time`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `auto_salary_init_logs` WRITE;
/*!40000 ALTER TABLE `auto_salary_init_logs` DISABLE KEYS */;
INSERT INTO `auto_salary_init_logs` (`id`, `call_time`, `user_id`, `status`, `reason`, `created_count`, `skipped_count`, `error_count`, `month`, `year`, `ip_address`, `request_uri`) VALUES
('271', '2025-12-09 17:22:45', '1', 'executed', 'Already initialized this session', '0', '0', '0', '12', '2025', '154.239.18.244', '/v1/dashboard/manager.php?page=local_customers');
/*!40000 ALTER TABLE `auto_salary_init_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `backups`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` bigint(20) DEFAULT 0,
  `backup_type` enum('full','incremental','manual') DEFAULT 'full',
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `backups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
INSERT INTO `backups` (`id`, `filename`, `file_path`, `file_size`, `backup_type`, `status`, `created_by`, `created_at`) VALUES
('23', 'backup_1_2025-12-15_18-12-31.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-15_18-12-31.sql.gz', '59593', '', 'completed', NULL, '2025-12-15 18:12:32'),
('24', 'backup_1_2025-12-15_18-22-48.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-15_18-22-48.sql.gz', '59668', '', 'completed', NULL, '2025-12-15 18:22:49'),
('25', 'backup_1_2025-12-16_01-03-33.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_01-03-33.sql.gz', '59976', '', 'completed', NULL, '2025-12-16 01:03:34'),
('26', 'backup_1_2025-12-16_01-13-40.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_01-13-40.sql.gz', '60108', '', 'completed', NULL, '2025-12-16 01:13:41'),
('27', 'backup_1_2025-12-16_01-23-40.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_01-23-40.sql.gz', '60118', '', 'completed', NULL, '2025-12-16 01:23:41'),
('28', 'backup_1_2025-12-16_01-33-58.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_01-33-58.sql.gz', '60142', '', 'completed', NULL, '2025-12-16 01:33:59'),
('29', 'backup_1_2025-12-16_01-44-03.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_01-44-03.sql.gz', '60143', '', 'completed', NULL, '2025-12-16 01:44:04'),
('30', 'backup_1_2025-12-16_01-54-21.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_01-54-21.sql.gz', '60071', '', 'completed', NULL, '2025-12-16 01:54:22'),
('31', 'backup_1_2025-12-16_02-04-22.sql.gz', 'C:\\xampp\\htdocs\\v1/backups\\backup_1_2025-12-16_02-04-22.sql.gz', '60075', '', 'completed', NULL, '2025-12-16 02:04:23');
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `barcode_scans`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `barcode_scans`;
CREATE TABLE `barcode_scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number_id` int(11) NOT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `scan_location` varchar(255) DEFAULT NULL,
  `scan_type` enum('in','out','verification','sale','return') DEFAULT 'verification',
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_number_id` (`batch_number_id`),
  KEY `scanned_by` (`scanned_by`),
  KEY `scan_type` (`scan_type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `barcode_scans_ibfk_1` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `barcode_scans_ibfk_2` FOREIGN KEY (`scanned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `barcode_scans`

-- --------------------------------------------------------
-- Table structure for table `batch_numbers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `batch_numbers`;
CREATE TABLE `batch_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `production_id` int(11) DEFAULT NULL,
  `production_date` date NOT NULL,
  `honey_supplier_id` int(11) DEFAULT NULL,
  `honey_variety` varchar(50) DEFAULT NULL COMMENT 'نوع العسل المستخدم',
  `packaging_materials` text DEFAULT NULL COMMENT 'JSON array of packaging material IDs',
  `packaging_supplier_id` int(11) DEFAULT NULL,
  `all_suppliers` text DEFAULT NULL COMMENT 'JSON array of all suppliers with their materials',
  `workers` text DEFAULT NULL COMMENT 'JSON array of worker IDs',
  `quantity` int(11) NOT NULL DEFAULT 1,
  `status` enum('in_production','completed','in_stock','sold','expired') DEFAULT 'in_production',
  `expiry_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_number` (`batch_number`),
  KEY `product_id` (`product_id`),
  KEY `production_id` (`production_id`),
  KEY `production_date` (`production_date`),
  KEY `honey_supplier_id` (`honey_supplier_id`),
  KEY `packaging_supplier_id` (`packaging_supplier_id`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `batch_numbers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `batch_numbers_ibfk_2` FOREIGN KEY (`production_id`) REFERENCES `production` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_3` FOREIGN KEY (`honey_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_4` FOREIGN KEY (`packaging_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `batch_numbers_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `batch_numbers` WRITE;
/*!40000 ALTER TABLE `batch_numbers` DISABLE KEYS */;
INSERT INTO `batch_numbers` (`id`, `batch_number`, `product_id`, `production_id`, `production_date`, `honey_supplier_id`, `honey_variety`, `packaging_materials`, `packaging_supplier_id`, `all_suppliers`, `workers`, `quantity`, `status`, `expiry_date`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', '251210-990828', '3', '1', '2025-12-10', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '50', 'completed', '2026-12-10', 'تم إنشاؤه من قالب: 1 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-09 19:35:03', NULL),
('2', '251210-921358', '4', '2', '2025-12-10', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '20', 'completed', '2026-12-10', 'تم إنشاؤه من قالب: TEST | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-09 19:56:25', NULL),
('3', '251211-069336', '12', '3', '2025-12-11', NULL, NULL, '[42]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"برطمان 370م بيضاوي\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: مخصص | الموردون: مورد ادوات تعبئه (برطمان 370م بيضاوي),  مورد زيت (زيت زيتون)', '4', '2025-12-11 00:32:13', NULL),
('4', '251211-995189', '12', '4', '2025-12-11', NULL, NULL, '[42]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"برطمان 370م بيضاوي\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: مخصص | الموردون: مورد ادوات تعبئه (برطمان 370م بيضاوي),  مورد زيت (زيت زيتون)', '4', '2025-12-11 00:41:53', NULL),
('5', '251211-531412', '12', '5', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: مخصص | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 00:43:46', NULL),
('6', '251211-945752', '13', '6', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: 11 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 01:17:40', NULL),
('7', '251211-219169', '13', '7', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: 11 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 01:34:30', NULL),
('8', '251211-072970', '15', '8', '2025-12-11', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: 12 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-11 02:19:41', NULL),
('9', '251211-461225', '4', '9', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: TEST | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 02:25:55', NULL),
('10', '251211-269689', '4', '10', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: TEST | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 02:27:17', NULL),
('11', '251211-460851', '4', '11', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: TEST | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 02:29:15', NULL),
('12', '251211-581612', '4', '12', '2025-12-11', NULL, NULL, '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":6,\"name\":\" مورد زيت\",\"type\":\"olive_oil\",\"material\":\"زيت زيتون\",\"honey_variety\":null}]', '[4]', '12', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: TEST | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م),  مورد زيت (زيت زيتون)', '4', '2025-12-11 02:30:09', NULL),
('13', '251211-590620', '15', '13', '2025-12-11', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '11', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: 12 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-11 02:31:58', NULL),
('14', '251211-966029', '15', '14', '2025-12-11', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '1', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: 12 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-11 02:51:48', NULL),
('15', '251211-923972', '20', '15', '2025-12-11', '2', '', '[42,38,2]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"برطمان 370م بيضاوي\"},{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"ملصق صغير\"},{\"id\":2,\"name\":\"عمرو \",\"type\":\"honey\",\"material\":\"عسل - سدر\",\"honey_variety\":null}]', '[16,11,4]', '18', 'completed', '2026-12-11', 'تم إنشاؤه من قالب: عسل ك سنبله | الموردون: مورد ادوات تعبئه (برطمان 370م بيضاوي), مورد ادوات تعبئه (ملصق صغير), عمرو  (عسل - سدر)', '4', '2025-12-11 07:55:29', NULL),
('16', '251214-424521', '30', '22', '2025-12-14', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-14', 'تم إنشاؤه من قالب: ك | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-14 15:47:16', NULL),
('17', '251215-093925', '30', '23', '2025-12-15', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: ك | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-15 01:11:48', NULL),
('18', '251215-613802', '30', '24', '2025-12-15', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: ك | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-15 01:26:51', NULL),
('19', '251215-082617', '30', '25', '2025-12-15', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: ك | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-15 01:34:44', NULL),
('20', '251215-135346', '30', '26', '2025-12-15', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '6', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: ك | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-15 01:51:59', NULL),
('21', '251215-836983', '3', '27', '2025-12-15', '2', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":2,\"name\":\"عمرو \",\"type\":\"honey\",\"material\":\"عسل - تيست\",\"honey_variety\":null}]', '[4]', '12', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: 1 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), عمرو  (عسل - تيست)', '4', '2025-12-15 18:04:54', NULL),
('22', '251215-539325', '32', '28', '2025-12-15', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '1', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: 2 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-15 18:08:03', NULL),
('23', '251215-241987', '32', '29', '2025-12-15', '1', '', '[17]', '4', '[{\"id\":4,\"name\":\"مورد ادوات تعبئه\",\"type\":\"packaging\",\"material\":\"أغطية - غطاء 43م\"},{\"id\":1,\"name\":\"مايكل \",\"type\":\"honey\",\"material\":\"عسل - عسل حلبه\",\"honey_variety\":null}]', '[4]', '2', 'completed', '2026-12-15', 'تم إنشاؤه من قالب: 2 | الموردون: مورد ادوات تعبئه (أغطية - غطاء 43م), مايكل  (عسل - عسل حلبه)', '4', '2025-12-15 18:08:15', NULL);
/*!40000 ALTER TABLE `batch_numbers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `batch_packaging`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `batch_packaging`;
CREATE TABLE `batch_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `packaging_material_id` int(11) DEFAULT NULL,
  `packaging_name` varchar(255) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `quantity_used` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `packaging_material_id` (`packaging_material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `batch_packaging` WRITE;
/*!40000 ALTER TABLE `batch_packaging` DISABLE KEYS */;
INSERT INTO `batch_packaging` (`id`, `batch_id`, `packaging_material_id`, `packaging_name`, `unit`, `supplier_id`, `quantity_used`, `created_at`) VALUES
('1', '1', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '50.000', '2025-12-09 19:35:03'),
('2', '2', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '20.000', '2025-12-09 19:56:25'),
('3', '3', '42', 'برطمان 370م بيضاوي', 'قطعة', '4', '11.000', '2025-12-11 00:32:13'),
('4', '4', '42', 'برطمان 370م بيضاوي', 'قطعة', '4', '11.000', '2025-12-11 00:41:53'),
('5', '5', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '11.000', '2025-12-11 00:43:46'),
('6', '6', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '11.000', '2025-12-11 01:17:40'),
('7', '7', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '11.000', '2025-12-11 01:34:30'),
('8', '8', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '11.000', '2025-12-11 02:19:41'),
('9', '9', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-11 02:25:55'),
('10', '10', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-11 02:27:17'),
('11', '11', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-11 02:29:15'),
('12', '12', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '12.000', '2025-12-11 02:30:09'),
('13', '13', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '11.000', '2025-12-11 02:31:58'),
('14', '14', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '1.000', '2025-12-11 02:51:48'),
('15', '15', '42', 'برطمان 370م بيضاوي', 'قطعة', '4', '18.000', '2025-12-11 07:55:29'),
('16', '15', '38', 'ملصق صغير', 'قطعة', '4', '18.000', '2025-12-11 07:55:29'),
('17', '16', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-14 15:47:16'),
('18', '17', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-15 01:11:48'),
('19', '18', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-15 01:26:51'),
('20', '19', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-15 01:34:44'),
('21', '20', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '6.000', '2025-12-15 01:51:59'),
('22', '21', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '12.000', '2025-12-15 18:04:54'),
('23', '22', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '1.000', '2025-12-15 18:08:03'),
('24', '23', '17', 'أغطية - غطاء 43م', 'قطعة', '4', '2.000', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `batch_packaging` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `batch_raw_materials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `batch_raw_materials`;
CREATE TABLE `batch_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `raw_material_id` int(11) DEFAULT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `quantity_used` decimal(12,3) NOT NULL DEFAULT 0.000,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `raw_material_id` (`raw_material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `batch_raw_materials` WRITE;
/*!40000 ALTER TABLE `batch_raw_materials` DISABLE KEYS */;
INSERT INTO `batch_raw_materials` (`id`, `batch_id`, `raw_material_id`, `material_name`, `unit`, `supplier_id`, `quantity_used`, `created_at`) VALUES
('1', '1', NULL, 'زيت زيتون', 'كيلوجرام', '6', '50.000', '2025-12-09 19:35:03'),
('2', '2', NULL, 'زيت زيتون', 'كيلوجرام', '6', '20.000', '2025-12-09 19:56:25'),
('3', '3', NULL, 'زيت زيتون', 'كيلوجرام', '6', '11.000', '2025-12-11 00:32:13'),
('4', '4', NULL, 'زيت زيتون', 'كيلوجرام', '6', '11.000', '2025-12-11 00:41:53'),
('5', '5', NULL, 'زيت زيتون', 'كيلوجرام', '6', '11.000', '2025-12-11 00:43:46'),
('6', '6', NULL, 'زيت زيتون', 'كيلوجرام', '6', '11.000', '2025-12-11 01:17:40'),
('7', '7', NULL, 'زيت زيتون', 'كيلوجرام', '6', '11.000', '2025-12-11 01:34:30'),
('8', '8', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '11.000', '2025-12-11 02:19:41'),
('9', '9', NULL, 'زيت زيتون', 'كيلوجرام', '6', '6.000', '2025-12-11 02:25:55'),
('10', '10', NULL, 'زيت زيتون', 'كيلوجرام', '6', '6.000', '2025-12-11 02:27:17'),
('11', '11', NULL, 'زيت زيتون', 'كيلوجرام', '6', '6.000', '2025-12-11 02:29:15'),
('12', '12', NULL, 'زيت زيتون', 'كيلوجرام', '6', '12.000', '2025-12-11 02:30:09'),
('13', '13', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '11.000', '2025-12-11 02:31:58'),
('14', '14', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '1.000', '2025-12-11 02:51:48'),
('15', '15', NULL, 'عسل - سدر', 'كيلوجرام', '2', '18.000', '2025-12-11 07:55:29'),
('16', '16', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '3.000', '2025-12-14 15:47:16'),
('17', '17', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '3.000', '2025-12-15 01:11:48'),
('18', '18', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '3.000', '2025-12-15 01:26:51'),
('19', '19', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '3.000', '2025-12-15 01:34:44'),
('20', '20', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '3.000', '2025-12-15 01:51:59'),
('21', '21', NULL, 'عسل - تيست', 'كيلوجرام', '2', '12.000', '2025-12-15 18:04:54'),
('22', '22', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '1.000', '2025-12-15 18:08:03'),
('23', '23', NULL, 'عسل - عسل حلبه', 'كيلوجرام', '1', '2.000', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `batch_raw_materials` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `batch_suppliers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `batch_suppliers`;
CREATE TABLE `batch_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(255) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `batch_suppliers` WRITE;
/*!40000 ALTER TABLE `batch_suppliers` DISABLE KEYS */;
INSERT INTO `batch_suppliers` (`id`, `batch_id`, `supplier_id`, `supplier_name`, `role`, `created_at`) VALUES
('1', '1', '6', 'زيت زيتون', 'raw_material', '2025-12-09 19:35:03'),
('2', '1', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-09 19:35:03'),
('3', '2', '6', 'زيت زيتون', 'raw_material', '2025-12-09 19:56:25'),
('4', '2', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-09 19:56:25'),
('5', '3', '6', 'زيت زيتون', 'raw_material', '2025-12-11 00:32:13'),
('6', '3', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 00:32:13'),
('7', '4', '6', 'زيت زيتون', 'raw_material', '2025-12-11 00:41:53'),
('8', '4', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 00:41:53'),
('9', '5', '6', 'زيت زيتون', 'raw_material', '2025-12-11 00:43:46'),
('10', '5', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 00:43:46'),
('11', '6', '6', 'زيت زيتون', 'raw_material', '2025-12-11 01:17:40'),
('12', '6', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 01:17:40'),
('13', '7', '6', 'زيت زيتون', 'raw_material', '2025-12-11 01:34:30'),
('14', '7', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 01:34:30'),
('15', '8', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-11 02:19:41'),
('16', '8', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:19:41'),
('17', '9', '6', 'زيت زيتون', 'raw_material', '2025-12-11 02:25:55'),
('18', '9', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:25:55'),
('19', '10', '6', 'زيت زيتون', 'raw_material', '2025-12-11 02:27:17'),
('20', '10', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:27:17'),
('21', '11', '6', 'زيت زيتون', 'raw_material', '2025-12-11 02:29:15'),
('22', '11', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:29:15'),
('23', '12', '6', 'زيت زيتون', 'raw_material', '2025-12-11 02:30:09'),
('24', '12', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:30:09'),
('25', '13', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-11 02:31:58'),
('26', '13', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:31:58'),
('27', '14', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-11 02:51:48'),
('28', '14', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 02:51:48'),
('29', '15', '2', 'عسل - سدر', 'raw_material', '2025-12-11 07:55:29'),
('30', '15', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-11 07:55:29'),
('31', '16', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-14 15:47:16'),
('32', '16', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-14 15:47:16'),
('33', '17', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-15 01:11:48'),
('34', '17', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 01:11:48'),
('35', '18', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-15 01:26:51'),
('36', '18', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 01:26:51'),
('37', '19', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-15 01:34:44'),
('38', '19', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 01:34:44'),
('39', '20', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-15 01:51:59'),
('40', '20', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 01:51:59'),
('41', '21', '2', 'عسل - تيست', 'raw_material', '2025-12-15 18:04:54'),
('42', '21', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 18:04:54'),
('43', '22', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-15 18:08:03'),
('44', '22', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 18:08:03'),
('45', '23', '1', 'عسل - عسل حلبه', 'raw_material', '2025-12-15 18:08:15'),
('46', '23', '4', 'مورد ادوات تعبئه', 'packaging', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `batch_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `batch_workers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `batch_workers`;
CREATE TABLE `batch_workers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `worker_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `batch_workers` WRITE;
/*!40000 ALTER TABLE `batch_workers` DISABLE KEYS */;
INSERT INTO `batch_workers` (`id`, `batch_id`, `employee_id`, `worker_name`, `created_at`) VALUES
('1', '1', '4', 'عامل الإنتاج الأول', '2025-12-09 19:35:03'),
('2', '2', '4', 'عامل الإنتاج الأول', '2025-12-09 19:56:25'),
('3', '3', '2', 'المحاسب الأول', '2025-12-11 00:32:13'),
('4', '3', '4', 'عامل الإنتاج الأول', '2025-12-11 00:32:13'),
('5', '4', '2', 'المحاسب الأول', '2025-12-11 00:41:53'),
('6', '4', '4', 'عامل الإنتاج الأول', '2025-12-11 00:41:53'),
('7', '5', '2', 'المحاسب الأول', '2025-12-11 00:43:46'),
('8', '5', '4', 'عامل الإنتاج الأول', '2025-12-11 00:43:46'),
('9', '6', '2', 'المحاسب الأول', '2025-12-11 01:17:40'),
('10', '6', '4', 'عامل الإنتاج الأول', '2025-12-11 01:17:40'),
('11', '7', '2', 'المحاسب الأول', '2025-12-11 01:34:30'),
('12', '7', '4', 'عامل الإنتاج الأول', '2025-12-11 01:34:30'),
('13', '8', '2', 'المحاسب الأول', '2025-12-11 02:19:41'),
('14', '8', '4', 'عامل الإنتاج الأول', '2025-12-11 02:19:41'),
('15', '9', '2', 'المحاسب الأول', '2025-12-11 02:25:55'),
('16', '9', '4', 'عامل الإنتاج الأول', '2025-12-11 02:25:55'),
('17', '10', '2', 'المحاسب الأول', '2025-12-11 02:27:17'),
('18', '10', '4', 'عامل الإنتاج الأول', '2025-12-11 02:27:17'),
('19', '11', '2', 'المحاسب الأول', '2025-12-11 02:29:15'),
('20', '11', '4', 'عامل الإنتاج الأول', '2025-12-11 02:29:15'),
('21', '12', '2', 'المحاسب الأول', '2025-12-11 02:30:09'),
('22', '12', '4', 'عامل الإنتاج الأول', '2025-12-11 02:30:09'),
('23', '13', '2', 'المحاسب الأول', '2025-12-11 02:31:58'),
('24', '13', '4', 'عامل الإنتاج الأول', '2025-12-11 02:31:58'),
('25', '14', '2', 'المحاسب الأول', '2025-12-11 02:51:48'),
('26', '14', '4', 'عامل الإنتاج الأول', '2025-12-11 02:51:48'),
('27', '15', '2', 'Mohamed elsyed', '2025-12-11 07:55:29'),
('28', '15', '4', 'عامل الإنتاج الأول', '2025-12-11 07:55:29'),
('29', '15', '11', 'انتاج 2', '2025-12-11 07:55:29'),
('30', '15', '16', 'انتاج 3', '2025-12-11 07:55:29'),
('31', '16', '4', 'عامل الإنتاج الأول', '2025-12-14 15:47:16'),
('32', '17', '4', 'عامل الإنتاج الأول', '2025-12-15 01:11:48'),
('33', '18', '4', 'عامل الإنتاج الأول', '2025-12-15 01:26:51'),
('34', '19', '4', 'عامل الإنتاج الأول', '2025-12-15 01:34:44'),
('35', '20', '4', 'عامل الإنتاج الأول', '2025-12-15 01:51:59'),
('36', '21', '4', 'عامل الإنتاج الأول', '2025-12-15 18:04:54'),
('37', '22', '4', 'عامل الإنتاج الأول', '2025-12-15 18:08:03'),
('38', '23', '4', 'عامل الإنتاج الأول', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `batch_workers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `batches`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `batches`;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) NOT NULL,
  `production_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `status` enum('in_production','completed','cancelled') DEFAULT 'in_production',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_batch_number` (`batch_number`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
INSERT INTO `batches` (`id`, `product_id`, `batch_number`, `production_date`, `expiry_date`, `quantity`, `status`, `created_at`, `updated_at`) VALUES
('1', NULL, '251210-990828', '2025-12-10', '2026-12-10', '50', 'in_production', '2025-12-09 19:35:03', '2025-12-09 19:35:03'),
('2', NULL, '251210-921358', '2025-12-10', '2026-12-10', '20', 'in_production', '2025-12-09 19:56:25', '2025-12-09 19:56:25'),
('3', NULL, '251211-069336', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 00:32:13', '2025-12-11 00:32:13'),
('4', NULL, '251211-995189', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 00:41:53', '2025-12-11 00:41:53'),
('5', NULL, '251211-531412', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 00:43:46', '2025-12-11 00:43:46'),
('6', NULL, '251211-945752', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 01:17:40', '2025-12-11 01:17:40'),
('7', NULL, '251211-219169', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 01:34:30', '2025-12-11 01:34:30'),
('8', NULL, '251211-072970', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 02:19:41', '2025-12-11 02:19:41'),
('9', NULL, '251211-461225', '2025-12-11', '2026-12-11', '6', 'in_production', '2025-12-11 02:25:55', '2025-12-11 02:25:55'),
('10', NULL, '251211-269689', '2025-12-11', '2026-12-11', '6', 'in_production', '2025-12-11 02:27:17', '2025-12-11 02:27:17'),
('11', NULL, '251211-460851', '2025-12-11', '2026-12-11', '6', 'in_production', '2025-12-11 02:29:15', '2025-12-11 02:29:15'),
('12', NULL, '251211-581612', '2025-12-11', '2026-12-11', '12', 'in_production', '2025-12-11 02:30:09', '2025-12-11 02:30:09'),
('13', NULL, '251211-590620', '2025-12-11', '2026-12-11', '11', 'in_production', '2025-12-11 02:31:58', '2025-12-11 02:31:58'),
('14', NULL, '251211-966029', '2025-12-11', '2026-12-11', '1', 'in_production', '2025-12-11 02:51:48', '2025-12-11 02:51:48'),
('15', NULL, '251211-923972', '2025-12-11', '2026-12-11', '18', 'in_production', '2025-12-11 07:55:29', '2025-12-11 07:55:29'),
('16', NULL, '251214-424521', '2025-12-14', '2026-12-14', '6', 'in_production', '2025-12-14 15:47:16', '2025-12-14 15:47:16'),
('17', NULL, '251215-093925', '2025-12-15', '2026-12-15', '6', 'in_production', '2025-12-15 01:11:48', '2025-12-15 01:11:48'),
('18', NULL, '251215-613802', '2025-12-15', '2026-12-15', '6', 'in_production', '2025-12-15 01:26:51', '2025-12-15 01:26:51'),
('19', NULL, '251215-082617', '2025-12-15', '2026-12-15', '6', 'in_production', '2025-12-15 01:34:44', '2025-12-15 01:34:44'),
('20', NULL, '251215-135346', '2025-12-15', '2026-12-15', '6', 'in_production', '2025-12-15 01:51:59', '2025-12-15 01:51:59'),
('21', NULL, '251215-836983', '2025-12-15', '2026-12-15', '12', 'in_production', '2025-12-15 18:04:54', '2025-12-15 18:04:54'),
('22', NULL, '251215-539325', '2025-12-15', '2026-12-15', '1', 'in_production', '2025-12-15 18:08:03', '2025-12-15 18:08:03'),
('23', NULL, '251215-241987', '2025-12-15', '2026-12-15', '2', 'in_production', '2025-12-15 18:08:15', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `beeswax_product_templates`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `beeswax_product_templates`;
CREATE TABLE `beeswax_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `beeswax_weight` decimal(10,2) NOT NULL COMMENT 'وزن شمع العسل (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `beeswax_product_templates`

-- --------------------------------------------------------
-- Table structure for table `beeswax_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `beeswax_stock`;
CREATE TABLE `beeswax_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `beeswax_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `beeswax_stock` WRITE;
/*!40000 ALTER TABLE `beeswax_stock` DISABLE KEYS */;
INSERT INTO `beeswax_stock` (`id`, `supplier_id`, `weight`, `created_at`, `updated_at`) VALUES
('1', '8', '100.00', '2025-12-10 05:55:50', NULL);
/*!40000 ALTER TABLE `beeswax_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `blocked_ips`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `blocked_ips`;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT NULL,
  `blocked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `blocked_until` (`blocked_until`),
  KEY `blocked_by` (`blocked_by`),
  CONSTRAINT `blocked_ips_ibfk_1` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `blocked_ips`

-- --------------------------------------------------------
-- Table structure for table `cash_register_additions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cash_register_additions`;
CREATE TABLE `cash_register_additions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_rep_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `created_at` (`created_at`),
  KEY `cash_register_additions_ibfk_2` (`created_by`),
  CONSTRAINT `cash_register_additions_ibfk_1` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_register_additions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `cash_register_additions` WRITE;
/*!40000 ALTER TABLE `cash_register_additions` DISABLE KEYS */;
INSERT INTO `cash_register_additions` (`id`, `sales_rep_id`, `amount`, `description`, `created_by`, `created_at`) VALUES
('1', '10', '10000.00', NULL, '10', '2025-12-08 17:41:19'),
('2', '10', '1000.00', 'عربون', '10', '2025-12-10 05:08:12');
/*!40000 ALTER TABLE `cash_register_additions` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `collections`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `collections`;
CREATE TABLE `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_number` varchar(50) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','check','other') DEFAULT 'cash',
  `reference_number` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `collected_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `collected_by` (`collected_by`),
  KEY `date` (`date`),
  CONSTRAINT `collections_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collections_ibfk_2` FOREIGN KEY (`collected_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
INSERT INTO `collections` (`id`, `collection_number`, `customer_id`, `amount`, `date`, `payment_method`, `reference_number`, `notes`, `collected_by`, `created_at`) VALUES
('1', 'COL-202512-0001', '1', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0001', '17', '2025-12-09 20:03:22'),
('2', 'COL-202512-0002', '2', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل جزئي من نقطة بيع المندوب - فاتورة INV-202512-0002', '17', '2025-12-09 20:40:25'),
('3', 'COL-202512-0003', '2', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل جزئي من نقطة بيع المندوب - فاتورة INV-202512-0003', '17', '2025-12-09 20:50:35'),
('4', 'COL-202512-0004', '2', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل من صفحة العملاء', '17', '2025-12-09 21:02:32'),
('5', 'COL-202512-0005', '2', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل من صفحة العملاء', '17', '2025-12-09 21:11:57'),
('6', 'COL-202512-0006', '5', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0005', '10', '2025-12-09 22:26:09'),
('7', 'COL-202512-0007', '5', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل جزئي من نقطة بيع المندوب - فاتورة INV-202512-0006', '10', '2025-12-09 22:26:54'),
('8', 'COL-202512-0008', '5', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل من صفحة العملاء', '10', '2025-12-09 22:27:55'),
('9', 'COL-202512-0009', '6', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0008', '10', '2025-12-09 23:06:05'),
('10', 'COL-202512-0010', '9', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0011', '10', '2025-12-09 23:17:54'),
('11', 'COL-202512-0011', '5', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0025', '10', '2025-12-10 00:37:03'),
('12', 'COL-202512-0012', '8', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0026', '10', '2025-12-10 00:38:57'),
('13', 'COL-202512-0013', '13', '1000.00', '2025-12-10', 'cash', NULL, 'دفع كامل من نقطة بيع المندوب - فاتورة INV-202512-0027', '18', '2025-12-10 00:50:34'),
('14', 'COL-202512-0014', '13', '500.00', '2025-12-10', 'cash', NULL, 'تحصيل جزئي من نقطة بيع المندوب - فاتورة INV-202512-0028', '18', '2025-12-10 00:51:18');
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `customer_order_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customer_order_items`;
CREATE TABLE `customer_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `customer_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `customer_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `customer_order_items` WRITE;
/*!40000 ALTER TABLE `customer_order_items` DISABLE KEYS */;
INSERT INTO `customer_order_items` (`id`, `order_id`, `product_id`, `template_id`, `product_name`, `quantity`, `unit_price`, `total_price`, `notes`, `created_at`) VALUES
('1', '1', NULL, NULL, 'عسل', '10.00', '0.00', '0.00', NULL, '2025-12-10 05:16:31'),
('2', '2', NULL, '4', NULL, '10.00', '0.00', '0.00', NULL, '2025-12-10 22:40:53');
/*!40000 ALTER TABLE `customer_order_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `customer_orders`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customer_orders`;
CREATE TABLE `customer_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `order_type` enum('sales_rep','company') DEFAULT 'sales_rep',
  `order_date` date NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('pending','confirmed','in_production','ready','delivered','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `customer_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_orders_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `customer_orders` WRITE;
/*!40000 ALTER TABLE `customer_orders` DISABLE KEYS */;
INSERT INTO `customer_orders` (`id`, `order_number`, `customer_id`, `sales_rep_id`, `order_type`, `order_date`, `delivery_date`, `subtotal`, `discount_amount`, `total_amount`, `priority`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'ORD-202512-0001', '15', '18', 'sales_rep', '2025-12-10', '2025-12-11', '0.00', '0.00', '0.00', 'normal', 'delivered', '', '1', '2025-12-10 05:16:31', '2025-12-10 05:17:57'),
('2', 'ORD-202512-0002', '14', '10', 'sales_rep', '2025-12-11', NULL, '0.00', '0.00', '0.00', 'normal', 'pending', '', '1', '2025-12-10 22:40:53', NULL);
/*!40000 ALTER TABLE `customer_orders` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `customer_purchase_history`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customer_purchase_history`;
CREATE TABLE `customer_purchase_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `invoice_date` date NOT NULL,
  `invoice_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `invoice_status` varchar(32) DEFAULT NULL,
  `return_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `return_count` int(11) NOT NULL DEFAULT 0,
  `exchange_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `exchange_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_invoice_unique` (`customer_id`,`invoice_id`),
  KEY `customer_invoice_date_idx` (`customer_id`,`invoice_date`),
  KEY `invoice_date_idx` (`invoice_date`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `customer_purchase_history` WRITE;
/*!40000 ALTER TABLE `customer_purchase_history` DISABLE KEYS */;
INSERT INTO `customer_purchase_history` (`id`, `customer_id`, `invoice_id`, `invoice_number`, `invoice_date`, `invoice_total`, `paid_amount`, `invoice_status`, `return_total`, `return_count`, `exchange_total`, `exchange_count`, `created_at`, `updated_at`) VALUES
('1', '1', '1', 'INV-202512-0001', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-09 20:03:22', NULL),
('2', '2', '2', 'INV-202512-0002', '2025-12-10', '1000.00', '500.00', 'partial', '0.00', '0', '0.00', '0', '2025-12-09 20:40:25', NULL),
('3', '2', '3', 'INV-202512-0003', '2025-12-10', '1000.00', '500.00', 'partial', '0.00', '0', '0.00', '0', '2025-12-09 20:50:35', NULL),
('4', '3', '4', 'INV-202512-0004', '2025-12-10', '1000.00', '0.00', 'sent', '0.00', '0', '0.00', '0', '2025-12-09 20:51:59', NULL),
('5', '5', '5', 'INV-202512-0005', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-09 22:26:09', '2025-12-09 23:05:46'),
('6', '5', '6', 'INV-202512-0006', '2025-12-10', '1000.00', '500.00', 'partial', '1000.00', '1', '0.00', '0', '2025-12-09 22:26:54', '2025-12-09 23:05:46'),
('7', '5', '7', 'INV-202512-0007', '2025-12-10', '1000.00', '0.00', 'sent', '1000.00', '1', '0.00', '0', '2025-12-09 22:28:53', '2025-12-09 23:05:46'),
('20', '6', '8', 'INV-202512-0008', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-09 23:06:05', NULL),
('21', '8', '9', 'INV-202512-0009', '2025-12-10', '1000.00', '0.00', 'sent', '0.00', '0', '0.00', '0', '2025-12-09 23:12:09', '2025-12-09 23:53:21'),
('22', '8', '10', 'INV-202512-0010', '2025-12-10', '1000.00', '0.00', 'sent', '1000.00', '1', '0.00', '0', '2025-12-09 23:12:34', '2025-12-09 23:53:21'),
('23', '9', '11', 'INV-202512-0011', '2025-12-10', '1000.00', '1000.00', 'paid', '1000.00', '1', '0.00', '0', '2025-12-09 23:17:54', '2025-12-10 00:02:06'),
('24', '9', '12', 'INV-202512-0012', '2025-12-10', '1000.00', '1000.00', 'paid', '1000.00', '1', '0.00', '0', '2025-12-09 23:22:19', '2025-12-10 00:02:06'),
('25', '9', '13', 'INV-202512-0013', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-09 23:35:34', '2025-12-10 00:02:06'),
('26', '1', '15', 'INV-202512-0015', '2025-12-10', '1000.00', '0.00', 'sent', '0.00', '0', '0.00', '0', '2025-12-09 23:42:29', NULL),
('27', '1', '17', 'INV-202512-0017', '2025-12-10', '1000.00', '0.00', 'sent', '0.00', '0', '0.00', '0', '2025-12-09 23:43:35', NULL),
('36', '5', '25', 'INV-202512-0025', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-10 00:37:03', NULL),
('37', '8', '26', 'INV-202512-0026', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-10 00:38:57', NULL),
('38', '13', '27', 'INV-202512-0027', '2025-12-10', '1000.00', '1000.00', 'paid', '0.00', '0', '0.00', '0', '2025-12-10 00:50:34', NULL),
('39', '13', '28', 'INV-202512-0028', '2025-12-10', '1000.00', '500.00', 'partial', '0.00', '0', '0.00', '0', '2025-12-10 00:51:18', NULL),
('40', '5', '33', 'INV-202512-0033', '2025-12-11', '1000.00', '0.00', 'sent', '0.00', '0', '0.00', '0', '2025-12-11 05:54:21', NULL),
('41', '8', '31', 'INV-202512-0031', '2025-12-10', '10000.00', '0.00', 'sent', '0.00', '0', '0.00', '0', '2025-12-11 05:54:41', NULL);
/*!40000 ALTER TABLE `customer_purchase_history` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `customers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rep_id` int(11) DEFAULT NULL,
  `created_from_pos` tinyint(1) NOT NULL DEFAULT 0,
  `created_by_admin` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `location_captured_at` datetime DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_customers_created_by` (`created_by`),
  KEY `rep_id` (`rep_id`),
  KEY `region_id` (`region_id`),
  CONSTRAINT `customers_ibfk_region` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_customers_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`id`, `rep_id`, `created_from_pos`, `created_by_admin`, `name`, `phone`, `email`, `address`, `region_id`, `latitude`, `longitude`, `location_captured_at`, `balance`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
('1', '17', '0', '0', '1', '123', NULL, '1234', NULL, '31.23445760', '29.97288960', '2025-12-10 06:03:22', '0.00', 'active', '17', '2025-12-09 20:03:22', NULL),
('2', '17', '0', '0', '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '17', '2025-12-09 20:40:25', '2025-12-09 21:11:57'),
('3', '17', '0', '0', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1000.00', 'active', '17', '2025-12-09 20:51:59', NULL),
('4', '10', '0', '0', '1', '01000100', NULL, NULL, '1', '31.23445760', '29.97288960', '2025-12-10 07:33:04', '0.00', 'active', '10', '2025-12-09 21:33:04', '2025-12-10 21:55:20'),
('5', '10', '0', '0', '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '10', '2025-12-09 21:36:28', '2025-12-10 07:04:48'),
('6', '10', '0', '0', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '10', '2025-12-09 21:36:38', '2025-12-09 23:58:11'),
('7', '10', '0', '0', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '10', '2025-12-09 21:36:53', '2025-12-10 05:00:36'),
('8', '10', '0', '0', '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '10', '2025-12-09 23:11:54', '2025-12-10 00:35:53'),
('9', '10', '0', '0', '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-1000.00', 'active', '10', '2025-12-09 23:17:41', '2025-12-10 00:26:07'),
('10', NULL, '1', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '1', '2025-12-09 23:42:29', NULL),
('11', NULL, '1', '1', '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '1', '2025-12-09 23:54:06', NULL),
('12', NULL, '1', '1', '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '1', '2025-12-09 23:56:21', NULL),
('13', '18', '0', '0', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '400.00', 'active', '18', '2025-12-10 00:50:34', '2025-12-11 03:09:43'),
('14', '10', '0', '0', 'مايكل', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '400.00', 'active', '10', '2025-12-10 04:57:32', '2025-12-11 00:48:40'),
('15', '18', '0', '1', 'احمد', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '18', '2025-12-10 05:16:31', NULL),
('16', NULL, '1', '1', '12', '.02221', NULL, '515', NULL, NULL, NULL, NULL, '0.00', 'active', '1', '2025-12-10 06:57:04', NULL),
('17', NULL, '1', '1', 'شحن 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.00', 'active', '2', '2025-12-11 05:54:40', NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `daily_backup_sent_log`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `daily_backup_sent_log`;
CREATE TABLE `daily_backup_sent_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent_date` date NOT NULL,
  `sent_at` datetime NOT NULL,
  `backup_file_path` varchar(512) DEFAULT NULL,
  `backup_id` int(11) DEFAULT NULL,
  `status` enum('sent','failed') DEFAULT 'sent',
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_sent_date` (`sent_date`),
  KEY `sent_at` (`sent_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `daily_backup_sent_log` WRITE;
/*!40000 ALTER TABLE `daily_backup_sent_log` DISABLE KEYS */;
INSERT INTO `daily_backup_sent_log` (`id`, `sent_date`, `sent_at`, `backup_file_path`, `backup_id`, `status`, `error_message`, `created_at`) VALUES
('1', '2025-12-10', '2025-12-10 00:15:03', 'backup_if0_40278066_co_db_2025-12-10_00-15-02.sql.gz', '1', 'sent', NULL, '2025-12-09 14:15:03'),
('2', '2025-12-11', '2025-12-11 04:12:14', 'backup_if0_40278066_co_db_2025-12-11_04-12-13.sql.gz', '3', 'sent', NULL, '2025-12-10 18:12:14'),
('3', '2025-12-12', '2025-12-12 01:44:21', 'backup_if0_40278066_co_db_2025-12-12_01-44-20.sql.gz', '4', 'sent', NULL, '2025-12-11 15:44:21');
/*!40000 ALTER TABLE `daily_backup_sent_log` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `damaged_returns`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `damaged_returns`;
CREATE TABLE `damaged_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `return_item_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `damage_reason` text DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_transaction_number` varchar(100) DEFAULT NULL,
  `approval_status` varchar(50) DEFAULT 'pending',
  `sales_rep_id` int(11) DEFAULT NULL,
  `sales_rep_name` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_return_id` (`return_id`),
  KEY `idx_return_item_id` (`return_item_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_batch_number_id` (`batch_number_id`),
  KEY `idx_sales_rep_id` (`sales_rep_id`),
  KEY `idx_approval_status` (`approval_status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `damaged_returns` WRITE;
/*!40000 ALTER TABLE `damaged_returns` DISABLE KEYS */;
INSERT INTO `damaged_returns` (`id`, `return_id`, `return_item_id`, `product_id`, `batch_number_id`, `quantity`, `damage_reason`, `invoice_id`, `invoice_number`, `return_date`, `return_transaction_number`, `approval_status`, `sales_rep_id`, `sales_rep_name`, `product_name`, `batch_number`, `created_at`) VALUES
('1', '1', '1', '4', '2', '1.00', '', '7', 'INV-202512-0007', '2025-12-10', 'RET-202512-0001', 'approved', '10', 'مبيعات1', 'TEST', '251210-921358', '2025-12-09 22:33:11');
/*!40000 ALTER TABLE `damaged_returns` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `derivatives_product_templates`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `derivatives_product_templates`;
CREATE TABLE `derivatives_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `derivative_type` varchar(100) NOT NULL COMMENT 'نوع المشتق المستخدم',
  `derivative_weight` decimal(10,2) NOT NULL COMMENT 'وزن المشتق (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `derivative_type` (`derivative_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `derivatives_product_templates`

-- --------------------------------------------------------
-- Table structure for table `derivatives_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `derivatives_stock`;
CREATE TABLE `derivatives_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `derivative_type` varchar(100) NOT NULL COMMENT 'نوع المشتق',
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الوزن (كجم)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_derivative` (`supplier_id`,`derivative_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `derivative_type` (`derivative_type`),
  CONSTRAINT `derivatives_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `derivatives_stock`

-- --------------------------------------------------------
-- Table structure for table `exchange_new_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exchange_new_items`;
CREATE TABLE `exchange_new_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `exchange_new_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `product_exchanges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_new_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_new_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `exchange_new_items`

-- --------------------------------------------------------
-- Table structure for table `exchange_return_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exchange_return_items`;
CREATE TABLE `exchange_return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `exchange_return_items_ibfk_1` FOREIGN KEY (`exchange_id`) REFERENCES `product_exchanges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchange_return_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `exchange_return_items`

-- --------------------------------------------------------
-- Table structure for table `exchanges`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exchanges`;
CREATE TABLE `exchanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_number` varchar(50) NOT NULL,
  `return_id` int(11) DEFAULT NULL,
  `original_sale_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `exchange_date` date NOT NULL,
  `exchange_type` enum('same_product','different_product','upgrade','downgrade') DEFAULT 'same_product',
  `reason` text DEFAULT NULL,
  `original_total` decimal(15,2) NOT NULL,
  `new_total` decimal(15,2) NOT NULL,
  `difference_amount` decimal(15,2) DEFAULT 0.00,
  `difference_paid` tinyint(1) DEFAULT 0,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_number` (`exchange_number`),
  KEY `return_id` (`return_id`),
  KEY `original_sale_id` (`original_sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `exchange_date` (`exchange_date`),
  KEY `status` (`status`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `exchanges_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_2` FOREIGN KEY (`original_sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchanges_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exchanges_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `exchanges_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `exchanges`

-- --------------------------------------------------------
-- Table structure for table `factory_waste_packaging`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `factory_waste_packaging`;
CREATE TABLE `factory_waste_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packaging_damage_log_id` int(11) DEFAULT NULL,
  `tool_type` varchar(255) NOT NULL,
  `damaged_quantity` decimal(10,2) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `added_date` date NOT NULL,
  `recorded_by_user_id` int(11) DEFAULT NULL,
  `recorded_by_user_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_packaging_damage_log_id` (`packaging_damage_log_id`),
  KEY `idx_recorded_by_user_id` (`recorded_by_user_id`),
  KEY `idx_added_date` (`added_date`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `factory_waste_packaging` WRITE;
/*!40000 ALTER TABLE `factory_waste_packaging` DISABLE KEYS */;
INSERT INTO `factory_waste_packaging` (`id`, `packaging_damage_log_id`, `tool_type`, `damaged_quantity`, `unit`, `added_date`, `recorded_by_user_id`, `recorded_by_user_name`, `created_at`) VALUES
('1', '1', 'أغطية - غطاء 43م', '10.00', 'قطعة', '2025-12-10', '1', 'المدير العام', '2025-12-10 02:19:30'),
('2', '2', 'أغطية - غطاء 43م', '1.00', 'قطعة', '2025-12-11', '4', 'عامل الإنتاج الأول', '2025-12-11 08:00:48'),
('3', '3', 'أغطية - غطاء 43م', '1.00', 'قطعة', '2025-12-15', '4', 'عامل الإنتاج الأول', '2025-12-15 01:24:42'),
('4', '4', 'أغطية - غطاء 43م', '2.00', 'قطعة', '2025-12-15', '1', 'المدير العام', '2025-12-15 02:07:45');
/*!40000 ALTER TABLE `factory_waste_packaging` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `factory_waste_products`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `factory_waste_products`;
CREATE TABLE `factory_waste_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `damaged_return_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `batch_number_id` int(11) DEFAULT NULL,
  `damaged_quantity` decimal(10,2) NOT NULL,
  `waste_value` decimal(10,2) DEFAULT 0.00,
  `source` varchar(100) DEFAULT 'damaged_returns',
  `transaction_number` varchar(100) DEFAULT NULL,
  `added_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_batch_number_id` (`batch_number_id`),
  KEY `idx_damaged_return_id` (`damaged_return_id`),
  KEY `idx_added_date` (`added_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `factory_waste_products`

-- --------------------------------------------------------
-- Table structure for table `factory_waste_raw_materials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `factory_waste_raw_materials`;
CREATE TABLE `factory_waste_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `raw_material_damage_log_id` int(11) DEFAULT NULL,
  `material_name` varchar(255) NOT NULL,
  `wasted_quantity` decimal(10,2) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `waste_reason` text DEFAULT NULL,
  `added_date` date NOT NULL,
  `recorded_by_user_id` int(11) DEFAULT NULL,
  `recorded_by_user_name` varchar(255) DEFAULT NULL,
  `waste_value` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_raw_material_damage_log_id` (`raw_material_damage_log_id`),
  KEY `idx_recorded_by_user_id` (`recorded_by_user_id`),
  KEY `idx_added_date` (`added_date`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `factory_waste_raw_materials` WRITE;
/*!40000 ALTER TABLE `factory_waste_raw_materials` DISABLE KEYS */;
INSERT INTO `factory_waste_raw_materials` (`id`, `raw_material_damage_log_id`, `material_name`, `wasted_quantity`, `unit`, `waste_reason`, `added_date`, `recorded_by_user_id`, `recorded_by_user_name`, `waste_value`, `created_at`) VALUES
('1', '1', 'زيت زيتون', '1.00', 'كجم', '3', '2025-12-10', '4', 'عامل الإنتاج الأول', '0.00', '2025-12-09 19:26:33'),
('2', '2', 'عسل مصفى - حبة البركة', '10.00', 'كجم', '00', '2025-12-10', '1', 'المدير العام', '0.00', '2025-12-10 02:18:12'),
('3', '3', 'عسل خام', '1.00', 'كجم', 'ال', '2025-12-11', '4', 'عامل الإنتاج الأول', '0.00', '2025-12-11 08:01:32');
/*!40000 ALTER TABLE `factory_waste_raw_materials` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `financial_transactions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `financial_transactions`;
CREATE TABLE `financial_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('expense','income','transfer','payment') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `financial_transactions_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_transactions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_transactions_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `financial_transactions` WRITE;
/*!40000 ALTER TABLE `financial_transactions` DISABLE KEYS */;
INSERT INTO `financial_transactions` (`id`, `type`, `amount`, `supplier_id`, `description`, `reference_number`, `status`, `approved_by`, `created_by`, `approved_at`, `created_at`) VALUES
('1', 'expense', '500.00', NULL, '232', 'REF-864805', 'approved', '1', '1', '2025-12-09 18:46:16', '2025-12-09 18:46:16'),
('2', 'expense', '800.00', NULL, '1', 'REF-138821', 'approved', '1', '1', '2025-12-09 19:05:52', '2025-12-09 19:05:53'),
('3', 'payment', '1000.00', '8', 'تسجيل سداد للمورد: مورد شمع', 'SUP-8-20251210055938', 'approved', '1', '1', '2025-12-09 19:59:38', '2025-12-09 19:59:38'),
('4', 'expense', '200.00', NULL, '23', 'REF-763647', 'approved', '1', '1', '2025-12-09 23:44:33', '2025-12-09 23:44:33'),
('5', 'payment', '500.00', '8', 'تسجيل سداد للمورد: مورد شمع', 'SUP-8-20251210115723', 'approved', '1', '1', '2025-12-10 01:57:23', '2025-12-10 01:57:23'),
('6', 'expense', '100.00', NULL, 'مكنسه', 'REF-946512', 'approved', '1', '2', '2025-12-10 07:06:49', '2025-12-10 07:06:18'),
('7', 'payment', '400.00', '8', 'تسجيل سداد للمورد: مورد شمع', 'SUP-8-20251215023151', 'approved', '1', '1', '2025-12-15 02:31:51', '2025-12-15 02:31:51'),
('8', 'payment', '1.00', '8', 'تسجيل سداد للمورد: مورد شمع', 'SUP-8-20251215023226', 'approved', '1', '1', '2025-12-15 02:32:26', '2025-12-15 02:32:26'),
('9', 'payment', '1.00', '8', 'تسجيل سداد للمورد: مورد شمع', 'SUP-8-20251215023540', 'approved', '1', '1', '2025-12-15 02:35:40', '2025-12-15 02:35:40');
/*!40000 ALTER TABLE `financial_transactions` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `finished_products`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `finished_products`;
CREATE TABLE `finished_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `batch_number` varchar(100) NOT NULL,
  `production_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity_produced` int(11) NOT NULL DEFAULT 0,
  `unit_price` decimal(12,2) DEFAULT NULL COMMENT 'سعر الوحدة من القالب',
  `total_price` decimal(12,2) DEFAULT NULL COMMENT 'السعر الإجمالي (unit_price × quantity_produced)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number` (`batch_number`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `finished_products` WRITE;
/*!40000 ALTER TABLE `finished_products` DISABLE KEYS */;
INSERT INTO `finished_products` (`id`, `batch_id`, `product_id`, `product_name`, `batch_number`, `production_date`, `expiry_date`, `quantity_produced`, `unit_price`, `total_price`, `created_at`) VALUES
('1', '1', '3', '1', '251210-990828', '2025-12-10', '2026-12-10', '60', '1000.00', '60000.00', '2025-12-09 19:35:03'),
('2', '2', '4', 'TEST', '251210-921358', '2025-12-10', '2026-12-10', '0', '1000.00', '20000.00', '2025-12-09 19:56:25'),
('3', '3', '12', 'مخصص', '251211-069336', '2025-12-11', '2026-12-11', '11', '1000.00', '11000.00', '2025-12-11 00:32:13'),
('4', '4', '12', 'مخصص', '251211-995189', '2025-12-11', '2026-12-11', '11', '1000.00', '11000.00', '2025-12-11 00:41:53'),
('5', '5', '12', 'مخصص', '251211-531412', '2025-12-11', '2026-12-11', '11', '1000.00', '11000.00', '2025-12-11 00:43:46'),
('6', '6', '13', '11', '251211-945752', '2025-12-11', '2026-12-11', '11', '1000.00', '11000.00', '2025-12-11 01:17:40'),
('7', '7', '13', '11', '251211-219169', '2025-12-11', '2026-12-11', '10', '1000.00', '10000.00', '2025-12-11 01:34:30'),
('8', '8', '15', '12', '251211-072970', '2025-12-11', '2026-12-11', '11', '1000.00', '11000.00', '2025-12-11 02:19:41'),
('9', '9', '4', 'TEST', '251211-461225', '2025-12-11', '2026-12-11', '0', '1000.00', '6000.00', '2025-12-11 02:25:55'),
('10', '10', '4', 'TEST', '251211-269689', '2025-12-11', '2026-12-11', '0', '1000.00', '6000.00', '2025-12-11 02:27:17'),
('11', '11', '4', 'TEST', '251211-460851', '2025-12-11', '2026-12-11', '0', '1000.00', '6000.00', '2025-12-11 02:29:15'),
('12', '12', '4', 'TEST', '251211-581612', '2025-12-11', '2026-12-11', '0', '1000.00', '12000.00', '2025-12-11 02:30:09'),
('13', '13', '15', '12', '251211-590620', '2025-12-11', '2026-12-11', '11', '1000.00', '11000.00', '2025-12-11 02:31:58'),
('14', '14', '15', '12', '251211-966029', '2025-12-11', '2026-12-11', '1', '1000.00', '1000.00', '2025-12-11 02:51:48'),
('15', '15', '20', 'عسل ك سنبله', '251211-923972', '2025-12-11', '2026-12-11', '8', '150.00', '2700.00', '2025-12-11 07:55:29'),
('16', '16', '30', 'ك', '251214-424521', '2025-12-14', '2026-12-14', '6', '150.00', '900.00', '2025-12-14 15:47:16'),
('17', '17', '30', 'ك', '251215-093925', '2025-12-15', '2026-12-15', '6', '150.00', '900.00', '2025-12-15 01:11:48'),
('18', '18', '30', 'ك', '251215-613802', '2025-12-15', '2026-12-15', '6', '150.00', '900.00', '2025-12-15 01:26:51'),
('19', '19', '30', 'ك', '251215-082617', '2025-12-15', '2026-12-15', '0', '150.00', '900.00', '2025-12-15 01:34:44'),
('20', '20', '30', 'ك', '251215-135346', '2025-12-15', '2026-12-15', '6', '150.00', '900.00', '2025-12-15 01:51:59'),
('21', '21', '3', '1', '251215-836983', '2025-12-15', '2026-12-15', '12', '1000.00', '12000.00', '2025-12-15 18:04:54'),
('22', '22', '32', '2', '251215-539325', '2025-12-15', '2026-12-15', '1', '1000.00', '1000.00', '2025-12-15 18:08:03'),
('23', '23', '32', '2', '251215-241987', '2025-12-15', '2026-12-15', '2', '1000.00', '2000.00', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `finished_products` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `group_chat_messages`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `group_chat_messages`;
CREATE TABLE `group_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group_chat_user` (`user_id`),
  KEY `idx_group_chat_parent` (`parent_id`),
  KEY `idx_group_chat_created` (`created_at`),
  CONSTRAINT `fk_group_chat_parent` FOREIGN KEY (`parent_id`) REFERENCES `group_chat_messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_group_chat_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `group_chat_messages`

-- --------------------------------------------------------
-- Table structure for table `honey_filtration`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `honey_filtration`;
CREATE TABLE `honey_filtration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `raw_honey_quantity` decimal(10,2) NOT NULL,
  `filtered_honey_quantity` decimal(10,2) NOT NULL,
  `filtration_loss` decimal(10,2) NOT NULL COMMENT 'الكمية المفقودة (0.5%)',
  `filtration_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `filtration_date` (`filtration_date`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `honey_filtration_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `honey_filtration_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `honey_filtration` WRITE;
/*!40000 ALTER TABLE `honey_filtration` DISABLE KEYS */;
INSERT INTO `honey_filtration` (`id`, `supplier_id`, `raw_honey_quantity`, `filtered_honey_quantity`, `filtration_loss`, `filtration_date`, `notes`, `created_by`, `created_at`) VALUES
('1', '1', '100.00', '99.50', '0.50', '2025-12-10', NULL, '1', '2025-12-10 02:17:01'),
('2', '1', '15.00', '14.93', '0.08', '2025-12-11', NULL, '4', '2025-12-11 02:18:59'),
('3', '2', '100.00', '99.50', '0.50', '2025-12-11', NULL, '1', '2025-12-11 07:31:06'),
('4', '2', '100.00', '99.50', '0.50', '2025-12-11', NULL, '1', '2025-12-11 07:41:33');
/*!40000 ALTER TABLE `honey_filtration` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `honey_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `honey_stock`;
CREATE TABLE `honey_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `honey_variety` varchar(100) DEFAULT NULL COMMENT 'نوع العسل (يدعم أنواع مخصصة)',
  `raw_honey_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `filtered_honey_quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  KEY `honey_variety` (`honey_variety`),
  KEY `supplier_variety` (`supplier_id`,`honey_variety`),
  CONSTRAINT `honey_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `honey_stock` WRITE;
/*!40000 ALTER TABLE `honey_stock` DISABLE KEYS */;
INSERT INTO `honey_stock` (`id`, `supplier_id`, `honey_variety`, `raw_honey_quantity`, `filtered_honey_quantity`, `created_at`, `updated_at`) VALUES
('1', '1', 'حبة البركة', '0.00', '52.00', '2025-12-10 02:16:35', '2025-12-15 01:51:59'),
('2', '2', 'سدر', '0.00', '99.50', '2025-12-10 02:20:31', '2025-12-11 07:41:33'),
('8', '1', '13', '10.00', '0.00', '2025-12-11 02:11:45', NULL),
('9', '1', 'عسل حلبه', '0.00', '11.93', '2025-12-11 02:12:31', '2025-12-15 18:08:15'),
('10', '2', 'نوارة برسيم', '0.00', '82.00', '2025-12-11 07:30:36', '2025-12-11 07:55:29'),
('11', '2', 'تيست', '0.00', '88.00', '2025-12-15 01:13:05', '2025-12-15 18:04:54');
/*!40000 ALTER TABLE `honey_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `honey_types`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `honey_types`;
CREATE TABLE `honey_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `honey_type_id` varchar(10) NOT NULL COMMENT 'معرف نوع العسل (مثل KI001)',
  `name` varchar(100) NOT NULL COMMENT 'اسم نوع العسل',
  `is_custom` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'هل هو نوع مخصص (يدوي)',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `honey_type_id` (`honey_type_id`),
  UNIQUE KEY `name` (`name`),
  KEY `created_by` (`created_by`),
  KEY `is_custom` (`is_custom`),
  CONSTRAINT `honey_types_created_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `honey_types` WRITE;
/*!40000 ALTER TABLE `honey_types` DISABLE KEYS */;
INSERT INTO `honey_types` (`id`, `honey_type_id`, `name`, `is_custom`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'KI380', 'نوع جديد', '1', '1', '2025-12-10 23:59:24', NULL),
('2', 'KI548', 'نحل 1', '1', '1', '2025-12-11 01:07:55', NULL),
('3', 'KI257', 'جديد 2', '1', '4', '2025-12-11 01:51:03', NULL),
('4', 'KI507', '13', '1', '4', '2025-12-11 02:11:45', NULL),
('5', 'KI600', 'عسل حلبه', '1', '4', '2025-12-11 02:12:31', NULL),
('6', 'KI397', 'تيست', '1', '4', '2025-12-15 01:13:05', NULL);
/*!40000 ALTER TABLE `honey_types` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `inventory_movements`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `inventory_movements`;
CREATE TABLE `inventory_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `type` enum('in','out','adjustment','transfer') NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `quantity_before` decimal(10,2) NOT NULL,
  `quantity_after` decimal(10,2) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL COMMENT 'production, sales, purchase, etc.',
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `reference` (`reference_type`,`reference_id`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_movements_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
INSERT INTO `inventory_movements` (`id`, `product_id`, `warehouse_id`, `type`, `quantity`, `quantity_before`, `quantity_after`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES
('1', '3', '1', 'out', '40.00', '50.00', '10.00', 'warehouse_transfer', '1', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:39:46'),
('2', '3', '2', 'in', '40.00', '0.00', '0.00', 'warehouse_transfer', '1', 'نقل إلى مخزن سيارة - تشغيلة 251210-990828', '1', '2025-12-09 19:39:46'),
('3', '3', '2', 'out', '10.00', '0.00', '-10.00', 'warehouse_transfer', '2', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:40:45'),
('4', '3', '1', 'in', '10.00', '20.00', '30.00', 'warehouse_transfer', '2', 'نقل من مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:40:45'),
('5', '3', '2', 'out', '10.00', '0.00', '-10.00', 'warehouse_transfer', '3', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:48:20'),
('6', '3', '1', 'in', '10.00', '40.00', '50.00', 'warehouse_transfer', '3', 'نقل من مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:48:20'),
('7', '3', '2', 'out', '20.00', '0.00', '-20.00', 'warehouse_transfer', '4', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:57:37'),
('8', '3', '1', 'in', '20.00', '50.00', '70.00', 'warehouse_transfer', '4', 'نقل من مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-09 19:57:37'),
('9', '4', '1', 'out', '10.00', '20.00', '10.00', 'warehouse_transfer', '5', 'نقل إلى مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 19:58:19'),
('10', '4', '2', 'in', '10.00', '0.00', '0.00', 'warehouse_transfer', '5', 'نقل إلى مخزن سيارة - تشغيلة 251210-921358', '1', '2025-12-09 19:58:19'),
('11', '4', '2', 'out', '5.00', '0.00', '-5.00', 'warehouse_transfer', '6', 'نقل إلى مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 19:58:32'),
('12', '4', '1', 'in', '5.00', '10.00', '15.00', 'warehouse_transfer', '6', 'نقل من مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 19:58:32'),
('13', '4', '1', 'out', '15.00', '15.00', '0.00', 'warehouse_transfer', '7', 'نقل إلى مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 19:58:49'),
('14', '4', '2', 'in', '15.00', '5.00', '5.00', 'warehouse_transfer', '7', 'نقل إلى مخزن سيارة - تشغيلة 251210-921358', '1', '2025-12-09 19:58:49'),
('15', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '1', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0001', '17', '2025-12-09 20:03:22'),
('16', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '2', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0002', '17', '2025-12-09 20:40:25'),
('17', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '3', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0003', '17', '2025-12-09 20:50:35'),
('18', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '4', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0004', '17', '2025-12-09 20:51:59'),
('19', '7', '1', 'out', '50.00', '100.00', '50.00', 'warehouse_transfer', '8', 'نقل إلى مخزن آخر', '1', '2025-12-09 20:57:39'),
('20', '7', '2', 'in', '50.00', '50.00', '50.00', 'warehouse_transfer', '8', 'نقل إلى مخزن سيارة', '1', '2025-12-09 20:57:39'),
('21', '7', '2', 'out', '10.00', '0.00', '-10.00', 'warehouse_transfer', '9', 'نقل إلى مخزن آخر', '1', '2025-12-09 20:57:56'),
('22', '7', '1', 'in', '10.00', '60.00', '70.00', 'warehouse_transfer', '9', 'نقل من مخزن آخر', '1', '2025-12-09 20:57:56'),
('23', '7', '2', 'out', '10.00', '0.00', '-10.00', 'warehouse_transfer', '10', 'نقل إلى مخزن آخر', '1', '2025-12-09 21:06:17'),
('24', '7', '1', 'in', '10.00', '80.00', '90.00', 'warehouse_transfer', '10', 'نقل من مخزن آخر', '1', '2025-12-09 21:06:17'),
('25', '7', '2', 'out', '10.00', '0.00', '-10.00', 'warehouse_transfer', '11', 'نقل إلى مخزن آخر', '1', '2025-12-09 21:07:36'),
('26', '7', '1', 'in', '10.00', '100.00', '110.00', 'warehouse_transfer', '11', 'نقل من مخزن آخر', '1', '2025-12-09 21:07:36'),
('27', '4', '2', 'out', '1.00', '0.00', '-1.00', 'warehouse_transfer', '12', 'نقل إلى مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 21:09:14'),
('28', '4', '1', 'in', '1.00', '0.00', '1.00', 'warehouse_transfer', '12', 'نقل من مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 21:09:14'),
('29', '4', '1', 'out', '1.00', '1.00', '0.00', 'warehouse_transfer', '13', 'نقل إلى مخزن آخر - تشغيلة 251210-921358', '1', '2025-12-09 21:09:31'),
('30', '4', '2', 'in', '1.00', '5.00', '5.00', 'warehouse_transfer', '13', 'نقل إلى مخزن سيارة - تشغيلة 251210-921358', '1', '2025-12-09 21:09:31'),
('31', '7', '2', 'out', '10.00', '0.00', '-10.00', 'warehouse_transfer', '14', 'نقل إلى مخزن آخر', '1', '2025-12-09 21:16:41'),
('32', '7', '1', 'in', '10.00', '110.00', '120.00', 'warehouse_transfer', '14', 'نقل من مخزن آخر', '1', '2025-12-09 21:16:41'),
('33', '7', '1', 'out', '120.00', '120.00', '0.00', 'warehouse_transfer', '15', 'نقل إلى مخزن آخر', '1', '2025-12-09 21:16:55'),
('34', '7', '2', 'in', '120.00', '0.00', '0.00', 'warehouse_transfer', '15', 'نقل إلى مخزن سيارة', '1', '2025-12-09 21:16:55'),
('35', '7', '2', 'out', '110.00', '0.00', '-110.00', 'warehouse_transfer', '16', 'نقل إلى مخزن آخر', '1', '2025-12-09 21:17:14'),
('36', '7', '1', 'in', '110.00', '0.00', '110.00', 'warehouse_transfer', '16', 'نقل من مخزن آخر', '1', '2025-12-09 21:17:14'),
('37', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '5', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0005', '10', '2025-12-09 22:26:09'),
('38', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '6', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0006', '10', '2025-12-09 22:26:54'),
('39', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '7', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0007', '10', '2025-12-09 22:28:53'),
('40', '4', '1', 'in', '1.00', '1.00', '2.00', 'return', '2', 'إرجاع منتج من مرتجع رقم: RET-202512-0002 إلى المخزن الرئيسي', '1', '2025-12-09 22:34:15'),
('41', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '8', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0008', '10', '2025-12-09 23:06:05'),
('42', '4', '1', 'in', '1.00', '2.00', '3.00', 'return', '3', 'إرجاع منتج من مرتجع رقم: RET-202512-0003 إلى المخزن الرئيسي', '1', '2025-12-09 23:06:51'),
('43', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '9', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0009', '10', '2025-12-09 23:12:09'),
('44', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '10', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0010', '10', '2025-12-09 23:12:34'),
('45', '7', '1', 'in', '1.00', '111.00', '112.00', 'return', '4', 'إرجاع منتج من مرتجع رقم: RET-202512-0004 إلى المخزن الرئيسي', '1', '2025-12-09 23:16:00'),
('46', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '11', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0011', '10', '2025-12-09 23:17:54'),
('47', '7', '1', 'in', '1.00', '113.00', '114.00', 'return', '5', 'إرجاع منتج من مرتجع رقم: RET-202512-0005 إلى المخزن الرئيسي', '1', '2025-12-09 23:18:37'),
('48', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '12', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0012', '10', '2025-12-09 23:22:19'),
('49', '7', '1', 'in', '1.00', '115.00', '116.00', 'return', '6', 'إرجاع منتج من مرتجع رقم: RET-202512-0006 إلى المخزن الرئيسي', '1', '2025-12-09 23:24:00'),
('50', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '13', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0013', '10', '2025-12-09 23:35:34'),
('51', '7', '1', 'out', '1.00', '100.00', '99.00', 'shipping_order', '1', 'تسليم طلب شحن #SHIP-202512-0001 لشركة الشحن', '1', '2025-12-09 23:41:53'),
('52', '7', '1', 'in', '1.00', '99.00', '100.00', 'shipping_order_cancelled', '1', 'إرجاع منتجات من طلب شحن ملغي #1', '1', '2025-12-09 23:42:03'),
('53', '7', '1', 'out', '1.00', '100.00', '99.00', 'shipping_order', '2', 'تسليم طلب شحن #SHIP-202512-0002 لشركة الشحن', '1', '2025-12-09 23:42:17'),
('54', '7', '1', 'in', '1.00', '99.00', '100.00', 'local_return', '1', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0001', '1', '2025-12-09 23:42:48'),
('55', '2', '1', 'out', '1.00', '2.00', '1.00', 'shipping_order', '3', 'تسليم طلب شحن #SHIP-202512-0003 لشركة الشحن', '1', '2025-12-09 23:43:09'),
('56', '4', '1', 'in', '1.00', '1.00', '2.00', 'shipping_order_cancelled', '3', 'إرجاع منتجات من طلب شحن ملغي #3', '1', '2025-12-09 23:43:18'),
('57', '2', '1', 'out', '1.00', '2.00', '1.00', 'shipping_order', '4', 'تسليم طلب شحن #SHIP-202512-0004 لشركة الشحن', '1', '2025-12-09 23:43:27'),
('58', '4', '1', 'in', '1.00', '1.00', '2.00', 'local_return', '2', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0002 - رقم التشغيلة: 251210-921358', '1', '2025-12-09 23:43:49'),
('59', '7', '1', 'out', '1.00', '100.00', '99.00', 'sales', '18', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0018', '1', '2025-12-09 23:47:36'),
('60', '7', '1', 'in', '1.00', '99.00', '100.00', 'local_return', '3', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0003', '1', '2025-12-09 23:48:14'),
('61', '4', '1', 'out', '1.00', '2.00', '1.00', 'sales', '19', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0019', '1', '2025-12-09 23:48:38'),
('62', '4', '1', 'in', '1.00', '1.00', '2.00', 'local_return', '4', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0004 - رقم التشغيلة: 251210-921358', '1', '2025-12-09 23:50:15'),
('63', '7', '1', 'out', '1.00', '100.00', '99.00', 'sales', '20', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0020', '1', '2025-12-09 23:54:06'),
('64', '7', '1', 'out', '1.00', '99.00', '98.00', 'sales', '21', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0021', '1', '2025-12-09 23:54:50'),
('65', '7', '1', 'out', '1.00', '98.00', '97.00', 'sales', '22', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0022', '1', '2025-12-09 23:56:21'),
('66', '7', '1', 'out', '1.00', '97.00', '96.00', 'sales', '23', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0023', '1', '2025-12-10 00:25:10'),
('67', '7', '1', 'out', '1.00', '96.00', '95.00', 'sales', '24', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0024', '1', '2025-12-10 00:25:40'),
('68', '7', '1', 'in', '1.00', '96.00', '97.00', 'return', '7', 'إرجاع منتج من مرتجع رقم: RET-202512-0007 إلى المخزن الرئيسي', '1', '2025-12-10 00:26:07'),
('69', '7', '2', 'in', '1.00', '0.00', '1.00', 'return', '8', 'إرجاع منتج من مرتجع رقم: RET-202512-0008', '1', '2025-12-10 00:35:53'),
('70', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '25', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0025', '10', '2025-12-10 00:37:03'),
('71', '7', '2', 'in', '1.00', '0.00', '1.00', 'return', '9', 'إرجاع منتج من مرتجع رقم: RET-202512-0009', '1', '2025-12-10 00:38:23'),
('72', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '26', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0026', '10', '2025-12-10 00:38:57'),
('73', '4', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '27', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0027', '18', '2025-12-10 00:50:34'),
('74', '7', '2', 'out', '1.00', '0.00', '-1.00', 'sales', '28', 'بيع من نقطة بيع المندوب - فاتورة INV-202512-0028', '18', '2025-12-10 00:51:18'),
('75', '7', '1', 'in', '1.00', '97.00', '98.00', 'local_return', '5', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0005', '2', '2025-12-10 06:44:59'),
('76', '7', '1', 'in', '1.00', '98.00', '99.00', 'local_return', '6', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0006', '2', '2025-12-10 06:45:18'),
('77', '7', '1', 'in', '1.00', '99.00', '100.00', 'local_return', '7', 'إرجاع من عميل محلي - رقم المرتجع: LOC-RET-202512-0007', '2', '2025-12-10 06:45:28'),
('78', '3', '1', 'out', '35.00', '70.00', '35.00', 'warehouse_transfer', '17', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-10 06:51:28'),
('79', '3', '3', 'in', '35.00', '40.00', '40.00', 'warehouse_transfer', '17', 'نقل إلى مخزن سيارة - تشغيلة 251210-990828', '1', '2025-12-10 06:51:28'),
('80', '3', '3', 'out', '20.00', '0.00', '-20.00', 'warehouse_transfer', '18', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-10 06:52:32'),
('81', '3', '1', 'in', '20.00', '35.00', '55.00', 'warehouse_transfer', '18', 'نقل من مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-10 06:52:32'),
('82', '3', '3', 'out', '5.00', '0.00', '-5.00', 'warehouse_transfer', '19', 'نقل إلى مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-10 06:54:24'),
('83', '3', '1', 'in', '5.00', '55.00', '60.00', 'warehouse_transfer', '19', 'نقل من مخزن آخر - تشغيلة 251210-990828', '1', '2025-12-10 06:54:24'),
('84', '10', '1', 'out', '1.00', '100.00', '99.00', 'sales', '29', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0029', '1', '2025-12-10 06:57:04'),
('85', '7', '1', 'out', '1.00', '100.00', '99.00', 'sales', '29', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0029', '1', '2025-12-10 06:57:04'),
('86', '9', '1', 'out', '20.00', '100.00', '80.00', 'shipping_order', '5', 'تسليم طلب شحن #SHIP-202512-0005 لشركة الشحن', '1', '2025-12-10 07:00:17'),
('87', '7', '1', 'out', '9.00', '99.00', '90.00', 'shipping_order', '5', 'تسليم طلب شحن #SHIP-202512-0005 لشركة الشحن', '1', '2025-12-10 07:00:17'),
('88', '9', '1', 'in', '20.00', '80.00', '100.00', 'shipping_order_cancelled', '5', 'إرجاع منتجات من طلب شحن ملغي #5', '1', '2025-12-10 07:01:07'),
('89', '7', '1', 'in', '9.00', '90.00', '99.00', 'shipping_order_cancelled', '5', 'إرجاع منتجات من طلب شحن ملغي #5', '1', '2025-12-10 07:01:07'),
('90', '9', '1', 'out', '20.00', '100.00', '80.00', 'shipping_order', '6', 'تسليم طلب شحن #SHIP-202512-0006 لشركة الشحن', '1', '2025-12-10 07:01:26'),
('91', '4', '1', 'out', '12.00', '12.00', '0.00', 'sales', '32', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0032', '1', '2025-12-11 02:37:47'),
('92', '4', '1', 'out', '6.00', '6.00', '0.00', 'sales', '32', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0032', '1', '2025-12-11 02:37:47'),
('93', '4', '1', 'out', '6.00', '6.00', '0.00', 'sales', '32', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0032', '1', '2025-12-11 02:37:47'),
('94', '4', '1', 'out', '6.00', '6.00', '0.00', 'sales', '32', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0032', '1', '2025-12-11 02:37:47'),
('95', '4', '1', 'out', '2.00', '2.00', '0.00', 'sales', '32', 'بيع من نقطة بيع المدير - فاتورة INV-202512-0032', '1', '2025-12-11 02:37:47'),
('96', '7', '1', 'out', '1.00', '11.00', '10.00', 'shipping_order', '7', 'تسليم طلب شحن #SHIP-202512-0007 لشركة الشحن', '2', '2025-12-11 05:53:26'),
('97', '7', '1', 'out', '10.00', '99.00', '89.00', 'shipping_order', '8', 'تسليم طلب شحن #SHIP-202512-0008 لشركة الشحن', '2', '2025-12-11 06:03:50'),
('98', '7', '1', 'in', '10.00', '89.00', '99.00', 'shipping_order_cancelled', '8', 'إرجاع منتجات من طلب شحن ملغي #8', '2', '2025-12-11 06:04:21'),
('99', '7', '1', 'out', '10.00', '99.00', '89.00', 'shipping_order', '9', 'تسليم طلب شحن #SHIP-202512-0009 لشركة الشحن', '2', '2025-12-11 06:05:07'),
('100', '20', '1', 'out', '10.00', '18.00', '8.00', 'warehouse_transfer', '20', 'نقل إلى مخزن آخر - تشغيلة 251211-923972', '1', '2025-12-11 08:22:49'),
('101', '20', '3', 'in', '10.00', '0.00', '0.00', 'warehouse_transfer', '20', 'نقل إلى مخزن سيارة - تشغيلة 251211-923972', '1', '2025-12-11 08:22:49'),
('102', '30', '1', 'out', '6.00', '6.00', '0.00', 'warehouse_transfer', '21', 'نقل إلى مخزن آخر - تشغيلة 251215-082617', '1', '2025-12-15 02:49:33'),
('103', '30', '3', 'in', '6.00', '0.00', '0.00', 'warehouse_transfer', '21', 'نقل إلى مخزن سيارة - تشغيلة 251215-082617', '1', '2025-12-15 02:49:33'),
('104', '30', '3', 'out', '6.00', '0.00', '-6.00', 'warehouse_transfer', '22', 'نقل إلى مخزن آخر - تشغيلة 251215-082617', '1', '2025-12-15 02:51:20'),
('105', '30', '1', 'in', '6.00', '0.00', '6.00', 'warehouse_transfer', '22', 'نقل من مخزن آخر - تشغيلة 251215-082617', '1', '2025-12-15 02:51:20'),
('106', '30', '1', 'out', '6.00', '6.00', '0.00', 'warehouse_transfer', '23', 'نقل إلى مخزن آخر - تشغيلة 251215-082617', '1', '2025-12-15 03:38:53'),
('107', '30', '2', 'in', '6.00', '0.00', '0.00', 'warehouse_transfer', '23', 'نقل إلى مخزن سيارة - تشغيلة 251215-082617', '1', '2025-12-15 03:38:53');
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `invoice_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
INSERT INTO `invoice_items` (`id`, `invoice_id`, `product_id`, `description`, `quantity`, `unit_price`, `total_price`, `created_at`) VALUES
('1', '1', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 20:03:22'),
('2', '2', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 20:40:25'),
('3', '3', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 20:50:35'),
('4', '4', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 20:51:59'),
('5', '5', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 22:26:09'),
('6', '6', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 22:26:54'),
('7', '7', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 22:28:53'),
('8', '8', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 23:06:05'),
('9', '9', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:12:09'),
('10', '10', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:12:34'),
('11', '11', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:17:54'),
('12', '12', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:22:19'),
('13', '13', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:35:34'),
('14', '14', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:41:53'),
('15', '15', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:42:17'),
('16', '16', '4', 'TEST (251210-921358)', '1.00', '1000.00', '1000.00', '2025-12-09 23:43:09'),
('17', '17', '4', 'TEST (251210-921358)', '1.00', '1000.00', '1000.00', '2025-12-09 23:43:27'),
('18', '18', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:47:36'),
('19', '19', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-09 23:48:38'),
('20', '20', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:54:06'),
('21', '21', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:54:50'),
('22', '22', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-09 23:56:21'),
('23', '23', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-10 00:25:10'),
('24', '24', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-10 00:25:40'),
('25', '25', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-10 00:37:03'),
('26', '26', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-10 00:38:57'),
('27', '27', '4', 'TEST', '1.00', '1000.00', '1000.00', '2025-12-10 00:50:34'),
('28', '28', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-10 00:51:18'),
('29', '29', '10', 'صابون صغير', '1.00', '500.00', '500.00', '2025-12-10 06:57:04'),
('30', '29', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', '2025-12-10 06:57:04'),
('31', '30', '9', 'صابون صغير', '20.00', '500.00', '10000.00', '2025-12-10 07:00:17'),
('32', '30', '7', 'صابون كبير', '9.00', '1000.00', '9000.00', '2025-12-10 07:00:17'),
('33', '31', '9', 'صابون صغير', '20.00', '500.00', '10000.00', '2025-12-10 07:01:26'),
('34', '32', '4', 'TEST', '12.00', '1000.00', '12000.00', '2025-12-11 02:37:47'),
('35', '32', '4', 'TEST', '6.00', '1000.00', '6000.00', '2025-12-11 02:37:47'),
('36', '32', '4', 'TEST', '6.00', '1000.00', '6000.00', '2025-12-11 02:37:47'),
('37', '32', '4', 'TEST', '6.00', '1000.00', '6000.00', '2025-12-11 02:37:47'),
('38', '32', '4', 'TEST', '2.00', '1000.00', '2000.00', '2025-12-11 02:37:47'),
('39', '33', '13', '11 (251211-219169)', '1.00', '1000.00', '1000.00', '2025-12-11 05:53:26'),
('40', '34', '7', 'صابون كبير', '10.00', '1000.00', '10000.00', '2025-12-11 06:03:50'),
('41', '35', '7', 'صابون كبير', '10.00', '1000.00', '10000.00', '2025-12-11 06:05:07');
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `invoices`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `remaining_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('draft','sent','paid','partial','overdue','cancelled') DEFAULT 'draft',
  `paid_from_credit` tinyint(1) DEFAULT 0,
  `credit_used` decimal(15,2) DEFAULT 0.00 COMMENT 'المبلغ المخصوم من الرصيد الدائن',
  `amount_added_to_sales` decimal(15,2) DEFAULT NULL COMMENT 'المبلغ المضاف إلى خزنة المندوب (بعد خصم الرصيد الدائن)',
  `created_from_pos` tinyint(1) DEFAULT 0 COMMENT 'تم إنشاء الفاتورة من نقطة البيع',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `date` (`date`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` (`id`, `invoice_number`, `customer_id`, `sales_rep_id`, `date`, `due_date`, `subtotal`, `tax_rate`, `tax_amount`, `discount_amount`, `total_amount`, `paid_amount`, `remaining_amount`, `status`, `paid_from_credit`, `credit_used`, `amount_added_to_sales`, `created_from_pos`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'INV-202512-0001', '1', '17', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '17', '2025-12-09 20:03:22', NULL),
('2', 'INV-202512-0002', '2', '17', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '17', '2025-12-09 20:40:25', NULL),
('3', 'INV-202512-0003', '2', '17', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '500.00', '500.00', 'partial', '0', '0.00', '1000.00', '1', '', '17', '2025-12-09 20:50:35', '2025-12-09 20:50:35'),
('4', 'INV-202512-0004', '3', '17', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', '0.00', '1', '', '17', '2025-12-09 20:51:59', '2025-12-09 20:51:59'),
('5', 'INV-202512-0005', '5', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 22:26:09', '2025-12-09 22:26:09'),
('6', 'INV-202512-0006', '5', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '500.00', '500.00', 'partial', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 22:26:54', '2025-12-09 22:26:54'),
('7', 'INV-202512-0007', '5', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 22:28:53', '2025-12-09 22:28:53'),
('8', 'INV-202512-0008', '6', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 23:06:05', '2025-12-09 23:06:05'),
('9', 'INV-202512-0009', '8', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 23:12:09', '2025-12-09 23:12:09'),
('10', 'INV-202512-0010', '8', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 23:12:34', '2025-12-09 23:12:34'),
('11', 'INV-202512-0011', '9', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '0', '0.00', '1000.00', '1', '', '10', '2025-12-09 23:17:54', '2025-12-09 23:17:54'),
('12', 'INV-202512-0012', '9', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '1', '1000.00', '0.00', '1', '', '10', '2025-12-09 23:22:19', '2025-12-09 23:22:19'),
('13', 'INV-202512-0013', '9', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '1', '1000.00', '0.00', '1', '', '10', '2025-12-09 23:35:34', '2025-12-09 23:35:34'),
('14', 'INV-202512-0014', '1', NULL, '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'cancelled', '0', '0.00', NULL, '0', '', '1', '2025-12-09 23:41:53', '2025-12-09 23:42:03'),
('15', 'INV-202512-0015', '1', NULL, '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', NULL, '0', '', '1', '2025-12-09 23:42:17', '2025-12-09 23:42:29'),
('16', 'INV-202512-0016', '1', NULL, '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'cancelled', '0', '0.00', NULL, '0', '', '1', '2025-12-09 23:43:09', '2025-12-09 23:43:18'),
('17', 'INV-202512-0017', '1', NULL, '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', NULL, '0', '', '1', '2025-12-09 23:43:27', '2025-12-09 23:43:35'),
('18', 'INV-202512-0018', '10', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-09 23:47:36', NULL),
('19', 'INV-202512-0019', '10', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-09 23:48:38', NULL),
('20', 'INV-202512-0020', '11', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-09 23:54:06', NULL),
('21', 'INV-202512-0021', '10', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-09 23:54:50', NULL),
('22', 'INV-202512-0022', '12', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-09 23:56:21', NULL),
('23', 'INV-202512-0023', '12', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-10 00:25:10', NULL),
('24', 'INV-202512-0024', '12', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-10 00:25:40', NULL),
('25', 'INV-202512-0025', '5', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '0', '0.00', '1000.00', '1', '', '10', '2025-12-10 00:37:03', '2025-12-10 00:37:03'),
('26', 'INV-202512-0026', '8', '10', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '0', '0.00', '1000.00', '1', '', '10', '2025-12-10 00:38:57', '2025-12-10 00:38:57'),
('27', 'INV-202512-0027', '13', '18', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '0', '0.00', '0.00', '1', '', '18', '2025-12-10 00:50:34', '2025-12-10 00:50:34'),
('28', 'INV-202512-0028', '13', '18', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '500.00', '500.00', 'partial', '0', '0.00', '1000.00', '1', '', '18', '2025-12-10 00:51:18', '2025-12-10 00:51:18'),
('29', 'INV-202512-0029', '16', '1', '2025-12-10', NULL, '1500.00', '0.00', '0.00', '0.00', '1500.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-10 06:57:04', NULL),
('30', 'INV-202512-0030', '8', NULL, '2025-12-10', NULL, '19000.00', '0.00', '0.00', '0.00', '19000.00', '0.00', '19000.00', 'cancelled', '0', '0.00', NULL, '0', '', '1', '2025-12-10 07:00:17', '2025-12-10 07:01:07'),
('31', 'INV-202512-0031', '8', NULL, '2025-12-10', NULL, '10000.00', '0.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', 'sent', '0', '0.00', NULL, '0', '', '1', '2025-12-10 07:01:26', '2025-12-11 05:54:41'),
('32', 'INV-202512-0032', '10', '1', '2025-12-11', NULL, '32000.00', '0.00', '0.00', '0.00', '32000.00', '0.00', '0.00', 'draft', '0', '0.00', NULL, '1', '', '1', '2025-12-11 02:37:47', NULL),
('33', 'INV-202512-0033', '5', NULL, '2025-12-11', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '0', '0.00', NULL, '0', '', '2', '2025-12-11 05:53:26', '2025-12-11 05:54:21'),
('34', 'INV-202512-0034', '4', NULL, '2025-12-11', NULL, '10000.00', '0.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', 'cancelled', '0', '0.00', NULL, '0', '', '2', '2025-12-11 06:03:50', '2025-12-11 06:04:21'),
('35', 'INV-202512-0035', '4', NULL, '2025-12-11', NULL, '10000.00', '0.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', 'sent', '0', '0.00', NULL, '0', '', '2', '2025-12-11 06:05:07', '2025-12-11 06:05:07');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `local_collections`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `local_collections`;
CREATE TABLE `local_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_number` varchar(50) DEFAULT NULL COMMENT 'رقم التحصيل',
  `customer_id` int(11) NOT NULL COMMENT 'معرف العميل المحلي',
  `amount` decimal(15,2) NOT NULL COMMENT 'المبلغ المحصل',
  `date` date NOT NULL COMMENT 'تاريخ التحصيل',
  `payment_method` enum('cash','bank','cheque','other') DEFAULT 'cash' COMMENT 'طريقة الدفع',
  `reference_number` varchar(50) DEFAULT NULL COMMENT 'رقم مرجعي',
  `notes` text DEFAULT NULL COMMENT 'ملاحظات',
  `collected_by` int(11) NOT NULL COMMENT 'من قام بالتحصيل',
  `status` enum('pending','approved','rejected') DEFAULT 'pending' COMMENT 'حالة التحصيل',
  `approved_by` int(11) DEFAULT NULL COMMENT 'من وافق على التحصيل',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT 'تاريخ الموافقة',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `collection_number` (`collection_number`),
  KEY `customer_id` (`customer_id`),
  KEY `collected_by` (`collected_by`),
  KEY `approved_by` (`approved_by`),
  KEY `date` (`date`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول التحصيلات للعملاء المحليين';

LOCK TABLES `local_collections` WRITE;
/*!40000 ALTER TABLE `local_collections` DISABLE KEYS */;
INSERT INTO `local_collections` (`id`, `collection_number`, `customer_id`, `amount`, `date`, `payment_method`, `reference_number`, `notes`, `collected_by`, `status`, `approved_by`, `approved_at`, `created_at`, `updated_at`) VALUES
('1', 'LOC-COL-202512-0001', '2', '1000.00', '2025-12-10', 'cash', NULL, 'تحصيل من صفحة العملاء المحليين', '1', 'approved', NULL, NULL, '2025-12-10 00:18:37', NULL),
('2', 'LOC-COL-202512-0002', '5', '1000.00', '2025-12-11', 'cash', NULL, 'تحصيل من صفحة العملاء المحليين', '2', 'approved', NULL, NULL, '2025-12-11 05:55:23', NULL);
/*!40000 ALTER TABLE `local_collections` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `local_customers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `local_customers`;
CREATE TABLE `local_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00 COMMENT 'رصيد العميل (موجب = دين، سالب = رصيد دائن)',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) NOT NULL COMMENT 'المستخدم الذي أضاف العميل',
  `latitude` decimal(10,8) DEFAULT NULL COMMENT 'خط العرض',
  `longitude` decimal(11,8) DEFAULT NULL COMMENT 'خط الطول',
  `location_captured_at` datetime DEFAULT NULL COMMENT 'تاريخ تحديد الموقع',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `name` (`name`),
  KEY `status` (`status`),
  KEY `region_id` (`region_id`),
  CONSTRAINT `local_customers_ibfk_region` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول العملاء المحليين (منفصل عن عملاء المندوبين)';

LOCK TABLES `local_customers` WRITE;
/*!40000 ALTER TABLE `local_customers` DISABLE KEYS */;
INSERT INTO `local_customers` (`id`, `name`, `phone`, `address`, `region_id`, `balance`, `status`, `created_by`, `latitude`, `longitude`, `location_captured_at`, `created_at`, `updated_at`) VALUES
('1', '1', '0100100100', NULL, '1', '0.00', 'active', '1', '31.09893468', '29.77279640', '2025-12-11 10:18:58', '2025-12-09 23:41:22', '2025-12-11 00:18:58'),
('2', '2', NULL, NULL, '2', '0.00', 'active', '1', NULL, NULL, NULL, '2025-12-09 23:54:06', '2025-12-11 00:37:28'),
('3', '3', NULL, NULL, '1', '-1000.00', 'active', '1', NULL, NULL, NULL, '2025-12-09 23:56:21', '2025-12-10 21:54:22'),
('4', 'عمر', NULL, NULL, NULL, '0.00', 'active', '1', '30.04441960', '31.23571160', '2025-12-10 14:52:51', '2025-12-10 04:52:08', '2025-12-10 07:04:08'),
('5', 'احمد', NULL, NULL, NULL, '0.00', 'active', '1', NULL, NULL, NULL, '2025-12-10 04:54:44', '2025-12-11 05:55:23'),
('6', 'احمد محمد', '010000000', NULL, NULL, '500.00', 'active', '2', '30.04441960', '31.23571160', '2025-12-10 16:42:39', '2025-12-10 06:41:40', '2025-12-10 06:42:39'),
('7', '12', '.02221', '515', NULL, '1350.00', 'active', '1', NULL, NULL, NULL, '2025-12-10 06:57:04', NULL),
('8', 'شحن 1', NULL, NULL, NULL, '10000.00', 'active', '1', NULL, NULL, NULL, '2025-12-10 06:59:33', '2025-12-11 05:54:40'),
('9', 'احمد مدين', NULL, NULL, NULL, '-1000.00', 'active', '1', NULL, NULL, NULL, '2025-12-10 07:03:06', NULL);
/*!40000 ALTER TABLE `local_customers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `local_invoice_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `local_invoice_items`;
CREATE TABLE `local_invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `local_invoice_items` WRITE;
/*!40000 ALTER TABLE `local_invoice_items` DISABLE KEYS */;
INSERT INTO `local_invoice_items` (`id`, `invoice_id`, `product_id`, `description`, `quantity`, `unit_price`, `total_price`, `batch_number`, `batch_id`, `created_at`) VALUES
('1', '1', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-09 23:42:29'),
('2', '2', '4', 'TEST', '1.00', '1000.00', '1000.00', '251210-921358', '2', '2025-12-09 23:43:35'),
('3', '3', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-09 23:47:36'),
('4', '4', '4', 'TEST', '1.00', '1000.00', '1000.00', '251210-921358', '2', '2025-12-09 23:48:38'),
('5', '5', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-09 23:54:06'),
('6', '6', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-09 23:54:51'),
('7', '7', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-09 23:56:21'),
('8', '8', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-10 00:25:10'),
('9', '9', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-10 00:25:40'),
('10', '10', '10', 'صابون صغير', '1.00', '500.00', '500.00', NULL, NULL, '2025-12-10 06:57:04'),
('11', '10', '7', 'صابون كبير', '1.00', '1000.00', '1000.00', NULL, NULL, '2025-12-10 06:57:04'),
('12', '11', '4', 'TEST', '12.00', '1000.00', '12000.00', '251211-581612', '12', '2025-12-11 02:37:47'),
('13', '11', '4', 'TEST', '6.00', '1000.00', '6000.00', '251211-460851', '11', '2025-12-11 02:37:47'),
('14', '11', '4', 'TEST', '6.00', '1000.00', '6000.00', '251211-269689', '10', '2025-12-11 02:37:47'),
('15', '11', '4', 'TEST', '6.00', '1000.00', '6000.00', '251211-461225', '9', '2025-12-11 02:37:47'),
('16', '11', '4', 'TEST', '2.00', '1000.00', '2000.00', '251210-921358', '2', '2025-12-11 02:37:47'),
('17', '12', '13', '11', '1.00', '1000.00', '1000.00', '251211-219169', '7', '2025-12-11 05:54:21'),
('18', '13', '9', 'صابون صغير', '20.00', '500.00', '10000.00', NULL, NULL, '2025-12-11 05:54:41');
/*!40000 ALTER TABLE `local_invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `local_invoices`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `local_invoices`;
CREATE TABLE `local_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `remaining_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('draft','sent','paid','partial','overdue','cancelled') DEFAULT 'draft',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `local_invoices` WRITE;
/*!40000 ALTER TABLE `local_invoices` DISABLE KEYS */;
INSERT INTO `local_invoices` (`id`, `invoice_number`, `customer_id`, `date`, `due_date`, `subtotal`, `tax_rate`, `tax_amount`, `discount_amount`, `total_amount`, `paid_amount`, `remaining_amount`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'LOC-SHIP-202512-0002', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', 'طلب شحن - SHIP-202512-0002', '1', '2025-12-09 23:42:29', NULL),
('2', 'LOC-SHIP-202512-0004', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', 'طلب شحن - SHIP-202512-0004', '1', '2025-12-09 23:43:35', NULL),
('3', 'LOC-INV-202512-0018', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '1000.00', '0.00', 'paid', '', '1', '2025-12-09 23:47:36', NULL),
('4', 'LOC-INV-202512-0019', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'paid', '', '1', '2025-12-09 23:48:38', NULL),
('5', 'LOC-INV-202512-0020', '2', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '', '1', '2025-12-09 23:54:06', NULL),
('6', 'LOC-INV-202512-0021', '1', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '0.00', 'paid', '', '1', '2025-12-09 23:54:50', NULL),
('7', 'LOC-INV-202512-0022', '3', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '500.00', '500.00', 'partial', '', '1', '2025-12-09 23:56:21', NULL),
('8', 'LOC-INV-202512-0023', '3', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', '', '1', '2025-12-10 00:25:10', NULL),
('9', 'LOC-INV-202512-0024', '3', '2025-12-10', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '500.00', '500.00', 'partial', '', '1', '2025-12-10 00:25:40', NULL),
('10', 'LOC-INV-202512-0029', '7', '2025-12-10', NULL, '1500.00', '0.00', '0.00', '0.00', '1500.00', '150.00', '1350.00', 'partial', '', '1', '2025-12-10 06:57:04', NULL),
('11', 'LOC-INV-202512-0032', '1', '2025-12-11', NULL, '32000.00', '0.00', '0.00', '0.00', '32000.00', '32000.00', '0.00', 'paid', '', '1', '2025-12-11 02:37:47', NULL),
('12', 'LOC-SHIP-202512-0007', '5', '2025-12-11', NULL, '1000.00', '0.00', '0.00', '0.00', '1000.00', '0.00', '1000.00', 'sent', 'طلب شحن - SHIP-202512-0007', '2', '2025-12-11 05:54:21', NULL),
('13', 'LOC-SHIP-202512-0006', '8', '2025-12-11', NULL, '10000.00', '0.00', '0.00', '0.00', '10000.00', '0.00', '10000.00', 'sent', 'طلب شحن - SHIP-202512-0006', '2', '2025-12-11 05:54:41', NULL);
/*!40000 ALTER TABLE `local_invoices` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `local_return_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `local_return_items`;
CREATE TABLE `local_return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `invoice_item_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `local_return_items_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `local_returns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `local_return_items_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `local_invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `local_return_items_ibfk_3` FOREIGN KEY (`invoice_item_id`) REFERENCES `local_invoice_items` (`id`) ON DELETE SET NULL,
  CONSTRAINT `local_return_items_ibfk_4` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `local_return_items` WRITE;
/*!40000 ALTER TABLE `local_return_items` DISABLE KEYS */;
INSERT INTO `local_return_items` (`id`, `return_id`, `invoice_id`, `invoice_item_id`, `product_id`, `quantity`, `unit_price`, `total_price`, `notes`, `created_at`) VALUES
('1', '1', '1', '1', '7', '1.00', '1000.00', '1000.00', NULL, '2025-12-09 23:42:48'),
('2', '2', '2', '2', '4', '1.00', '1000.00', '1000.00', NULL, '2025-12-09 23:43:49'),
('3', '3', '3', '3', '7', '1.00', '1000.00', '1000.00', NULL, '2025-12-09 23:48:14'),
('4', '4', '4', '4', '4', '1.00', '1000.00', '1000.00', NULL, '2025-12-09 23:50:15'),
('5', '5', '9', '9', '7', '1.00', '1000.00', '1000.00', NULL, '2025-12-10 06:44:59'),
('6', '6', '8', '8', '7', '1.00', '1000.00', '1000.00', NULL, '2025-12-10 06:45:18'),
('7', '7', '7', '7', '7', '1.00', '1000.00', '1000.00', NULL, '2025-12-10 06:45:28');
/*!40000 ALTER TABLE `local_return_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `local_returns`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `local_returns`;
CREATE TABLE `local_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `refund_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `refund_method` enum('cash','credit') DEFAULT 'credit',
  `status` enum('pending','approved','rejected','processed','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `local_returns_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `local_customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `local_returns_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `local_returns_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `local_returns` WRITE;
/*!40000 ALTER TABLE `local_returns` DISABLE KEYS */;
INSERT INTO `local_returns` (`id`, `return_number`, `customer_id`, `return_date`, `refund_amount`, `refund_method`, `status`, `approved_by`, `approved_at`, `processed_by`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'LOC-RET-202512-0001', '1', '2025-12-10', '1000.00', 'credit', 'approved', '1', '2025-12-09 23:42:48', NULL, NULL, '1', '2025-12-09 23:42:48', NULL),
('2', 'LOC-RET-202512-0002', '1', '2025-12-10', '1000.00', 'credit', 'approved', '1', '2025-12-09 23:43:49', NULL, NULL, '1', '2025-12-09 23:43:49', NULL),
('3', 'LOC-RET-202512-0003', '1', '2025-12-10', '1000.00', 'credit', 'approved', '1', '2025-12-09 23:48:14', NULL, NULL, '1', '2025-12-09 23:48:14', NULL),
('4', 'LOC-RET-202512-0004', '1', '2025-12-10', '1000.00', 'credit', 'approved', '1', '2025-12-09 23:50:15', NULL, NULL, '1', '2025-12-09 23:50:15', NULL),
('5', 'LOC-RET-202512-0005', '3', '2025-12-10', '1000.00', 'credit', 'approved', '2', '2025-12-10 06:44:59', NULL, NULL, '2', '2025-12-10 06:44:59', NULL),
('6', 'LOC-RET-202512-0006', '3', '2025-12-10', '1000.00', 'credit', 'approved', '2', '2025-12-10 06:45:18', NULL, NULL, '2', '2025-12-10 06:45:18', NULL),
('7', 'LOC-RET-202512-0007', '3', '2025-12-10', '1000.00', 'credit', 'approved', '2', '2025-12-10 06:45:28', NULL, NULL, '2', '2025-12-10 06:45:28', NULL);
/*!40000 ALTER TABLE `local_returns` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `login_attempts`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) DEFAULT 0,
  `failure_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `username` (`username`),
  KEY `created_at` (`created_at`),
  KEY `success` (`success`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` (`id`, `username`, `ip_address`, `user_agent`, `success`, `failure_reason`, `created_at`) VALUES
('113', 'p', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:03:48'),
('114', 'admin', '105.93.74.211', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '1', NULL, '2025-12-11 07:09:43'),
('115', 'p', '45.108.2.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:10:53'),
('116', 'p1', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '0', 'مستخدم غير موجود', '2025-12-11 07:13:34'),
('117', 'p1', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '0', 'كلمة مرور خاطئة', '2025-12-11 07:13:34'),
('118', 'p2', '45.108.2.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:15:07'),
('119', 'p3', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '0', 'كلمة مرور خاطئة', '2025-12-11 07:18:29'),
('120', 'p3', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '0', 'كلمة مرور خاطئة', '2025-12-11 07:18:29'),
('121', 'p3', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '0', 'كلمة مرور خاطئة', '2025-12-11 07:18:56'),
('122', 'p3', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '0', 'كلمة مرور خاطئة', '2025-12-11 07:18:56'),
('123', 'p3', '45.108.149.194', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:19:07'),
('124', 'p', '41.40.198.232', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:20:56'),
('125', 'p3', '102.12.101.96', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:22:27'),
('126', 'admin', '105.93.74.211', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '1', NULL, '2025-12-11 07:29:31'),
('127', 'p', '102.12.101.96', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36', '1', NULL, '2025-12-11 07:40:11'),
('128', 'p', '105.93.74.211', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '1', NULL, '2025-12-11 08:17:13'),
('129', 'admin', '41.199.8.175', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '1', NULL, '2025-12-11 16:08:10'),
('130', 'admin', '41.199.8.175', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '1', NULL, '2025-12-11 16:16:17'),
('131', 'p', '41.199.8.175', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '1', NULL, '2025-12-11 16:27:15'),
('132', 'admin', '41.199.8.175', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '1', NULL, '2025-12-11 16:47:44'),
('133', 'admin', '41.199.8.175', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '1', NULL, '2025-12-11 16:55:25'),
('134', 'admin', '197.197.142.163', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.1 Safari/605.1.15', '1', NULL, '2025-12-12 12:20:31'),
('135', 'admin', '62.114.163.58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '1', NULL, '2025-12-13 04:09:27'),
('136', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '1', NULL, '2025-12-14 12:40:28'),
('137', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 12:51:40'),
('138', 'p2', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 12:56:00'),
('139', 'p3', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 12:56:37'),
('140', 'p3', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 12:56:45'),
('141', 'p3', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 12:58:00'),
('142', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 13:02:03'),
('143', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 13:16:37'),
('144', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 13:17:11'),
('145', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '1', NULL, '2025-12-14 13:18:13'),
('146', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '1', NULL, '2025-12-14 13:19:32'),
('147', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 13:23:39'),
('148', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '1', NULL, '2025-12-14 13:27:38'),
('149', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '1', NULL, '2025-12-14 13:28:03'),
('150', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-14 14:51:20'),
('151', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '1', NULL, '2025-12-14 14:56:53'),
('152', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '1', NULL, '2025-12-14 15:16:19'),
('153', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', '1', NULL, '2025-12-14 15:22:33'),
('154', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '1', NULL, '2025-12-14 15:30:06'),
('155', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '1', NULL, '2025-12-15 01:00:39'),
('156', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0', '1', NULL, '2025-12-15 01:13:57'),
('157', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-15 02:01:51'),
('158', 'p', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-15 18:12:54'),
('159', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-15 18:29:02'),
('160', 'a', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '1', NULL, '2025-12-16 01:03:44'),
('161', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-16 01:04:24'),
('162', 'a', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '1', NULL, '2025-12-16 01:52:06');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `message_reads`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `message_reads`;
CREATE TABLE `message_reads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `message_reads_unique` (`message_id`,`user_id`),
  KEY `message_reads_user_idx` (`user_id`),
  CONSTRAINT `message_reads_message_fk` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_reads_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `message_reads` WRITE;
/*!40000 ALTER TABLE `message_reads` DISABLE KEYS */;
INSERT INTO `message_reads` (`id`, `message_id`, `user_id`, `read_at`) VALUES
('1', '1', '1', '2025-12-10 03:55:19'),
('2', '1', '4', '2025-12-15 17:53:56'),
('3', '2', '4', '2025-12-10 03:55:49'),
('4', '2', '1', '2025-12-15 18:02:03'),
('13', '1', '2', '2025-12-11 18:06:02'),
('14', '2', '2', '2025-12-11 18:06:02'),
('15', '3', '2', '2025-12-10 11:50:42'),
('16', '3', '1', '2025-12-15 18:02:03'),
('17', '4', '1', '2025-12-10 11:50:51'),
('18', '4', '2', '2025-12-10 11:50:53'),
('21', '1', '19', '2025-12-10 13:24:34'),
('22', '2', '19', '2025-12-10 13:24:34'),
('23', '3', '19', '2025-12-10 13:24:34'),
('29', '5', '19', '2025-12-10 13:23:39'),
('32', '5', '2', '2025-12-11 18:06:02'),
('33', '6', '2', '2025-12-10 13:23:59'),
('34', '6', '19', '2025-12-10 13:24:21'),
('47', '5', '1', '2025-12-15 18:02:03'),
('60', '7', '2', '2025-12-11 16:17:22'),
('62', '3', '4', '2025-12-15 17:53:56'),
('63', '5', '4', '2025-12-15 17:53:56'),
('64', '7', '4', '2025-12-15 17:53:56'),
('68', '7', '1', '2025-12-15 18:02:03'),
('73', '8', '1', '2025-12-11 17:10:16'),
('74', '9', '1', '2025-12-11 17:10:31'),
('79', '8', '4', '2025-12-15 17:53:56'),
('80', '9', '4', '2025-12-15 17:53:56'),
('81', '10', '4', '2025-12-11 17:11:16'),
('82', '10', '1', '2025-12-15 18:02:03'),
('83', '1', '16', '2025-12-11 17:23:22'),
('84', '2', '16', '2025-12-11 17:23:22'),
('85', '3', '16', '2025-12-11 17:23:22'),
('86', '5', '16', '2025-12-11 17:23:22'),
('87', '7', '16', '2025-12-11 17:23:22'),
('88', '8', '16', '2025-12-11 17:23:22'),
('89', '9', '16', '2025-12-11 17:23:22'),
('90', '10', '16', '2025-12-11 17:23:22'),
('100', '8', '2', '2025-12-11 18:06:02'),
('101', '9', '2', '2025-12-11 18:06:02'),
('102', '10', '2', '2025-12-11 18:06:02');
/*!40000 ALTER TABLE `message_reads` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `messages`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message_text` longtext NOT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `edited` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `read_by_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_idx` (`user_id`),
  KEY `messages_reply_to_idx` (`reply_to`),
  CONSTRAINT `messages_reply_fk` FOREIGN KEY (`reply_to`) REFERENCES `messages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `messages_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` (`id`, `user_id`, `message_text`, `reply_to`, `edited`, `deleted`, `created_at`, `updated_at`, `read_by_count`) VALUES
('1', '1', 'اهلا', NULL, '0', '0', '2025-12-10 03:55:19', '2025-12-11 17:23:22', '5'),
('2', '4', 'اهلا', '1', '0', '0', '2025-12-10 03:55:49', '2025-12-11 17:23:22', '5'),
('3', '2', 'ش', NULL, '0', '0', '2025-12-10 11:50:42', '2025-12-11 17:23:22', '5'),
('4', '1', '', '3', '1', '1', '2025-12-10 11:50:51', '2025-12-10 11:50:58', '2'),
('5', '19', 'اهلا', NULL, '0', '0', '2025-12-10 13:23:39', '2025-12-11 17:23:22', '5'),
('6', '2', '', '5', '1', '1', '2025-12-10 13:23:59', '2025-12-10 13:24:28', '2'),
('7', '2', 'M', NULL, '0', '0', '2025-12-11 16:17:22', '2025-12-11 17:23:22', '4'),
('8', '1', 'انا مشيت', NULL, '0', '0', '2025-12-11 17:10:16', '2025-12-11 18:06:02', '4'),
('9', '1', 'انا مشيت', '7', '0', '0', '2025-12-11 17:10:31', '2025-12-11 18:06:02', '4'),
('10', '4', 'يا جماعه انا ماشي', NULL, '0', '0', '2025-12-11 17:11:16', '2025-12-11 18:06:02', '4');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `mixed_nuts`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `mixed_nuts`;
CREATE TABLE `mixed_nuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(255) NOT NULL COMMENT 'اسم الخلطة',
  `supplier_id` int(11) NOT NULL COMMENT 'المورد الخاص بالخلطة',
  `total_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'إجمالي الوزن',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `mixed_nuts_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mixed_nuts_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `mixed_nuts` WRITE;
/*!40000 ALTER TABLE `mixed_nuts` DISABLE KEYS */;
INSERT INTO `mixed_nuts` (`id`, `batch_name`, `supplier_id`, `total_quantity`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'تشكيلة 12', '3', '500.000', NULL, '1', '2025-12-10 02:25:12', NULL);
/*!40000 ALTER TABLE `mixed_nuts` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `mixed_nuts_ingredients`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `mixed_nuts_ingredients`;
CREATE TABLE `mixed_nuts_ingredients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mixed_nuts_id` int(11) NOT NULL COMMENT 'رقم الخلطة',
  `nuts_stock_id` int(11) NOT NULL COMMENT 'رقم المكسرات المنفردة',
  `quantity` decimal(10,3) NOT NULL COMMENT 'الكمية المستخدمة',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mixed_nuts_id` (`mixed_nuts_id`),
  KEY `nuts_stock_id` (`nuts_stock_id`),
  CONSTRAINT `mixed_nuts_ingredients_ibfk_1` FOREIGN KEY (`mixed_nuts_id`) REFERENCES `mixed_nuts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mixed_nuts_ingredients_ibfk_2` FOREIGN KEY (`nuts_stock_id`) REFERENCES `nuts_stock` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `mixed_nuts_ingredients` WRITE;
/*!40000 ALTER TABLE `mixed_nuts_ingredients` DISABLE KEYS */;
INSERT INTO `mixed_nuts_ingredients` (`id`, `mixed_nuts_id`, `nuts_stock_id`, `quantity`, `created_at`) VALUES
('1', '1', '2', '250.000', '2025-12-10 02:25:12'),
('2', '1', '1', '250.000', '2025-12-10 02:25:12');
/*!40000 ALTER TABLE `mixed_nuts_ingredients` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `notification_settings`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `notification_settings`;
CREATE TABLE `notification_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` enum('manager','accountant','sales','production','all') DEFAULT NULL,
  `notification_type` varchar(50) NOT NULL,
  `telegram_enabled` tinyint(1) DEFAULT 0,
  `telegram_chat_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role` (`role`),
  KEY `notification_type` (`notification_type`),
  CONSTRAINT `notification_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `notification_settings`

-- --------------------------------------------------------
-- Table structure for table `notifications`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` enum('manager','accountant','sales','production','all') DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role` (`role`),
  KEY `read` (`read`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `user_id`, `role`, `title`, `message`, `type`, `link`, `read`, `created_at`) VALUES
('38', '17', NULL, 'تمت الموافقة على طلب السلفة', 'تمت الموافقة على طلب السلفة بمبلغ 10.00 ج.م. وتم خصمها من راتبك الحالي.', 'success', NULL, '0', '2025-12-09 20:38:50'),
('39', '17', NULL, 'تم تعديل راتبك', 'تم تعديل راتبك للشهر December. مكافأة: 0.00 ج.م, خصومات: 0.00 ج.م', 'info', NULL, '0', '2025-12-09 20:39:08'),
('40', '17', NULL, 'تم تعديل راتبك', 'تم تعديل راتبك للشهر December. مكافأة: 10.00 ج.م, خصومات: 0.00 ج.م', 'info', NULL, '0', '2025-12-09 20:39:20'),
('41', '17', NULL, 'تذكير بموعد تحصيل', 'تذكير: موعد تحصيل مبلغ 200.00 ج.م من العميل 4 في تاريخ 13/12/2025', 'warning', 'dashboard/sales.php?page=sales_collections&id=1', '0', '2025-12-09 20:52:46'),
('64', '18', NULL, 'تنبيه تسجيل الحضور', 'تنبيه هام لتسجيل الحضور لتفادي الخصومات. يرجى تسجيل الحضور الآن.', '', '/v1/dashboard/sales.php?page=attendance', '0', '2025-12-10 00:43:27'),
('69', '18', NULL, 'تحصيل من خزنتك', 'تم تحصيل مبلغ 1,500.00 ج.م من رصيد خزنتك من قبل المدير العام - رقم المرجع: COL-REP-18-20251210150210', 'warning', '/v1/dashboard/sales.php?page=cash_register', '0', '2025-12-10 05:02:10'),
('71', '19', NULL, 'مهمة جديدة من الإدارة', '1 (مشتركة مع 1 عامل آخر)', 'info', '/v1/production.php?page=tasks', '0', '2025-12-10 05:13:55'),
('75', '18', NULL, 'طلب جديد', 'تم إنشاء طلب جديد رقم ORD-202512-0001 لك من قبل المدير العام', 'info', '/v1/dashboard/sales.php?page=orders&id=1', '1', '2025-12-10 05:16:31'),
('81', '10', NULL, 'تحصيل من عميلك', 'تم تحصيل مبلغ 500.00 ج.م من العميل مايكل بواسطة المحاسب الأول - رقم المرجع: COL-CUST-14-20251210163946 (ملاحظة: لا يتم احتساب نسبة تحصيلات على هذا المبلغ)', 'info', '/v1/dashboard/sales.php?page=customers', '1', '2025-12-10 06:39:46'),
('84', '17', NULL, 'تحصيل من خزنتك', 'تم تحصيل مبلغ 2,000.00 ج.م من رصيد خزنتك من قبل المحاسب الأول - رقم المرجع: COL-REP-17-20251210170812', 'warning', '/v1/dashboard/sales.php?page=cash_register', '0', '2025-12-10 07:08:13'),
('89', '10', NULL, 'طلب جديد', 'تم إنشاء طلب جديد رقم ORD-202512-0002 لك من قبل المدير العام', 'info', '/v1/dashboard/sales.php?page=orders&id=2', '1', '2025-12-10 22:40:53'),
('93', '10', NULL, 'تنبيه تسجيل الحضور', 'تنبيه هام لتسجيل الحضور لتفادي الخصومات. يرجى تسجيل الحضور الآن.', '', '/v1/dashboard/sales.php?page=attendance', '0', '2025-12-11 00:25:06'),
('94', '10', NULL, 'تحصيل من عميلك', 'تم تحصيل مبلغ 100.00 ج.م من العميل مايكل بواسطة المدير العام - رقم المرجع: COL-CUST-14-20251211104840 (ملاحظة: لا يتم احتساب نسبة تحصيلات على هذا المبلغ)', 'info', '/v1/dashboard/sales.php?page=customers', '0', '2025-12-11 00:48:40'),
('95', '18', NULL, 'تحصيل من عميلك', 'تم تحصيل مبلغ 100.00 ج.م من العميل 1 بواسطة المدير العام - رقم المرجع: COL-CUST-13-20251211130944 (ملاحظة: لا يتم احتساب نسبة تحصيلات على هذا المبلغ)', 'info', '/v1/dashboard/sales.php?page=customers', '0', '2025-12-11 03:09:43'),
('96', '11', NULL, 'مهمة جديدة من الإدارة', '10 كرتونة شمع نص', 'info', '/v1/production.php?page=tasks', '0', '2025-12-11 06:32:40'),
('97', '11', NULL, 'مهمة جديدة من الإدارة', 'تعبئة', 'info', '/v1/production.php?page=tasks', '1', '2025-12-11 06:34:38'),
('98', '16', NULL, 'مهمة جديدة من الإدارة', 'T (مشتركة مع 2 عامل آخر)', 'info', '/v1/production.php?page=tasks', '1', '2025-12-11 06:36:32'),
('100', '19', NULL, 'مهمة جديدة من الإدارة', 'T (مشتركة مع 2 عامل آخر)', 'info', '/v1/production.php?page=tasks', '0', '2025-12-11 06:36:32'),
('103', '11', NULL, 'تنبيه تسجيل الحضور', 'تنبيه هام لتسجيل الحضور لتفادي الخصومات. يرجى تسجيل الحضور الآن.', '', '/v1/dashboard/production.php?page=attendance', '0', '2025-12-11 07:15:07'),
('104', '11', NULL, 'تنبيه: تأخير في الحضور', 'تم تسجيل حضورك مع تأخير 497 دقيقة. عدد حالات التأخير الحالية لهذا الشهر: 2', 'warning', NULL, '0', '2025-12-11 07:17:04'),
('107', '11', NULL, 'مهمة جديدة من الإدارة', '10 شمع (مشتركة مع 3 عامل آخر)', 'info', '/v1/production.php?page=tasks', '1', '2025-12-11 07:23:04'),
('108', '16', NULL, 'مهمة جديدة من الإدارة', '10 شمع (مشتركة مع 3 عامل آخر)', 'info', '/v1/production.php?page=tasks', '1', '2025-12-11 07:23:04'),
('110', '19', NULL, 'مهمة جديدة من الإدارة', '10 شمع (مشتركة مع 3 عامل آخر)', 'info', '/v1/production.php?page=tasks', '0', '2025-12-11 07:23:04'),
('117', '2', NULL, 'طلب سلفة جديد', 'طلب سلفة من عامل الإنتاج الأول بقيمة 100.00 ج.م', 'warning', '/v1/dashboard/accountant.php?page=salaries&view=advances', '0', '2025-12-11 08:28:02'),
('122', '11', NULL, 'تنبيه تسجيل الحضور', 'تنبيه هام لتسجيل الحضور لتفادي الخصومات. يرجى تسجيل الحضور الآن.', '', '/v1/dashboard/production.php?page=attendance', '0', '2025-12-12 02:11:05'),
('125', '19', NULL, 'مهمة جديدة من الإدارة', '111', 'info', '/production.php?page=tasks', '1', '2025-12-14 12:41:18'),
('127', '11', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"111\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '1', '2025-12-14 12:44:05'),
('128', '16', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"111\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '1', '2025-12-14 12:44:05'),
('129', '19', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"111\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-14 12:44:05'),
('131', '11', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"تعبئة\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '1', '2025-12-14 12:44:14'),
('132', '16', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"تعبئة\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '1', '2025-12-14 12:44:14'),
('133', '19', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"تعبئة\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-14 12:44:14'),
('135', '11', NULL, 'مهمة جديدة من الإدارة', '111 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '1', '2025-12-14 12:52:46'),
('136', '16', NULL, 'مهمة جديدة من الإدارة', '111 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '1', '2025-12-14 12:52:46'),
('138', '19', NULL, 'مهمة جديدة من الإدارة', '111 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 12:52:46'),
('139', '11', NULL, 'تنبيه تسجيل الحضور', 'تنبيه هام لتسجيل الحضور لتفادي الخصومات. يرجى تسجيل الحضور الآن.', '', '/dashboard/production.php?page=attendance', '0', '2025-12-14 12:56:09'),
('140', '16', NULL, 'تنبيه تسجيل الحضور', 'تنبيه هام لتسجيل الحضور لتفادي الخصومات. يرجى تسجيل الحضور الآن.', '', '/dashboard/production.php?page=attendance', '0', '2025-12-14 12:58:11'),
('141', '11', NULL, 'مهمة جديدة من الإدارة', '000 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 13:00:45'),
('142', '16', NULL, 'مهمة جديدة من الإدارة', '000 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 13:00:45'),
('144', '19', NULL, 'مهمة جديدة من الإدارة', '000 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 13:00:45'),
('145', '11', NULL, 'مهمة جديدة من الإدارة', '12 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 13:12:59'),
('146', '16', NULL, 'مهمة جديدة من الإدارة', '12 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 13:12:59'),
('148', '19', NULL, 'مهمة جديدة من الإدارة', '12 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 13:12:59'),
('149', '11', NULL, 'مهمة جديدة من الإدارة', '0123 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:49:03'),
('150', '16', NULL, 'مهمة جديدة من الإدارة', '0123 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:49:03'),
('152', '19', NULL, 'مهمة جديدة من الإدارة', '0123 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:49:03'),
('153', '11', NULL, 'مهمة جديدة من الإدارة', '00 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:54:20'),
('154', '16', NULL, 'مهمة جديدة من الإدارة', '00 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:54:20'),
('156', '19', NULL, 'مهمة جديدة من الإدارة', '00 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:54:20'),
('157', '11', NULL, 'مهمة جديدة من الإدارة', '00000 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:54:52'),
('158', '16', NULL, 'مهمة جديدة من الإدارة', '00000 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:54:52'),
('160', '19', NULL, 'مهمة جديدة من الإدارة', '00000 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 14:54:52'),
('161', '11', NULL, 'مهمة جديدة من الإدارة', '1 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 15:05:35'),
('162', '16', NULL, 'مهمة جديدة من الإدارة', '1 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 15:05:35'),
('164', '19', NULL, 'مهمة جديدة من الإدارة', '1 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 15:05:35'),
('165', '11', NULL, 'مهمة جديدة من الإدارة', '2 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 15:07:28'),
('166', '16', NULL, 'مهمة جديدة من الإدارة', '2 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 15:07:28'),
('168', '19', NULL, 'مهمة جديدة من الإدارة', '2 (مشتركة مع 3 عامل آخر)', 'info', '/production.php?page=tasks', '0', '2025-12-14 15:07:28'),
('170', '11', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"2\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-14 15:13:33'),
('171', '16', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"2\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-14 15:13:33'),
('172', '19', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"2\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-14 15:13:33'),
('177', '11', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"1\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-15 02:05:13'),
('178', '16', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"1\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-15 02:05:13'),
('179', '19', NULL, 'تنبيه هام: تم إلغاء مهمة', 'تم إلغاء المهمة \"1\" من قبل الإدارة. يرجى تجاهلها.', 'error', '/production.php?page=tasks', '0', '2025-12-15 02:05:13');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `nuts_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `nuts_stock`;
CREATE TABLE `nuts_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `nut_type` varchar(100) NOT NULL COMMENT 'نوع المكسرات (لوز، جوز، فستق، إلخ)',
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالكيلوجرام',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الكيلو',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  KEY `nut_type` (`nut_type`),
  KEY `supplier_nut` (`supplier_id`,`nut_type`),
  CONSTRAINT `nuts_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `nuts_stock` WRITE;
/*!40000 ALTER TABLE `nuts_stock` DISABLE KEYS */;
INSERT INTO `nuts_stock` (`id`, `supplier_id`, `nut_type`, `quantity`, `unit_price`, `notes`, `created_at`, `updated_at`) VALUES
('1', '3', 'عين جمل', '250.000', NULL, NULL, '2025-12-10 02:21:53', '2025-12-10 02:25:12'),
('2', '3', 'بندق', '250.000', NULL, NULL, '2025-12-10 02:22:33', '2025-12-10 02:25:12');
/*!40000 ALTER TABLE `nuts_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `olive_oil_product_templates`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `olive_oil_product_templates`;
CREATE TABLE `olive_oil_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `olive_oil_quantity` decimal(10,2) NOT NULL COMMENT 'كمية زيت الزيتون (لتر)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `olive_oil_product_templates`

-- --------------------------------------------------------
-- Table structure for table `olive_oil_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `olive_oil_stock`;
CREATE TABLE `olive_oil_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية (لتر)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `olive_oil_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `olive_oil_stock` WRITE;
/*!40000 ALTER TABLE `olive_oil_stock` DISABLE KEYS */;
INSERT INTO `olive_oil_stock` (`id`, `supplier_id`, `quantity`, `created_at`, `updated_at`) VALUES
('1', '6', '44.00', '2025-12-09 18:00:46', '2025-12-11 02:30:09');
/*!40000 ALTER TABLE `olive_oil_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `packaging_damage_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `packaging_damage_logs`;
CREATE TABLE `packaging_damage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `source_table` enum('packaging_materials','products') NOT NULL DEFAULT 'packaging_materials',
  `quantity_before` decimal(15,4) DEFAULT 0.0000,
  `damaged_quantity` decimal(15,4) NOT NULL,
  `quantity_after` decimal(15,4) DEFAULT 0.0000,
  `unit` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `recorded_by` (`recorded_by`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `packaging_damage_logs` WRITE;
/*!40000 ALTER TABLE `packaging_damage_logs` DISABLE KEYS */;
INSERT INTO `packaging_damage_logs` (`id`, `material_id`, `material_name`, `source_table`, `quantity_before`, `damaged_quantity`, `quantity_after`, `unit`, `reason`, `recorded_by`, `created_at`) VALUES
('1', '17', 'أغطية - غطاء 43م', 'packaging_materials', '900.0000', '10.0000', '890.0000', 'قطعة', '00', '1', '2025-12-10 02:19:30'),
('2', '17', 'أغطية - غطاء 43م', 'packaging_materials', '804.0000', '1.0000', '803.0000', 'قطعة', 'الن', '4', '2025-12-11 08:00:48'),
('3', '17', 'أغطية - غطاء 43م', 'packaging_materials', '791.0000', '1.0000', '790.0000', 'قطعة', '1', '4', '2025-12-15 01:24:42'),
('4', '17', 'أغطية - غطاء 43م', 'packaging_materials', '772.0000', '2.0000', '770.0000', 'قطعة', '2131', '1', '2025-12-15 02:07:45');
/*!40000 ALTER TABLE `packaging_damage_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `packaging_materials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `packaging_materials`;
CREATE TABLE `packaging_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` varchar(50) NOT NULL COMMENT 'معرف فريد مثل PKG-001',
  `name` varchar(255) NOT NULL COMMENT 'اسم مأخوذ من type + specifications',
  `alias` varchar(255) DEFAULT NULL,
  `type` varchar(100) NOT NULL COMMENT 'نوع الأداة مثل: عبوات زجاجية',
  `specifications` varchar(255) DEFAULT NULL COMMENT 'المواصفات مثل: برطمان 720م دائري',
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(50) DEFAULT 'قطعة',
  `unit_price` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_id` (`material_id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `packaging_materials` WRITE;
/*!40000 ALTER TABLE `packaging_materials` DISABLE KEYS */;
INSERT INTO `packaging_materials` (`id`, `material_id`, `name`, `alias`, `type`, `specifications`, `quantity`, `unit`, `unit_price`, `status`, `created_at`, `updated_at`) VALUES
('1', 'PKG-002', 'صناديق كرتون - كراتين كيلو', NULL, 'صناديق كرتون', 'كراتين كيلو', '999.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-15 18:08:15'),
('2', 'PKG-001', 'صناديق كرتون - كراتين نصف', NULL, 'صناديق كرتون', 'كراتين نصف', '998.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-15 18:04:54'),
('3', 'PKG-003', 'عبوات زجاجية - برطمان 720م دائري', NULL, 'عبوات زجاجية', 'برطمان 720م دائري', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:58:55'),
('4', 'PKG-004', 'عبوات زجاجية - برطمان 370م دائري', NULL, 'عبوات زجاجية', 'برطمان 370م دائري', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:58:34'),
('5', 'PKG-005', 'عبوات زجاجية - برطمان 290م سداسي', NULL, 'عبوات زجاجية', 'برطمان 290م سداسي', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:58:37'),
('6', 'PKG-006', 'عبوات زجاجية - برطمان 285م فازه', NULL, 'عبوات زجاجية', 'برطمان 285م فازه', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:59:04'),
('7', 'PKG-007', 'عبوات زجاجية - برطمان 212 ملل', NULL, 'عبوات زجاجية', 'برطمان 212 ملل', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:58:39'),
('8', 'PKG-008', 'عبوات زجاجية - برطمان 100 ملل', NULL, 'عبوات زجاجية', 'برطمان 100 ملل', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('9', 'PKG-010', 'عبوات زجاجية - برطمان 1ك مشرشر', NULL, 'عبوات بلاستيكية', 'برطمان 1ك مشرشر', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:58:48'),
('10', 'PKG-009', 'عبوات زجاجية - برطمان نص ك مشرشر', NULL, 'عبوات زجاجية', 'برطمان نص ك مشرشر', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:59:08'),
('11', 'PKG-011', 'عبوات بلاستيكية - سكويز 400م', NULL, 'عبوات بلاستيكية', 'سكويز 400م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:58:53'),
('12', 'PKG-012', 'عبوات بلاستيكية - سكويز 200م', NULL, 'عبوات بلاستيكية', 'سكويز 200م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:59:06'),
('13', 'PKG-013', 'أغطية - غطاء 63م متعدد', NULL, 'أغطية', 'غطاء 63م متعدد', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-24 03:45:21'),
('14', 'PKG-014', 'أغطية - غطاء سنبله', NULL, 'أغطية', 'غطاء سنبله', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-23 08:39:01'),
('15', 'PKG-015', 'أغطية - غطاء 82م', NULL, 'أغطية', 'غطاء 82م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('16', 'PKG-016', 'أغطية - غطاء زيت زيتون متعدد', NULL, 'أغطية', 'غطاء زيت زيتون متعدد', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('17', 'PKG-017', 'أغطية - غطاء 43م', NULL, 'أغطية', 'غطاء 43م', '985.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-15 18:08:15'),
('18', 'PKG-018', 'أغطية - غطاء سكويز 400م', NULL, 'أغطية', 'غطاء سكويز 400م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-24 05:17:08'),
('19', 'PKG-019', 'أغطية - غطاء فليبتوب 200م ذهبي', NULL, 'أغطية', 'غطاء فليبتوب 200م ذهبي', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('20', 'PKG-020', 'أغطية - غطاء فليبتوب 200م اسود', NULL, 'أغطية', 'غطاء فليبتوب 200م اسود', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('21', 'PKG-021', 'أغطية - غطاء دبدوب', NULL, 'أغطية', 'غطاء دبدوب', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('22', 'PKG-022', 'طبات - طبه دبدوب', NULL, 'طبات', 'طبه دبدوب', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('23', 'PKG-023', 'طبات - طبه سنبله', NULL, 'طبات', 'طبه سنبله', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('24', 'PKG-024', 'طبات - طبه سكويز 200م', NULL, 'طبات', 'طبه سكويز 200م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('25', 'PKG-025', 'طبات - طبه سكويز 400م', NULL, 'طبات', 'طبه سكويز 400م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('26', 'PKG-026', 'طبات - طبه فليبتوب 200م', NULL, 'طبات', 'طبه فليبتوب 200م', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('27', 'PKG-027', 'عبوات بلاستيكية - علبة شمع نص ك', NULL, 'عبوات بلاستيكية', 'علبة شمع نص ك', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('28', 'PKG-028', 'عبوات بلاستيكية - علبة شمع ك', NULL, 'عبوات بلاستيكية', 'علبة شمع ك', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-24 05:40:33'),
('29', 'PKG-029', 'عبوات بلاستيكية - جركن 20 ل', NULL, 'عبوات بلاستيكية', 'جركن 20 ل', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('30', 'PKG-030', 'أكياس - أكياس', NULL, 'أكياس', 'أكياس', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('31', 'PKG-031', 'لوازم التعبئة - شريط لاصق', NULL, 'لوازم التعبئة', 'شريط لاصق', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('32', 'PKG-032', 'عبوات زجاجية - برطمان دبدوب', NULL, 'عبوات زجاجية', 'برطمان دبدوب', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('33', 'PKG-033', 'عبوات زجاجية - برطمان دبله', NULL, 'عبوات زجاجية', 'برطمان دبله', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-05 18:17:32'),
('36', 'PKG-036', 'عبوات زجاجية - برطمان سنبله ك', NULL, 'عبوات زجاجية', 'برطمان سنبله ك', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-12-07 05:59:02'),
('37', 'PKG-037', 'عبوات بلاستيكية - بابلز', NULL, 'عبوات بلاستيكية', 'بابلز', '0.00', 'قطعة', '0.00', 'active', '2025-11-05 18:16:07', '2025-11-24 03:45:12'),
('38', 'PKG-038', 'ملصق صغير', NULL, 'لوازم التعبئة', NULL, '881.00', 'قطعة', '0.00', 'active', '2025-11-11 17:59:08', '2025-12-11 07:55:29'),
('39', 'PKG-039', 'ملصق وسط', NULL, 'لوازم التعبئة', NULL, '0.00', 'قطعة', '0.00', 'active', '2025-11-11 18:00:11', '2025-11-24 03:45:16'),
('40', 'PKG-040', 'ملصق كبير', NULL, 'ملصقات', NULL, '0.00', 'قطعة', '0.00', 'active', '2025-11-11 18:00:54', '2025-11-23 03:12:24'),
('41', 'PKG-041', 'كراتين ربع', NULL, 'صناديق كرتون', 'كراتين ربع', '996.00', 'قطعة', '0.00', 'active', '2025-11-24 03:51:33', '2025-12-08 13:35:15'),
('42', 'PKG-042', 'برطمان 370م بيضاوي', NULL, 'عبوات زجاجية', 'نص مكسرات', '60.00', 'قطعة', '0.00', 'active', '2025-11-24 05:58:42', '2025-12-11 07:55:29'),
('43', 'PKG-043', 'جركن 16 لتر', NULL, 'عبوات بلاستيكية', NULL, '99.00', 'قطعة', '0.00', 'active', '2025-12-10 06:00:06', '2025-12-10 06:01:41');
/*!40000 ALTER TABLE `packaging_materials` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `packaging_usage_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `packaging_usage_logs`;
CREATE TABLE `packaging_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `material_code` varchar(100) DEFAULT NULL,
  `source_table` enum('packaging_materials','products') NOT NULL DEFAULT 'packaging_materials',
  `quantity_before` decimal(15,4) DEFAULT 0.0000,
  `quantity_used` decimal(15,4) NOT NULL,
  `quantity_after` decimal(15,4) DEFAULT 0.0000,
  `unit` varchar(50) DEFAULT NULL,
  `used_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `used_by` (`used_by`),
  KEY `source_table` (`source_table`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `packaging_usage_logs` WRITE;
/*!40000 ALTER TABLE `packaging_usage_logs` DISABLE KEYS */;
INSERT INTO `packaging_usage_logs` (`id`, `material_id`, `material_name`, `material_code`, `source_table`, `quantity_before`, `quantity_used`, `quantity_after`, `unit`, `used_by`, `created_at`) VALUES
('1', '43', 'جركن 16 لتر', 'PKG-043', 'packaging_materials', '100.0000', '1.0000', '99.0000', 'قطعة', '1', '2025-12-10 06:01:41'),
('2', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '999.0000', '1.0000', '998.0000', 'قطعة', '4', '2025-12-11 02:29:15'),
('3', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '998.0000', '2.0000', '996.0000', 'قطعة', '4', '2025-12-11 02:30:09'),
('4', '2', 'صناديق كرتون - كراتين نصف', NULL, 'packaging_materials', '1000.0000', '1.0000', '999.0000', 'قطعة', '4', '2025-12-11 02:31:58'),
('5', '1', 'صناديق كرتون - كراتين كيلو', 'PKG-002', 'packaging_materials', '996.0000', '1.0000', '995.0000', 'قطعة', '1', '2025-12-11 07:36:33'),
('6', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '995.0000', '3.0000', '992.0000', 'قطعة', '4', '2025-12-11 07:55:29'),
('7', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '992.0000', '1.0000', '991.0000', 'قطعة', '4', '2025-12-14 15:47:16'),
('8', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '991.0000', '1.0000', '990.0000', 'قطعة', '4', '2025-12-15 01:11:48'),
('9', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '990.0000', '1.0000', '989.0000', 'قطعة', '4', '2025-12-15 01:26:51'),
('10', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '989.0000', '1.0000', '988.0000', 'قطعة', '4', '2025-12-15 01:34:44'),
('11', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '988.0000', '1.0000', '987.0000', 'قطعة', '4', '2025-12-15 01:51:59'),
('12', '2', 'صناديق كرتون - كراتين نصف', NULL, 'packaging_materials', '999.0000', '1.0000', '998.0000', 'قطعة', '4', '2025-12-15 18:04:54'),
('13', '1', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging_materials', '1000.0000', '1.0000', '999.0000', 'قطعة', '4', '2025-12-15 18:08:15');
/*!40000 ALTER TABLE `packaging_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `payment_reminders`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_reminders`;
CREATE TABLE `payment_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_schedule_id` int(11) NOT NULL,
  `reminder_type` enum('before_due','on_due','after_due','custom') DEFAULT 'before_due',
  `reminder_date` date NOT NULL,
  `days_before_due` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `sent_to` enum('sales_rep','customer','both') DEFAULT 'sales_rep',
  `sent_status` enum('pending','sent','failed') DEFAULT 'pending',
  `sent_at` timestamp NULL DEFAULT NULL,
  `sent_method` enum('notification','telegram','sms','email') DEFAULT 'notification',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `payment_schedule_id` (`payment_schedule_id`),
  KEY `reminder_date` (`reminder_date`),
  KEY `sent_status` (`sent_status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_reminders_ibfk_1` FOREIGN KEY (`payment_schedule_id`) REFERENCES `payment_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_reminders_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `payment_reminders` WRITE;
/*!40000 ALTER TABLE `payment_reminders` DISABLE KEYS */;
INSERT INTO `payment_reminders` (`id`, `payment_schedule_id`, `reminder_type`, `reminder_date`, `days_before_due`, `message`, `sent_to`, `sent_status`, `sent_at`, `sent_method`, `created_by`, `created_at`) VALUES
('2', '1', 'before_due', '2025-12-09', '4', NULL, 'sales_rep', 'sent', '2025-12-09 20:52:46', 'notification', '17', '2025-12-09 20:52:46'),
('3', '2', 'before_due', '2025-12-09', '1', NULL, 'sales_rep', 'sent', '2025-12-10 04:58:06', 'notification', '10', '2025-12-10 04:58:06'),
('4', '3', 'before_due', '2025-12-19', '1', NULL, 'sales_rep', 'pending', NULL, 'notification', '10', '2025-12-10 04:58:59');
/*!40000 ALTER TABLE `payment_reminders` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `payment_schedules`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_schedules`;
CREATE TABLE `payment_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue','cancelled') DEFAULT 'pending',
  `installment_number` int(11) DEFAULT 1,
  `total_installments` int(11) DEFAULT 1,
  `notes` text DEFAULT NULL,
  `reminder_sent` tinyint(1) DEFAULT 0,
  `reminder_sent_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_schedules_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_schedules_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `payment_schedules` WRITE;
/*!40000 ALTER TABLE `payment_schedules` DISABLE KEYS */;
INSERT INTO `payment_schedules` (`id`, `sale_id`, `invoice_id`, `customer_id`, `sales_rep_id`, `amount`, `due_date`, `payment_date`, `status`, `installment_number`, `total_installments`, `notes`, `reminder_sent`, `reminder_sent_at`, `created_by`, `created_at`, `updated_at`) VALUES
('1', NULL, NULL, '3', '17', '200.00', '2025-12-13', '2025-12-10', 'paid', '1', '1', NULL, '1', '2025-12-09 20:52:46', '17', '2025-12-09 20:52:13', '2025-12-09 20:53:00'),
('2', NULL, NULL, '14', '10', '100.00', '2025-12-10', NULL, 'overdue', '1', '1', NULL, '1', '2025-12-10 04:58:06', '10', '2025-12-10 04:57:47', '2025-12-10 21:48:03'),
('3', NULL, NULL, '14', '10', '200.00', '2025-12-20', NULL, 'pending', '1', '1', NULL, '0', NULL, '10', '2025-12-10 04:58:39', NULL);
/*!40000 ALTER TABLE `payment_schedules` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `permissions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `permissions`

-- --------------------------------------------------------
-- Table structure for table `product_exchanges`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_exchanges`;
CREATE TABLE `product_exchanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `original_invoice_id` int(11) DEFAULT NULL,
  `original_sale_id` int(11) DEFAULT NULL,
  `return_id` int(11) DEFAULT NULL,
  `exchange_date` date NOT NULL,
  `exchange_type` enum('same_product','different_product','upgrade','downgrade') DEFAULT 'same_product',
  `reason` text DEFAULT NULL,
  `original_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `new_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `difference_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_number` (`exchange_number`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `original_invoice_id` (`original_invoice_id`),
  KEY `original_sale_id` (`original_sale_id`),
  KEY `return_id` (`return_id`),
  KEY `status` (`status`),
  KEY `product_exchanges_ibfk_6` (`approved_by`),
  KEY `product_exchanges_ibfk_7` (`processed_by`),
  KEY `product_exchanges_ibfk_8` (`created_by`),
  CONSTRAINT `product_exchanges_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_exchanges_ibfk_2` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_exchanges_ibfk_3` FOREIGN KEY (`original_invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_4` FOREIGN KEY (`original_sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_5` FOREIGN KEY (`return_id`) REFERENCES `sales_returns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_6` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_7` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_exchanges_ibfk_8` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `product_exchanges`

-- --------------------------------------------------------
-- Table structure for table `product_specifications`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_specifications`;
CREATE TABLE `product_specifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `raw_materials` longtext DEFAULT NULL,
  `packaging` longtext DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `product_specifications_created_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_specifications_updated_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `product_specifications` WRITE;
/*!40000 ALTER TABLE `product_specifications` DISABLE KEYS */;
INSERT INTO `product_specifications` (`id`, `product_name`, `raw_materials`, `packaging`, `notes`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
('1', 'ك سدر', '1000 جم سدر داخل عبوة سنبلة', 'عبوة بلاستيك وغطاء بلاستيك', NULL, '1', NULL, '2025-12-11 06:53:23', NULL);
/*!40000 ALTER TABLE `product_specifications` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `product_template_materials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_template_materials`;
CREATE TABLE `product_template_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'القالب',
  `material_type` enum('honey','other','ingredient') NOT NULL DEFAULT 'other' COMMENT 'نوع المادة',
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة',
  `material_id` int(11) DEFAULT NULL COMMENT 'معرف المادة (supplier_id للعسل أو product_id للمواد الأخرى)',
  `quantity_per_unit` decimal(10,3) NOT NULL COMMENT 'الكمية لكل وحدة منتج',
  `unit` varchar(50) DEFAULT 'كجم' COMMENT 'وحدة القياس',
  `is_required` tinyint(1) DEFAULT 1 COMMENT 'هل المادة مطلوبة',
  `notes` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'ترتيب العرض',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `material_type` (`material_type`),
  CONSTRAINT `product_template_materials_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `product_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `product_template_materials`

-- --------------------------------------------------------
-- Table structure for table `product_template_packaging`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_template_packaging`;
CREATE TABLE `product_template_packaging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL COMMENT 'القالب',
  `packaging_material_id` int(11) DEFAULT NULL COMMENT 'مادة التعبئة',
  `packaging_name` varchar(255) DEFAULT NULL COMMENT 'اسم أداة التعبئة',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 1.000 COMMENT 'الكمية لكل وحدة منتج',
  `unit` varchar(50) DEFAULT 'قطعة' COMMENT 'الوحدة',
  `is_required` tinyint(1) DEFAULT 1 COMMENT 'هل أداة التعبئة مطلوبة',
  `notes` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'ترتيب العرض',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `packaging_material_id` (`packaging_material_id`),
  CONSTRAINT `product_template_packaging_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `product_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_template_packaging_ibfk_2` FOREIGN KEY (`packaging_material_id`) REFERENCES `packaging_materials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `product_template_packaging` WRITE;
/*!40000 ALTER TABLE `product_template_packaging` DISABLE KEYS */;
INSERT INTO `product_template_packaging` (`id`, `template_id`, `packaging_material_id`, `packaging_name`, `quantity_per_unit`, `unit`, `is_required`, `notes`, `sort_order`, `created_at`, `updated_at`) VALUES
('25', '12', '17', 'أغطية - غطاء 43م', '1.000', 'قطعة', '1', NULL, '0', '2025-12-15 18:03:39', NULL),
('26', '13', '17', 'أغطية - غطاء 43م', '1.000', 'قطعة', '1', NULL, '0', '2025-12-15 18:07:30', NULL);
/*!40000 ALTER TABLE `product_template_packaging` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `product_template_raw_materials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_template_raw_materials`;
CREATE TABLE `product_template_raw_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `material_name` varchar(255) NOT NULL COMMENT 'اسم المادة (مثل: مكسرات، لوز، إلخ)',
  `material_type` varchar(100) DEFAULT NULL COMMENT 'نوع المادة (مثل: honey_raw, honey_filtered)',
  `honey_variety` varchar(50) DEFAULT NULL COMMENT 'نوع العسل المستخدم',
  `quantity_per_unit` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالجرام',
  `unit` varchar(50) DEFAULT 'جرام',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `product_template_raw_materials` WRITE;
/*!40000 ALTER TABLE `product_template_raw_materials` DISABLE KEYS */;
INSERT INTO `product_template_raw_materials` (`id`, `template_id`, `material_name`, `material_type`, `honey_variety`, `quantity_per_unit`, `unit`, `created_at`) VALUES
('3', '5', 'زيت زيتون', '', NULL, '1.000', 'كيلوجرام', '2025-12-11 00:07:55'),
('7', '6', 'زيت زيتون', '', NULL, '1.000', 'كيلوجرام', '2025-12-11 01:15:07'),
('9', '4', 'زيت زيتون', '', NULL, '1.000', 'كيلوجرام', '2025-12-11 01:33:53'),
('10', '7', 'زيت زيتون', '', NULL, '1.000', 'كيلوجرام', '2025-12-11 01:47:51'),
('11', '8', 'عسل - عسل حلبه', 'honey_filtered', NULL, '1.000', 'كيلوجرام', '2025-12-11 02:18:45'),
('16', '1', 'زيت زيتون', '', NULL, '1.000', 'كيلوجرام', '2025-12-11 02:28:26'),
('17', '9', 'عسل - سدر', 'honey_filtered', NULL, '1.000', 'كيلوجرام', '2025-12-11 06:50:19'),
('18', '10', 'عسل - عسل حلبه', 'honey_filtered', NULL, '0.500', 'كيلوجرام', '2025-12-11 16:18:22'),
('19', '11', 'عسل - سدر', 'honey_filtered', NULL, '1.000', 'كيلوجرام', '2025-12-11 16:24:57'),
('20', '12', 'عسل - تيست', 'honey_filtered', NULL, '1.000', 'كيلوجرام', '2025-12-15 18:03:39'),
('21', '13', 'عسل - عسل حلبه', 'honey_filtered', NULL, '1.000', 'كيلوجرام', '2025-12-15 18:07:30');
/*!40000 ALTER TABLE `product_template_raw_materials` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `product_templates`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_templates`;
CREATE TABLE `product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) NOT NULL COMMENT 'اسم القالب',
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL COMMENT 'اسم المنتج',
  `honey_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'كمية العسل بالجرام',
  `template_type` varchar(50) DEFAULT 'general',
  `source_template_id` int(11) DEFAULT NULL,
  `main_supplier_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `details_json` longtext DEFAULT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL COMMENT 'سعر الوحدة بالجنيه',
  `carton_type` enum('kilo','half','quarter','third') DEFAULT NULL COMMENT 'نوع الكرتونة',
  `custom_carton_quantity` int(11) DEFAULT NULL COMMENT 'عدد المنتجات لكل كرتونة (للنوع المخصص)',
  `custom_carton_type_id` int(11) DEFAULT NULL COMMENT 'معرف نوع الكرتونة من packaging_materials (للنوع المخصص)',
  `target_quantity` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الكمية المستهدفة',
  `unit` varchar(50) DEFAULT 'قطعة' COMMENT 'الوحدة',
  `description` text DEFAULT NULL COMMENT 'الوصف',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) NOT NULL COMMENT 'منشئ القالب',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `source_template_id` (`source_template_id`),
  KEY `main_supplier_id` (`main_supplier_id`),
  KEY `product_templates_ibfk_custom_carton` (`custom_carton_type_id`),
  CONSTRAINT `product_templates_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_templates_ibfk_custom_carton` FOREIGN KEY (`custom_carton_type_id`) REFERENCES `packaging_materials` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `product_templates` WRITE;
/*!40000 ALTER TABLE `product_templates` DISABLE KEYS */;
INSERT INTO `product_templates` (`id`, `template_name`, `product_id`, `product_name`, `honey_quantity`, `template_type`, `source_template_id`, `main_supplier_id`, `notes`, `details_json`, `unit_price`, `carton_type`, `custom_carton_quantity`, `custom_carton_type_id`, `target_quantity`, `unit`, `description`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
('12', '', NULL, '1', '0.000', 'legacy', NULL, NULL, NULL, '{\"product_name\":\"1\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"عسل - تيست\",\"material_name\":\"عسل\",\"material_type\":\"honey_filtered\",\"quantity\":1,\"quantity_per_unit\":1,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":17,\"packaging_material_id\":17,\"name\":\"أغطية - غطاء 43م\",\"packaging_name\":\"أغطية - غطاء 43م\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-12-15T18:03:39+02:00\",\"submitted_by\":1}', '1000.00', '', '11', '2', '0.00', 'قطعة', NULL, 'active', '1', '2025-12-15 18:03:39', NULL),
('13', '', NULL, '2', '0.000', 'legacy', NULL, NULL, NULL, '{\"product_name\":\"2\",\"status\":\"active\",\"template_type\":\"legacy\",\"raw_materials\":[{\"type\":\"ingredient\",\"name\":\"عسل - عسل حلبه\",\"material_name\":\"عسل\",\"material_type\":\"honey_filtered\",\"quantity\":1,\"quantity_per_unit\":1,\"unit\":\"كيلوجرام\"}],\"packaging\":[{\"id\":17,\"packaging_material_id\":17,\"name\":\"أغطية - غطاء 43م\",\"packaging_name\":\"أغطية - غطاء 43م\",\"quantity_per_unit\":1,\"unit\":\"قطعة\"}],\"submitted_at\":\"2025-12-15T18:07:30+02:00\",\"submitted_by\":1}', '1000.00', '', '2', '1', '0.00', 'قطعة', NULL, 'active', '1', '2025-12-15 18:07:30', NULL);
/*!40000 ALTER TABLE `product_templates` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `production`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `production`;
CREATE TABLE `production` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_order_item_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `production_date` date NOT NULL,
  `worker_id` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `production_line_id` int(11) DEFAULT NULL COMMENT 'خط الإنتاج',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `worker_id` (`worker_id`),
  KEY `production_date` (`production_date`),
  KEY `customer_order_item_id` (`customer_order_item_id`),
  KEY `production_line_id` (`production_line_id`),
  CONSTRAINT `production_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_ibfk_line` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_ibfk_order_item` FOREIGN KEY (`customer_order_item_id`) REFERENCES `customer_order_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `production` WRITE;
/*!40000 ALTER TABLE `production` DISABLE KEYS */;
INSERT INTO `production` (`id`, `product_id`, `customer_order_item_id`, `quantity`, `production_date`, `worker_id`, `notes`, `status`, `created_at`, `production_line_id`) VALUES
('1', '3', NULL, '50.00', '2025-12-10', '4', NULL, 'completed', '2025-12-09 19:35:03', NULL),
('2', '4', NULL, '20.00', '2025-12-10', '4', NULL, 'completed', '2025-12-09 19:56:25', NULL),
('3', '12', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 00:32:13', NULL),
('4', '12', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 00:41:53', NULL),
('5', '12', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 00:43:46', NULL),
('6', '13', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 01:17:40', NULL),
('7', '13', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 01:34:30', NULL),
('8', '15', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:19:41', NULL),
('9', '4', NULL, '6.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:25:55', NULL),
('10', '4', NULL, '6.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:27:17', NULL),
('11', '4', NULL, '6.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:29:15', NULL),
('12', '4', NULL, '12.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:30:09', NULL),
('13', '15', NULL, '11.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:31:58', NULL),
('14', '15', NULL, '1.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 02:51:48', NULL),
('15', '20', NULL, '18.00', '2025-12-11', '4', NULL, 'completed', '2025-12-11 07:55:29', NULL),
('22', '30', NULL, '6.00', '2025-12-14', '4', NULL, 'completed', '2025-12-14 15:47:16', NULL),
('23', '30', NULL, '6.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 01:11:48', NULL),
('24', '30', NULL, '6.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 01:26:51', NULL),
('25', '30', NULL, '6.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 01:34:44', NULL),
('26', '30', NULL, '6.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 01:51:59', NULL),
('27', '3', NULL, '12.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 18:04:54', NULL),
('28', '32', NULL, '1.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 18:08:03', NULL),
('29', '32', NULL, '2.00', '2025-12-15', '4', NULL, 'completed', '2025-12-15 18:08:15', NULL);
/*!40000 ALTER TABLE `production` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `production_lines`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `production_lines`;
CREATE TABLE `production_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_name` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `target_quantity` decimal(10,2) DEFAULT 0.00,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `worker_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','active','completed','paused','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `worker_id` (`worker_id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `production_lines_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_lines_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_lines_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `production_lines`

-- --------------------------------------------------------
-- Table structure for table `production_materials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `production_materials`;
CREATE TABLE `production_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `production_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_used` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `production_id` (`production_id`),
  KEY `product_id` (`product_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `production_materials_ibfk_1` FOREIGN KEY (`production_id`) REFERENCES `production` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_materials_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_materials_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `production_materials` WRITE;
/*!40000 ALTER TABLE `production_materials` DISABLE KEYS */;
INSERT INTO `production_materials` (`id`, `production_id`, `product_id`, `quantity_used`, `created_at`, `supplier_id`) VALUES
('1', '1', '1', '50.00', '2025-12-09 19:35:03', '4'),
('2', '1', '2', '50.00', '2025-12-09 19:35:03', '6'),
('3', '2', '1', '20.00', '2025-12-09 19:56:25', '4'),
('4', '2', '2', '20.00', '2025-12-09 19:56:25', '6'),
('5', '3', '11', '11.00', '2025-12-11 00:32:13', '4'),
('6', '3', '2', '11.00', '2025-12-11 00:32:13', '6'),
('7', '4', '11', '11.00', '2025-12-11 00:41:53', '4'),
('8', '4', '2', '11.00', '2025-12-11 00:41:53', '6'),
('9', '5', '1', '11.00', '2025-12-11 00:43:46', '4'),
('10', '5', '2', '11.00', '2025-12-11 00:43:46', '6'),
('11', '6', '1', '11.00', '2025-12-11 01:17:40', '4'),
('12', '6', '2', '11.00', '2025-12-11 01:17:40', '6'),
('13', '7', '1', '11.00', '2025-12-11 01:34:30', '4'),
('14', '7', '2', '11.00', '2025-12-11 01:34:30', '6'),
('15', '8', '1', '11.00', '2025-12-11 02:19:41', '4'),
('16', '8', '14', '11.00', '2025-12-11 02:19:41', '1'),
('17', '9', '1', '6.00', '2025-12-11 02:25:55', '4'),
('18', '9', '2', '6.00', '2025-12-11 02:25:55', '6'),
('19', '10', '1', '6.00', '2025-12-11 02:27:17', '4'),
('20', '10', '2', '6.00', '2025-12-11 02:27:17', '6'),
('21', '11', '1', '6.00', '2025-12-11 02:29:15', '4'),
('22', '11', '2', '6.00', '2025-12-11 02:29:15', '6'),
('23', '12', '1', '12.00', '2025-12-11 02:30:09', '4'),
('24', '12', '2', '12.00', '2025-12-11 02:30:09', '6'),
('25', '13', '1', '11.00', '2025-12-11 02:31:58', '4'),
('26', '13', '14', '11.00', '2025-12-11 02:31:58', '1'),
('27', '14', '1', '1.00', '2025-12-11 02:51:48', '4'),
('28', '14', '14', '1.00', '2025-12-11 02:51:48', '1'),
('29', '15', '11', '18.00', '2025-12-11 07:55:29', '4'),
('30', '15', '18', '18.00', '2025-12-11 07:55:29', '4'),
('31', '15', '17', '1.00', '2025-12-11 07:55:29', NULL),
('32', '15', '19', '18.00', '2025-12-11 07:55:29', '2'),
('33', '22', '1', '6.00', '2025-12-14 15:47:16', '4'),
('34', '22', '14', '3.00', '2025-12-14 15:47:16', '1'),
('35', '23', '1', '6.00', '2025-12-15 01:11:48', '4'),
('36', '23', '14', '3.00', '2025-12-15 01:11:48', '1'),
('37', '24', '1', '6.00', '2025-12-15 01:26:51', '4'),
('38', '24', '14', '3.00', '2025-12-15 01:26:51', '1'),
('39', '25', '1', '6.00', '2025-12-15 01:34:44', '4'),
('40', '25', '14', '3.00', '2025-12-15 01:34:44', '1'),
('41', '26', '1', '6.00', '2025-12-15 01:51:59', '4'),
('42', '26', '14', '3.00', '2025-12-15 01:51:59', '1'),
('43', '27', '1', '12.00', '2025-12-15 18:04:54', '4'),
('44', '27', '31', '12.00', '2025-12-15 18:04:54', '2'),
('45', '28', '1', '1.00', '2025-12-15 18:08:03', '4'),
('46', '28', '14', '1.00', '2025-12-15 18:08:03', '1'),
('47', '29', '1', '2.00', '2025-12-15 18:08:15', '4'),
('48', '29', '14', '2.00', '2025-12-15 18:08:15', '1');
/*!40000 ALTER TABLE `production_materials` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `production_monthly_report_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `production_monthly_report_logs`;
CREATE TABLE `production_monthly_report_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month_key` varchar(7) NOT NULL,
  `month_number` tinyint(2) NOT NULL,
  `year_number` smallint(4) NOT NULL,
  `sent_via` varchar(40) NOT NULL DEFAULT 'telegram_auto',
  `triggered_by` int(11) DEFAULT NULL,
  `report_snapshot` longtext DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_monthly_report_logs_unique` (`month_key`,`sent_via`),
  KEY `production_monthly_report_logs_month_idx` (`month_number`,`year_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `production_monthly_report_logs`

-- --------------------------------------------------------
-- Table structure for table `production_supply_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `production_supply_logs`;
CREATE TABLE `production_supply_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_category` varchar(50) NOT NULL,
  `material_label` varchar(190) DEFAULT NULL,
  `stock_source` varchar(80) DEFAULT NULL,
  `stock_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `supplier_name` varchar(190) DEFAULT NULL,
  `quantity` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unit` varchar(20) DEFAULT 'كجم',
  `details` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `production_supply_logs_category_date_idx` (`material_category`,`recorded_at`),
  KEY `production_supply_logs_supplier_idx` (`supplier_id`),
  KEY `production_supply_logs_recorded_at_idx` (`recorded_at`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `production_supply_logs` WRITE;
/*!40000 ALTER TABLE `production_supply_logs` DISABLE KEYS */;
INSERT INTO `production_supply_logs` (`id`, `material_category`, `material_label`, `stock_source`, `stock_id`, `supplier_id`, `supplier_name`, `quantity`, `unit`, `details`, `recorded_by`, `recorded_at`) VALUES
('1', 'olive_oil', 'زيت زيتون', 'olive_oil_stock', '1', '6', 'مورد زيت', '100.000', 'كجم', 'إضافة زيت زيتون خام إلى المخزون', '4', '2025-12-09 18:00:46'),
('2', 'packaging', 'أغطية - غطاء 43م', 'packaging_materials', '17', '4', 'مورد ادوات تعبئه', '51.000', 'قطعة', 'إضافة كمية عبر مخزن أدوات التعبئة', '4', '2025-12-09 19:35:57'),
('3', 'packaging', 'أغطية - غطاء 43م', 'packaging_materials', '17', '4', 'مورد ادوات تعبئه', '20.000', 'قطعة', 'إضافة كمية عبر مخزن أدوات التعبئة', '4', '2025-12-10 01:55:16'),
('4', 'packaging', 'برطمان 370م بيضاوي', 'packaging_materials', '42', '4', 'مورد ادوات تعبئه', '100.000', 'قطعة', 'إضافة كمية عبر مخزن أدوات التعبئة', '19', '2025-12-10 02:13:05'),
('5', 'honey', 'حبة البركة - KI001', 'honey_stock', '1', '1', 'مايكل', '100.000', 'كجم', 'إضافة حبة البركة (حبة البركة - KI001) - الحالة: عسل خام', '1', '2025-12-10 02:16:35'),
('6', 'honey', 'سدر - KI002', 'honey_stock', '2', '2', 'عمرو', '100.000', 'كجم', 'إضافة سدر (سدر - KI002) - الحالة: عسل خام', '1', '2025-12-10 02:20:32'),
('7', 'olive_oil', 'زيت زيتون', 'olive_oil_stock', '1', '6', 'مورد زيت', '100.000', 'كجم', 'إضافة زيت زيتون خام إلى المخزون', '1', '2025-12-10 02:21:01'),
('8', 'nuts', 'مكسرات - عين جمل', 'nuts_stock', '1', '3', 'مورد مكسرات', '500.000', 'كجم', 'إضافة مكسرات خام', '1', '2025-12-10 02:21:53'),
('9', 'nuts', 'مكسرات - بندق', 'nuts_stock', '2', '3', 'مورد مكسرات', '500.000', 'كجم', 'إضافة مكسرات خام', '1', '2025-12-10 02:22:33'),
('10', 'sesame', 'سمسم', 'sesame_stock', '1', '5', 'مورد سمسم', '100.000', 'كجم', 'إضافة سمسم خام', '1', '2025-12-10 02:25:51'),
('11', 'beeswax', 'شمع عسل', 'beeswax_stock', '1', '8', 'مورد شمع', '100.000', 'كجم', 'إضافة شمع عسل خام إلى المخزون', '1', '2025-12-10 05:55:50'),
('12', 'sesame', 'سمسم', 'sesame_stock', '1', '5', 'مورد سمسم', '100.000', 'كجم', 'إضافة سمسم خام', '1', '2025-12-10 05:56:08'),
('13', 'tahini', 'طحينة', 'tahini_stock', '1', '5', 'مورد سمسم', '0.400', 'كجم', 'إضافة باقي عملية التحويل: 0.400 كجم', '1', '2025-12-10 05:57:27'),
('14', 'packaging', 'جركن 16 لتر', 'packaging_materials', '43', NULL, NULL, '50.000', 'قطعة', 'توريد ابتدائي عند إنشاء أداة التعبئة', '1', '2025-12-10 06:00:06'),
('15', 'packaging', 'جركن 16 لتر', 'packaging_materials', '43', '4', 'مورد ادوات تعبئه', '50.000', 'قطعة', 'إضافة كمية عبر مخزن أدوات التعبئة', '1', '2025-12-10 06:01:23'),
('16', 'honey', 'نوع مخصص', 'honey_stock', '3', '2', 'عمرو', '100.000', 'كجم', 'إضافة نوع مخصص (نوع مخصص) - الحالة: عسل خام', '1', '2025-12-10 22:25:55'),
('17', 'honey', 'نوع جديد - KI380', 'honey_stock', '4', '1', 'مايكل', '100.000', 'كجم', 'إضافة نوع جديد (نوع جديد - KI380) - الحالة: عسل خام', '1', '2025-12-10 23:59:24'),
('18', 'honey', 'نحل 1 - KI548', 'honey_stock', '5', '2', 'عمرو', '10.000', 'كجم', 'إضافة نحل 1 (نحل 1 - KI548) - الحالة: عسل خام', '1', '2025-12-11 01:07:55'),
('19', 'honey', 'جديد 2 - KI257', 'honey_stock', '6', '2', 'عمرو', '10.000', 'كجم', 'إضافة جديد 2 (جديد 2 - KI257) - الحالة: عسل خام', '4', '2025-12-11 01:51:03'),
('20', 'honey', 'نحل 1 - KI548', 'honey_stock', '7', '1', 'مايكل', '10.000', 'كجم', 'إضافة نحل 1 (نحل 1 - KI548) - الحالة: عسل خام', '4', '2025-12-11 01:59:33'),
('21', 'honey', '13 - KI507', 'honey_stock', '8', '1', 'مايكل', '10.000', 'كجم', 'إضافة 13 (13 - KI507) - الحالة: عسل خام', '4', '2025-12-11 02:11:45'),
('22', 'honey', 'عسل حلبه - KI600', 'honey_stock', '9', '1', 'مايكل', '15.000', 'كجم', 'إضافة عسل حلبه (عسل حلبه - KI600) - الحالة: عسل خام', '4', '2025-12-11 02:12:31'),
('23', 'honey', 'نوارة برسيم - KI005', 'honey_stock', '10', '2', 'عمرو', '100.000', 'كجم', 'إضافة نوارة برسيم (نوارة برسيم - KI005) - الحالة: عسل خام', '1', '2025-12-11 07:30:36'),
('24', 'honey', 'تيست - KI397', 'honey_stock', '11', '2', 'عمرو', '100.000', 'كجم', 'إضافة تيست (تيست - KI397) - الحالة: عسل مصفى', '4', '2025-12-15 01:13:05'),
('25', 'packaging', 'أغطية - غطاء 43م', 'packaging_materials', '17', '4', 'مورد ادوات تعبئه', '230.000', 'قطعة', 'إضافة كمية عبر مخزن أدوات التعبئة', '1', '2025-12-15 02:08:11'),
('26', 'packaging', 'صناديق كرتون - كراتين كيلو', 'packaging_materials', '1', '4', 'مورد ادوات تعبئه', '13.000', 'قطعة', 'إضافة كمية عبر مخزن أدوات التعبئة', '4', '2025-12-15 18:06:50');
/*!40000 ALTER TABLE `production_supply_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `products`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `product_type` enum('internal','external') DEFAULT 'internal',
  `external_channel` enum('company','delegate','other') DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(20) DEFAULT 'piece',
  `min_stock` decimal(10,2) DEFAULT 0.00,
  `min_stock_level` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `category` (`category`),
  KEY `warehouse_id` (`warehouse_id`),
  CONSTRAINT `products_ibfk_warehouse` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `description`, `category`, `product_type`, `external_channel`, `warehouse_id`, `unit_price`, `quantity`, `unit`, `min_stock`, `min_stock_level`, `status`, `created_at`, `updated_at`) VALUES
('1', 'أغطية - غطاء 43م', NULL, 'packaging', 'internal', NULL, '1', '0.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-09 19:35:03', '2025-12-09 19:35:05'),
('2', 'زيت زيتون', NULL, 'raw_material', 'internal', NULL, '1', '0.00', '0.00', 'كيلوجرام', '0.00', '0.00', 'active', '2025-12-09 19:35:03', '2025-12-09 19:35:05'),
('3', '1', NULL, 'finished', 'internal', NULL, '1', '0.00', '40.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-09 19:35:03', '2025-12-09 19:57:37'),
('4', 'TEST', NULL, 'finished', 'internal', NULL, '1', '1000.00', '9.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-09 19:56:25', '2025-12-09 23:43:27'),
('7', 'صابون كبير', NULL, 'منتجات خارجية', 'external', NULL, '1', '1000.00', '89.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-09 20:57:06', '2025-12-11 06:05:07'),
('9', 'صابون صغير', NULL, 'منتجات خارجية', 'external', NULL, '1', '500.00', '80.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-10 03:56:33', '2025-12-10 07:01:26'),
('10', 'صابون صغير', NULL, 'منتجات خارجية', 'external', NULL, '1', '500.00', '99.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-10 03:56:40', '2025-12-10 06:57:04'),
('11', 'برطمان 370م بيضاوي', NULL, 'packaging', 'internal', NULL, '1', '0.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 00:32:13', '2025-12-11 00:32:17'),
('12', 'مخصص', NULL, 'finished', 'internal', NULL, '1', '0.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 00:32:13', '2025-12-11 00:32:17'),
('13', '11', NULL, 'finished', 'internal', NULL, '1', '0.00', '1.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 01:17:40', '2025-12-11 05:53:26'),
('14', 'عسل - عسل حلبه', NULL, 'raw_material', 'internal', NULL, '1', '0.00', '0.00', 'كيلوجرام', '0.00', '0.00', 'active', '2025-12-11 02:19:41', '2025-12-11 02:19:47'),
('15', '12', NULL, 'finished', 'internal', NULL, '1', '1000.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 02:19:41', '2025-12-11 02:19:47'),
('16', 'صناديق كرتون - كراتين كيلو', NULL, 'packaging', 'internal', NULL, '1', '0.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 02:29:15', '2025-12-11 02:29:34'),
('17', 'صناديق كرتون - كراتين نصف', NULL, 'packaging', 'internal', NULL, '1', '0.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 02:31:58', '2025-12-11 02:32:01'),
('18', 'ملصق صغير', NULL, 'packaging', 'internal', NULL, '1', '0.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 07:55:29', '2025-12-11 07:55:33'),
('19', 'عسل - سدر', NULL, 'raw_material', 'internal', NULL, '1', '0.00', '0.00', 'كيلوجرام', '0.00', '0.00', 'active', '2025-12-11 07:55:29', '2025-12-11 07:55:33'),
('20', 'عسل ك سنبله', NULL, 'finished', 'internal', NULL, '1', '150.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-11 07:55:29', '2025-12-11 07:55:33'),
('30', 'ك', NULL, 'finished', 'internal', NULL, '1', '100.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-14 15:47:16', '2025-12-14 15:51:39'),
('31', 'عسل - تيست', NULL, 'raw_material', 'internal', NULL, '1', '0.00', '0.00', 'كيلوجرام', '0.00', '0.00', 'active', '2025-12-15 18:04:54', '2025-12-15 18:04:58'),
('32', '2', NULL, 'finished', 'internal', NULL, '1', '1000.00', '0.00', 'قطعة', '0.00', '0.00', 'active', '2025-12-15 18:08:03', '2025-12-15 18:08:08');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `pwa_splash_sessions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `pwa_splash_sessions`;
CREATE TABLE `pwa_splash_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `session_token` varchar(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `pwa_splash_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `pwa_splash_sessions`

-- --------------------------------------------------------
-- Table structure for table `raw_material_damage_logs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `raw_material_damage_logs`;
CREATE TABLE `raw_material_damage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_category` varchar(50) NOT NULL COMMENT 'نوع الخام (honey, olive_oil, beeswax, derivatives, nuts)',
  `stock_id` int(11) DEFAULT NULL COMMENT 'معرف السجل في جدول المخزون',
  `supplier_id` int(11) DEFAULT NULL COMMENT 'المورد المرتبط',
  `item_label` varchar(255) NOT NULL COMMENT 'اسم المادة التالفة',
  `variety` varchar(255) DEFAULT NULL COMMENT 'النوع/الصنف (اختياري)',
  `quantity` decimal(12,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية التالفة',
  `unit` varchar(20) NOT NULL DEFAULT 'كجم' COMMENT 'وحدة القياس',
  `reason` text DEFAULT NULL COMMENT 'سبب التلف',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `material_category` (`material_category`),
  KEY `created_by` (`created_by`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `raw_material_damage_logs` WRITE;
/*!40000 ALTER TABLE `raw_material_damage_logs` DISABLE KEYS */;
INSERT INTO `raw_material_damage_logs` (`id`, `material_category`, `stock_id`, `supplier_id`, `item_label`, `variety`, `quantity`, `unit`, `reason`, `created_by`, `created_at`) VALUES
('1', 'olive_oil', '1', '6', 'زيت زيتون', NULL, '1.000', 'كجم', '3', '4', '2025-12-09 19:26:33'),
('2', 'honey', '1', '1', 'عسل مصفى', 'حبة البركة', '10.000', 'كجم', '00', '1', '2025-12-10 02:18:12'),
('3', 'honey', '5', '2', 'عسل خام', '', '1.000', 'كجم', 'ال', '4', '2025-12-11 08:01:32');
/*!40000 ALTER TABLE `raw_material_damage_logs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `reader_access_log`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `reader_access_log`;
CREATE TABLE `reader_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `status` enum('success','not_found','error','rate_limited','invalid') NOT NULL DEFAULT 'success',
  `message` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `reader_access_log` WRITE;
/*!40000 ALTER TABLE `reader_access_log` DISABLE KEYS */;
INSERT INTO `reader_access_log` (`id`, `session_id`, `ip_address`, `batch_number`, `status`, `message`, `created_at`) VALUES
('1', 'f02532ae5cc8e0a9083f6b6ca5976b49', '105.92.230.105', '251210-921358', 'success', 'نجاح الاستعلام.', '2025-12-10 04:10:19'),
('2', 'f02532ae5cc8e0a9083f6b6ca5976b49', '105.202.99.68', '251210-990828', 'success', 'نجاح الاستعلام.', '2025-12-10 04:48:55'),
('3', 'ef88bbf1693a6c56a7668007933572b0', '105.93.74.211', '251211-923972', 'success', 'نجاح الاستعلام.', '2025-12-11 08:18:09');
/*!40000 ALTER TABLE `reader_access_log` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `regions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول المناطق';

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` (`id`, `name`, `created_at`, `updated_at`) VALUES
('1', 'المنطقه الاولي', '2025-12-10 21:53:42', NULL),
('2', 'المنطقه التانيه', '2025-12-10 21:54:01', NULL);
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `remember_tokens`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_used` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_token` (`user_id`,`token`),
  KEY `token` (`token`),
  KEY `expires_at` (`expires_at`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `remember_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `remember_tokens`

-- --------------------------------------------------------
-- Table structure for table `reports`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filters` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_type` enum('pdf','excel','csv') DEFAULT 'pdf',
  `telegram_sent` tinyint(1) DEFAULT 0,
  `status` enum('pending','generated','sent','deleted') DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `reports`

-- --------------------------------------------------------
-- Table structure for table `request_usage`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `request_usage`;
CREATE TABLE `request_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `method` varchar(10) NOT NULL,
  `path` text DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`created_at`),
  KEY `idx_ip_date` (`ip_address`,`created_at`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=40223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `request_usage` WRITE;
/*!40000 ALTER TABLE `request_usage` DISABLE KEYS */;
INSERT INTO `request_usage` (`id`, `user_id`, `ip_address`, `method`, `path`, `user_agent`, `created_at`) VALUES
('40123', '1', '::1', 'GET', '/dashboard/manager.php?page=invoices', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:00'),
('40124', '1', '::1', 'GET', '/dashboard/manager.php?page=returns_overview', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:01'),
('40125', '1', '::1', 'GET', '/dashboard/manager.php?page=company_cash', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:02'),
('40126', '1', '::1', 'GET', '/dashboard/manager.php?page=customer_credit_balances', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:03'),
('40127', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:03'),
('40128', '1', '::1', 'GET', '/profile.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:03'),
('40129', '1', '::1', 'GET', '/dashboard/manager.php?page=warehouse_transfers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:04'),
('40130', '1', '::1', 'GET', '/dashboard/manager.php?page=company_products', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:04'),
('40131', '1', '::1', 'GET', '/dashboard/manager.php?page=product_templates', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:05'),
('40132', '1', '::1', 'GET', '/dashboard/manager.php?page=product_templates&section=specifications', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:06'),
('40133', '1', '::1', 'GET', '/dashboard/manager.php?page=packaging_warehouse', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:06'),
('40134', '1', '::1', 'GET', '/dashboard/manager.php?page=raw_materials_warehouse', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:07'),
('40135', '1', '::1', 'GET', '/dashboard/manager.php?page=suppliers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:09'),
('40136', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:11'),
('40137', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:11'),
('40138', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:45:11'),
('40139', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos&_nocache=1765842405569', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:47'),
('40140', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos&_nocache=1765842405569', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:47'),
('40141', '2', '::1', 'GET', '/dashboard/accountant.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:48'),
('40142', '2', '::1', 'GET', '/dashboard/accountant.php?page=chat', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:48'),
('40143', '2', '::1', 'GET', '/dashboard/accountant.php?page=financial', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:48'),
('40144', '2', '::1', 'GET', '/dashboard/accountant.php?page=suppliers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:49'),
('40145', '2', '::1', 'GET', '/profile.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:49'),
('40146', '2', '::1', 'GET', '/dashboard/accountant.php?page=local_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:49'),
('40147', '2', '::1', 'GET', '/dashboard/accountant.php?page=representatives_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:49'),
('40148', '2', '::1', 'GET', '/dashboard/accountant.php?page=orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:49'),
('40149', '2', '::1', 'GET', '/dashboard/accountant.php?page=invoices', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:46:49'),
('40150', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:25'),
('40151', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:26'),
('40152', '1', '::1', 'GET', '/dashboard/manager.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:29'),
('40153', '1', '::1', 'GET', '/profile.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:29'),
('40154', '1', '::1', 'GET', '/dashboard/manager.php?page=chat', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:29'),
('40155', '1', '::1', 'GET', '/dashboard/manager.php?page=approvals', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:29'),
('40156', '1', '::1', 'GET', '/dashboard/manager.php?page=production_tasks', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:29'),
('40157', '1', '::1', 'GET', '/dashboard/manager.php?page=orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:29'),
('40158', '1', '::1', 'GET', '/dashboard/manager.php?page=local_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:30'),
('40159', '1', '::1', 'GET', '/dashboard/manager.php?page=representatives_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:30'),
('40160', '1', '::1', 'GET', '/dashboard/manager.php?page=pos', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:30'),
('40161', '1', '::1', 'GET', '/dashboard/manager.php?page=shipping_orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:30'),
('40162', '1', '::1', 'GET', '/dashboard/manager.php?page=invoices', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:30'),
('40163', '1', '::1', 'GET', '/dashboard/manager.php?page=returns_overview', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:31'),
('40164', '1', '::1', 'GET', '/dashboard/manager.php?page=company_cash', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:31'),
('40165', '1', '::1', 'GET', '/dashboard/manager.php?page=customer_credit_balances', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:31'),
('40166', '1', '::1', 'GET', '/dashboard/manager.php?page=warehouse_transfers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:49:31'),
('40167', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos&_nocache=1765842405569&_nocache=1765842593499', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:53'),
('40168', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos&_nocache=1765842405569&_nocache=1765842593499', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:53'),
('40169', '2', '::1', 'GET', '/dashboard/accountant.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:54'),
('40170', '2', '::1', 'GET', '/dashboard/accountant.php?page=chat', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:54'),
('40171', '2', '::1', 'GET', '/dashboard/accountant.php?page=financial', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:54'),
('40172', '2', '::1', 'GET', '/dashboard/accountant.php?page=suppliers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:55'),
('40173', '2', '::1', 'GET', '/attendance.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:55'),
('40174', '2', '::1', 'GET', '/profile.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:55'),
('40175', '2', '::1', 'GET', '/dashboard/accountant.php?page=local_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:55'),
('40176', '2', '::1', 'GET', '/dashboard/accountant.php?page=representatives_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:55'),
('40177', '2', '::1', 'GET', '/dashboard/accountant.php?page=orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:55'),
('40178', '2', '::1', 'GET', '/dashboard/accountant.php?page=invoices', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.20 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-16 01:49:56'),
('40179', '2', '::1', 'GET', '/dashboard/accountant.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:12'),
('40180', '2', '::1', 'GET', '/dashboard/accountant.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:12'),
('40181', '2', '::1', 'GET', '/dashboard/accountant.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:13'),
('40182', '2', '::1', 'GET', '/dashboard/accountant.php?page=chat', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:13'),
('40183', '2', '::1', 'GET', '/dashboard/accountant.php?page=financial', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:13'),
('40184', '2', '::1', 'GET', '/dashboard/accountant.php?page=suppliers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:13'),
('40185', '2', '::1', 'GET', '/attendance.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:14'),
('40186', '2', '::1', 'GET', '/profile.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:14'),
('40187', '2', '::1', 'GET', '/dashboard/accountant.php?page=local_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:14'),
('40188', '2', '::1', 'GET', '/dashboard/accountant.php?page=representatives_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:14'),
('40189', '2', '::1', 'GET', '/dashboard/accountant.php?page=orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:14'),
('40190', '2', '::1', 'GET', '/dashboard/accountant.php?page=invoices', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:14'),
('40191', '2', '::1', 'GET', '/dashboard/accountant.php?page=customer_credit_balances', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:15'),
('40192', '2', '::1', 'GET', '/dashboard/accountant.php?page=company_products', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:15'),
('40193', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:15'),
('40194', '2', '::1', 'GET', '/dashboard/accountant.php?page=salaries', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:15'),
('40195', '2', '::1', 'GET', '/dashboard/accountant.php?page=my_salary', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:16'),
('40196', '2', '::1', 'GET', '/dashboard/accountant.php?page=attendance_management', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:16'),
('40197', '2', '::1', 'GET', '/dashboard/accountant.php?page=shipping_orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:17'),
('40198', '2', '::1', 'GET', '/dashboard/accountant.php?page=production_tasks', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:17'),
('40199', '2', '::1', 'GET', '/dashboard/accountant.php?page=returns', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:17'),
('40200', '2', '::1', 'GET', '/dashboard/accountant.php?page=vehicles', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:17'),
('40201', '2', '::1', 'GET', '/dashboard/manager.php?page=reports', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:18'),
('40202', '2', '::1', 'GET', '/dashboard/accountant.php?page=packaging_warehouse', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:18'),
('40203', '2', '::1', 'GET', '/dashboard/accountant.php?page=raw_materials_warehouse', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:18'),
('40204', '2', '::1', 'GET', '/dashboard/accountant.php?page=factory_waste_warehouse', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:18'),
('40205', '2', '::1', 'GET', '/dashboard/accountant.php?page=batch_reader', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:19'),
('40206', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:21'),
('40207', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:21'),
('40208', '2', '::1', 'GET', '/dashboard/accountant.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:21'),
('40209', '2', '::1', 'GET', '/dashboard/accountant.php?page=chat', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:22'),
('40210', '2', '::1', 'GET', '/dashboard/accountant.php?page=financial', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:22'),
('40211', '2', '::1', 'GET', '/dashboard/accountant.php?page=suppliers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:22'),
('40212', '2', '::1', 'GET', '/attendance.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:22'),
('40213', '2', '::1', 'GET', '/profile.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:22'),
('40214', '2', '::1', 'GET', '/dashboard/accountant.php?page=local_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:22'),
('40215', '2', '::1', 'GET', '/dashboard/accountant.php?page=representatives_customers', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:23'),
('40216', '2', '::1', 'GET', '/dashboard/accountant.php?page=orders', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:23'),
('40217', '2', '::1', 'GET', '/dashboard/accountant.php?page=invoices', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:23'),
('40218', '2', '::1', 'GET', '/dashboard/accountant.php?page=customer_credit_balances', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:23'),
('40219', '2', '::1', 'GET', '/dashboard/accountant.php?page=company_products', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:23'),
('40220', '2', '::1', 'GET', '/dashboard/accountant.php?page=pos', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:23'),
('40221', '2', '::1', 'GET', '/dashboard/accountant.php?page=salaries', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:24'),
('40222', '2', '::1', 'GET', '/dashboard/accountant.php?page=my_salary', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:25');
/*!40000 ALTER TABLE `request_usage` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `request_usage_alerts`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `request_usage_alerts`;
CREATE TABLE `request_usage_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier_type` enum('user','ip') NOT NULL,
  `identifier_value` varchar(255) NOT NULL,
  `window_start` datetime NOT NULL,
  `window_end` datetime NOT NULL,
  `request_count` int(11) NOT NULL,
  `threshold` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_window` (`identifier_type`,`identifier_value`,`window_start`,`window_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `request_usage_alerts`

-- --------------------------------------------------------
-- Table structure for table `return_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `return_items`;
CREATE TABLE `return_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `invoice_item_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `condition` enum('new','used','damaged','defective') DEFAULT 'new',
  `is_damaged` tinyint(1) NOT NULL DEFAULT 0,
  `batch_number_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `return_id` (`return_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_number_id` (`batch_number_id`),
  KEY `idx_invoice_item_id` (`invoice_item_id`),
  CONSTRAINT `return_items_ibfk_1` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `return_items_ibfk_invoice_item` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `return_items` WRITE;
/*!40000 ALTER TABLE `return_items` DISABLE KEYS */;
INSERT INTO `return_items` (`id`, `return_id`, `invoice_item_id`, `product_id`, `quantity`, `unit_price`, `total_price`, `condition`, `is_damaged`, `batch_number_id`, `batch_number`, `notes`, `created_at`) VALUES
('1', '1', '7', '4', '1.00', '1000.00', '1000.00', 'damaged', '1', '2', '251210-921358', '', '2025-12-09 22:32:44'),
('2', '2', '6', '4', '1.00', '1000.00', '1000.00', 'new', '0', '2', '251210-921358', NULL, '2025-12-09 22:34:03'),
('3', '3', '8', '4', '1.00', '1000.00', '1000.00', 'new', '0', '2', '251210-921358', NULL, '2025-12-09 23:06:31'),
('4', '4', '10', '7', '1.00', '1000.00', '1000.00', 'new', '0', NULL, NULL, NULL, '2025-12-09 23:15:34'),
('5', '5', '11', '7', '1.00', '1000.00', '1000.00', 'new', '0', NULL, NULL, NULL, '2025-12-09 23:18:17'),
('6', '6', '12', '7', '1.00', '1000.00', '1000.00', 'new', '0', NULL, NULL, NULL, '2025-12-09 23:23:46'),
('7', '7', '13', '7', '1.00', '1000.00', '1000.00', 'new', '0', NULL, NULL, NULL, '2025-12-10 00:24:17'),
('8', '8', '9', '7', '1.00', '1000.00', '1000.00', 'new', '0', NULL, NULL, NULL, '2025-12-10 00:34:57'),
('9', '9', '25', '7', '1.00', '1000.00', '1000.00', 'new', '0', NULL, NULL, NULL, '2025-12-10 00:38:12');
/*!40000 ALTER TABLE `return_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `returns`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `returns`;
CREATE TABLE `returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) DEFAULT NULL,
  `return_date` date NOT NULL,
  `return_type` enum('full','partial') DEFAULT 'full',
  `reason` enum('defective','wrong_item','customer_request','other') DEFAULT 'customer_request',
  `reason_description` text DEFAULT NULL,
  `refund_amount` decimal(15,2) DEFAULT 0.00,
  `refund_method` enum('cash','credit','exchange','company_request') DEFAULT 'cash',
  `status` enum('pending','approved','rejected','processed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `return_date` (`return_date`),
  KEY `status` (`status`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `returns_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
INSERT INTO `returns` (`id`, `return_number`, `sale_id`, `invoice_id`, `customer_id`, `sales_rep_id`, `return_date`, `return_type`, `reason`, `reason_description`, `refund_amount`, `refund_method`, `status`, `approved_by`, `approved_at`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', 'RET-202512-0001', NULL, '7', '5', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-09 22:33:11', NULL, '10', '2025-12-09 22:32:44', '2025-12-09 22:33:11'),
('2', 'RET-202512-0002', NULL, '6', '5', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-09 22:34:15', NULL, '10', '2025-12-09 22:34:03', '2025-12-09 22:34:15'),
('3', 'RET-202512-0003', NULL, '8', '6', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-09 23:06:51', NULL, '10', '2025-12-09 23:06:31', '2025-12-09 23:06:51'),
('4', 'RET-202512-0004', NULL, '10', '8', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-09 23:16:00', NULL, '10', '2025-12-09 23:15:34', '2025-12-09 23:16:00'),
('5', 'RET-202512-0005', NULL, '11', '9', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-09 23:18:37', NULL, '10', '2025-12-09 23:18:17', '2025-12-09 23:18:37'),
('6', 'RET-202512-0006', NULL, '12', '9', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-09 23:24:00', NULL, '10', '2025-12-09 23:23:46', '2025-12-09 23:24:00'),
('7', 'RET-202512-0007', NULL, '13', '9', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-10 00:26:07', NULL, '10', '2025-12-10 00:24:17', '2025-12-10 00:26:07'),
('8', 'RET-202512-0008', NULL, '9', '8', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-10 00:35:53', NULL, '10', '2025-12-10 00:34:57', '2025-12-10 00:35:53'),
('9', 'RET-202512-0009', NULL, '25', '5', '10', '2025-12-10', 'partial', 'customer_request', NULL, '1000.00', 'credit', 'approved', '1', '2025-12-10 00:38:23', NULL, '10', '2025-12-10 00:38:12', '2025-12-10 00:38:23');
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `role_permissions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('manager','accountant','sales','production') NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission` (`role`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `role_permissions`

-- --------------------------------------------------------
-- Table structure for table `salaries`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `salaries`;
CREATE TABLE `salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `month` date NOT NULL,
  `year` int(4) DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `base_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bonuses` decimal(15,2) DEFAULT 0.00,
  `collections_bonus` decimal(10,2) DEFAULT 0.00 COMMENT 'مكافآت التحصيلات 2%',
  `collections_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'إجمالي مبالغ التحصيلات للمندوب',
  `deductions` decimal(15,2) DEFAULT 0.00,
  `advances_deduction` decimal(10,2) DEFAULT 0.00 COMMENT 'خصم السلف',
  `settlements_advances` decimal(10,2) DEFAULT 0.00 COMMENT 'التسويات والسلف',
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL COMMENT 'ملاحظات',
  `accumulated_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'المبلغ التراكمي',
  `paid_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'المبلغ المدفوع',
  `status` enum('pending','approved','paid') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `month` (`month`),
  KEY `status` (`status`),
  KEY `salaries_ibfk_2` (`approved_by`),
  KEY `salaries_ibfk_3` (`created_by`),
  CONSTRAINT `salaries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salaries_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salaries_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `salaries` WRITE;
/*!40000 ALTER TABLE `salaries` DISABLE KEYS */;
INSERT INTO `salaries` (`id`, `user_id`, `month`, `year`, `hourly_rate`, `total_hours`, `base_amount`, `bonuses`, `collections_bonus`, `collections_amount`, `deductions`, `advances_deduction`, `settlements_advances`, `total_amount`, `notes`, `accumulated_amount`, `paid_amount`, `status`, `approved_by`, `paid_at`, `created_by`, `created_at`) VALUES
('115', '2', '2025-12-01', '2025', '25.00', '5.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند أول زيارة للموقع', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-08 23:55:33'),
('116', '17', '2025-12-01', '2025', '15.00', '0.00', '0.00', '10.00', '70.00', '3500.00', '0.00', '10.00', '1050.00', '80.00', 'تحديث تلقائي بعد تحصيل من صفحة العملاء', '40.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-08 23:55:34'),
('117', '10', '2025-12-01', '2025', '15.00', '53.02', '720.30', '110.00', '100.00', '5000.00', '90.30', '0.00', '600.00', '840.00', NULL, '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-08 23:55:34'),
('118', '11', '2025-12-01', '2025', '20.00', '221.08', '4321.60', '100.00', '0.00', '0.00', '100.00', '500.00', '800.00', '4221.60', 'حساب تلقائي بعد تسجيل الانصراف', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-08 23:55:34'),
('119', '16', '2025-12-01', '2025', '20.00', '5.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '500.00', '0.00', 'إنشاء تلقائي عند أول زيارة للموقع', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-08 23:55:34'),
('120', '4', '2025-12-01', '2025', '20.00', '42.20', '644.00', '0.00', '0.00', '0.00', '0.00', '250.00', '350.00', '644.00', 'حساب تلقائي بعد تسجيل الانصراف', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-08 23:55:34'),
('143', '18', '2025-12-01', '2025', '15.00', '0.00', '0.00', '0.00', '10.00', '500.00', '0.00', '0.00', '0.00', '30.00', 'تحديث تلقائي بعد بيع كاش من نقطة البيع', '10.00', '0.00', 'pending', NULL, NULL, '18', '2025-12-10 00:50:35'),
('144', '19', '2025-12-01', '2025', '20.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '2', '2025-12-10 03:25:13'),
('145', '11', '2025-11-01', '2025', '20.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:53'),
('146', '16', '2025-11-01', '2025', '20.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:53'),
('147', '4', '2025-11-01', '2025', '20.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:53'),
('148', '19', '2025-11-01', '2025', '20.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:53'),
('149', '2', '2025-11-01', '2025', '25.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:54'),
('150', '18', '2025-11-01', '2025', '15.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:54'),
('151', '17', '2025-11-01', '2025', '15.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:54'),
('152', '10', '2025-11-01', '2025', '15.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 06:14:54'),
('153', '20', '2025-12-01', '2025', '15.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 'إنشاء تلقائي عند فتح صفحة الرواتب - أول مرة في الشهر', '0.00', '0.00', 'pending', NULL, NULL, '1', '2025-12-10 21:27:10');
/*!40000 ALTER TABLE `salaries` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `salary_advances`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `salary_advances`;
CREATE TABLE `salary_advances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'الموظف',
  `amount` decimal(10,2) NOT NULL COMMENT 'مبلغ السلفة',
  `reason` text DEFAULT NULL COMMENT 'سبب السلفة',
  `request_date` date NOT NULL COMMENT 'تاريخ الطلب',
  `status` enum('pending','accountant_approved','manager_approved','rejected') DEFAULT 'pending' COMMENT 'حالة الطلب',
  `accountant_approved_by` int(11) DEFAULT NULL,
  `accountant_approved_at` timestamp NULL DEFAULT NULL,
  `manager_approved_by` int(11) DEFAULT NULL,
  `manager_approved_at` timestamp NULL DEFAULT NULL,
  `deducted_from_salary_id` int(11) DEFAULT NULL COMMENT 'الراتب الذي تم خصم السلفة منه',
  `total_salary_before_advance` decimal(10,2) DEFAULT NULL COMMENT 'الراتب الإجمالي قبل خصم السلفة',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `request_date` (`request_date`),
  KEY `accountant_approved_by` (`accountant_approved_by`),
  KEY `manager_approved_by` (`manager_approved_by`),
  KEY `deducted_from_salary_id` (`deducted_from_salary_id`),
  CONSTRAINT `salary_advances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_advances_ibfk_2` FOREIGN KEY (`accountant_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_advances_ibfk_3` FOREIGN KEY (`manager_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_advances_ibfk_4` FOREIGN KEY (`deducted_from_salary_id`) REFERENCES `salaries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `salary_advances` WRITE;
/*!40000 ALTER TABLE `salary_advances` DISABLE KEYS */;
INSERT INTO `salary_advances` (`id`, `user_id`, `amount`, `reason`, `request_date`, `status`, `accountant_approved_by`, `accountant_approved_at`, `manager_approved_by`, `manager_approved_at`, `deducted_from_salary_id`, `total_salary_before_advance`, `notes`, `created_at`) VALUES
('1', '2', '300.00', NULL, '2025-12-09', 'rejected', NULL, NULL, NULL, NULL, NULL, NULL, '10', '2025-12-08 17:36:26'),
('2', '2', '100.00', NULL, '2025-12-09', 'manager_approved', '1', '2025-12-08 17:42:54', '1', '2025-12-08 17:42:54', '6', '601.50', NULL, '2025-12-08 17:42:43'),
('3', '11', '500.00', NULL, '2025-12-09', 'manager_approved', '1', '2025-12-09 00:07:54', '1', '2025-12-09 00:07:54', '118', '1000.00', NULL, '2025-12-09 00:07:41'),
('4', '4', '100.00', NULL, '2025-12-10', 'manager_approved', '1', '2025-12-09 19:02:56', '1', '2025-12-09 19:02:56', '120', '480.20', NULL, '2025-12-09 18:34:45'),
('5', '4', '100.00', NULL, '2025-12-10', 'manager_approved', '1', '2025-12-09 19:12:46', '1', '2025-12-09 19:12:46', '120', '480.20', NULL, '2025-12-09 19:12:36'),
('6', '4', '50.00', NULL, '2025-12-10', 'manager_approved', '1', '2025-12-09 19:13:32', '1', '2025-12-09 19:13:32', '120', '480.20', NULL, '2025-12-09 19:13:20'),
('7', '17', '10.00', NULL, '2025-12-10', 'manager_approved', '1', '2025-12-09 20:38:50', '1', '2025-12-09 20:38:50', '116', '1020.00', NULL, '2025-12-09 20:38:41'),
('8', '4', '100.00', NULL, '2025-12-11', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-12-11 08:28:02');
/*!40000 ALTER TABLE `salary_advances` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `salary_payments`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `salary_payments`;
CREATE TABLE `salary_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) NOT NULL COMMENT 'معرف الراتب',
  `user_id` int(11) NOT NULL COMMENT 'معرف الموظف',
  `payment_amount` decimal(10,2) NOT NULL COMMENT 'مبلغ الدفعة',
  `payment_date` date NOT NULL COMMENT 'تاريخ الدفعة',
  `payment_method` varchar(50) DEFAULT NULL COMMENT 'طريقة الدفع',
  `notes` text DEFAULT NULL COMMENT 'ملاحظات',
  `created_by` int(11) DEFAULT NULL COMMENT 'من قام بالتسجيل',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `salary_id` (`salary_id`),
  KEY `user_id` (`user_id`),
  KEY `payment_date` (`payment_date`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `salary_payments_ibfk_1` FOREIGN KEY (`salary_id`) REFERENCES `salaries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_payments_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `salary_payments`

-- --------------------------------------------------------
-- Table structure for table `salary_settlements`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `salary_settlements`;
CREATE TABLE `salary_settlements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_id` int(11) NOT NULL COMMENT 'معرف الراتب',
  `user_id` int(11) NOT NULL COMMENT 'معرف الموظف',
  `settlement_amount` decimal(10,2) NOT NULL COMMENT 'مبلغ التسوية',
  `previous_accumulated` decimal(10,2) DEFAULT 0.00 COMMENT 'المبلغ التراكمي السابق',
  `remaining_after_settlement` decimal(10,2) DEFAULT 0.00 COMMENT 'المتبقي بعد التسوية',
  `settlement_type` enum('full','partial') DEFAULT 'partial' COMMENT 'نوع التسوية',
  `settlement_date` date NOT NULL COMMENT 'تاريخ التسوية',
  `notes` text DEFAULT NULL COMMENT 'ملاحظات',
  `created_by` int(11) DEFAULT NULL COMMENT 'من قام بالتسوية',
  `invoice_path` varchar(500) DEFAULT NULL COMMENT 'مسار فاتورة PDF',
  `telegram_sent` tinyint(1) DEFAULT 0 COMMENT 'تم الإرسال إلى تليجرام',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `salary_id` (`salary_id`),
  KEY `user_id` (`user_id`),
  KEY `settlement_date` (`settlement_date`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `salary_settlements_ibfk_1` FOREIGN KEY (`salary_id`) REFERENCES `salaries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_settlements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_settlements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `salary_settlements` WRITE;
/*!40000 ALTER TABLE `salary_settlements` DISABLE KEYS */;
INSERT INTO `salary_settlements` (`id`, `salary_id`, `user_id`, `settlement_amount`, `previous_accumulated`, `remaining_after_settlement`, `settlement_type`, `settlement_date`, `notes`, `created_by`, `invoice_path`, `telegram_sent`, `created_at`) VALUES
('1', '6', '2', '300.00', '601.50', '301.50', 'partial', '2025-12-09', '', '1', 'invoices/salary_settlements/settlement_1_20251209034216.html', '0', '2025-12-08 17:42:16'),
('2', '6', '2', '100.00', '501.50', '101.50', 'partial', '2025-12-09', '', '1', 'invoices/salary_settlements/settlement_2_20251209062111.html', '0', '2025-12-08 20:21:11'),
('3', '5', '10', '100.00', '361.05', '261.05', 'partial', '2025-12-09', '', '1', 'invoices/salary_settlements/settlement_3_20251209062200.html', '0', '2025-12-08 20:22:00'),
('4', '4', '4', '100.00', '481.20', '381.20', 'partial', '2025-12-09', '', '1', 'invoices/salary_settlements/settlement_4_20251209063628.html', '0', '2025-12-08 20:36:28'),
('5', '118', '11', '100.00', '1000.00', '400.00', 'partial', '2025-12-09', '', '1', 'invoices/salary_settlements/settlement_5_20251209100912.html', '0', '2025-12-09 00:09:12'),
('6', '117', '10', '500.00', '1000.00', '500.00', 'partial', '2025-12-17', '', '1', 'invoices/salary_settlements/settlement_6_20251210035718.html', '0', '2025-12-09 17:57:18'),
('7', '120', '4', '100.00', '480.20', '380.20', 'partial', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_7_20251210040145.html', '0', '2025-12-09 18:01:45'),
('8', '116', '17', '500.00', '1000.00', '500.00', 'partial', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_8_20251210041307.html', '0', '2025-12-09 18:13:07'),
('9', '119', '16', '500.00', '1000.00', '500.00', 'partial', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_9_20251210041725.html', '0', '2025-12-09 18:17:25'),
('10', '118', '11', '100.00', '4221.60', '3521.60', 'partial', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_10_20251210043403.html', '0', '2025-12-09 18:34:03'),
('11', '118', '11', '100.00', '4221.60', '3421.60', 'partial', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_11_20251210050151.html', '0', '2025-12-09 19:01:51'),
('12', '116', '17', '500.00', '1000.00', '0.00', 'full', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_12_20251210060225.html', '0', '2025-12-09 20:02:25'),
('13', '116', '17', '20.00', '1030.00', '0.00', 'full', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_13_20251210063937.html', '0', '2025-12-09 20:39:37'),
('14', '116', '17', '20.00', '1050.00', '0.00', 'full', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_14_20251210065137.html', '0', '2025-12-09 20:51:37'),
('15', '117', '10', '100.00', '700.00', '100.00', 'partial', '2025-12-10', '', '1', 'invoices/salary_settlements/settlement_15_20251210072902.html', '0', '2025-12-09 21:29:02');
/*!40000 ALTER TABLE `salary_settlements` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `sales`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `date` date NOT NULL,
  `salesperson_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected','completed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `product_id` (`product_id`),
  KEY `salesperson_id` (`salesperson_id`),
  KEY `approved_by` (`approved_by`),
  KEY `date` (`date`),
  KEY `status` (`status`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`salesperson_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` (`id`, `customer_id`, `product_id`, `quantity`, `price`, `total`, `date`, `salesperson_id`, `status`, `approved_by`, `approved_at`, `created_at`) VALUES
('1', '1', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '17', 'completed', NULL, NULL, '2025-12-09 20:03:22'),
('2', '2', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '17', 'completed', NULL, NULL, '2025-12-09 20:40:25'),
('3', '2', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '17', 'completed', NULL, NULL, '2025-12-09 20:50:35'),
('4', '3', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '17', 'completed', NULL, NULL, '2025-12-09 20:51:59'),
('5', '5', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 22:26:09'),
('6', '5', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 22:26:54'),
('7', '5', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 22:28:53'),
('8', '6', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 23:06:05'),
('9', '8', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 23:12:09'),
('10', '8', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 23:12:34'),
('11', '9', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 23:17:54'),
('12', '9', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 23:22:19'),
('13', '9', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-09 23:35:34'),
('14', '10', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:42:29'),
('15', '10', '2', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:43:35'),
('16', '10', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:47:36'),
('17', '10', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:48:38'),
('18', '11', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:54:06'),
('19', '10', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:54:50'),
('20', '12', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-09 23:56:21'),
('21', '12', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-10 00:25:10'),
('22', '12', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-10 00:25:40'),
('23', '5', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-10 00:37:03'),
('24', '8', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '10', 'completed', NULL, NULL, '2025-12-10 00:38:57'),
('25', '13', '4', '1.00', '1000.00', '1000.00', '2025-12-10', '18', 'completed', NULL, NULL, '2025-12-10 00:50:34'),
('26', '13', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '18', 'completed', NULL, NULL, '2025-12-10 00:51:18'),
('27', '16', '10', '1.00', '500.00', '500.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-10 06:57:04'),
('28', '16', '7', '1.00', '1000.00', '1000.00', '2025-12-10', '1', 'completed', NULL, NULL, '2025-12-10 06:57:04'),
('29', '10', '4', '12.00', '1000.00', '12000.00', '2025-12-11', '1', 'completed', NULL, NULL, '2025-12-11 02:37:47'),
('30', '10', '4', '6.00', '1000.00', '6000.00', '2025-12-11', '1', 'completed', NULL, NULL, '2025-12-11 02:37:47'),
('31', '10', '4', '6.00', '1000.00', '6000.00', '2025-12-11', '1', 'completed', NULL, NULL, '2025-12-11 02:37:47'),
('32', '10', '4', '6.00', '1000.00', '6000.00', '2025-12-11', '1', 'completed', NULL, NULL, '2025-12-11 02:37:47'),
('33', '10', '4', '2.00', '1000.00', '2000.00', '2025-12-11', '1', 'completed', NULL, NULL, '2025-12-11 02:37:47'),
('34', '15', '7', '1.00', '1000.00', '1000.00', '2025-12-11', '2', 'completed', NULL, NULL, '2025-12-11 05:54:21'),
('35', '17', '9', '20.00', '500.00', '10000.00', '2025-12-11', '2', 'completed', NULL, NULL, '2025-12-11 05:54:40');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `sales_batch_numbers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sales_batch_numbers`;
CREATE TABLE `sales_batch_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `invoice_item_id` int(11) DEFAULT NULL,
  `batch_number_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `batch_number_id` (`batch_number_id`),
  CONSTRAINT `sales_batch_numbers_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_batch_numbers_ibfk_2` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_batch_numbers_ibfk_3` FOREIGN KEY (`batch_number_id`) REFERENCES `batch_numbers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `sales_batch_numbers` WRITE;
/*!40000 ALTER TABLE `sales_batch_numbers` DISABLE KEYS */;
INSERT INTO `sales_batch_numbers` (`id`, `sale_id`, `invoice_item_id`, `batch_number_id`, `quantity`, `created_at`) VALUES
('1', NULL, '1', '2', '1', '2025-12-09 20:03:22'),
('2', NULL, '2', '2', '1', '2025-12-09 20:40:25'),
('3', NULL, '3', '2', '1', '2025-12-09 20:50:35'),
('4', NULL, '4', '2', '1', '2025-12-09 20:51:59'),
('5', NULL, '5', '2', '1', '2025-12-09 22:26:09'),
('6', NULL, '6', '2', '1', '2025-12-09 22:26:54'),
('7', NULL, '7', '2', '1', '2025-12-09 22:28:53'),
('8', NULL, '8', '2', '1', '2025-12-09 23:06:05'),
('9', NULL, '19', '2', '1', '2025-12-09 23:48:38'),
('10', NULL, '27', '2', '1', '2025-12-10 00:50:34'),
('11', NULL, '34', '12', '12', '2025-12-11 02:37:47'),
('12', NULL, '35', '11', '6', '2025-12-11 02:37:47'),
('13', NULL, '36', '10', '6', '2025-12-11 02:37:47'),
('14', NULL, '37', '9', '6', '2025-12-11 02:37:47'),
('15', NULL, '38', '2', '2', '2025-12-11 02:37:47');
/*!40000 ALTER TABLE `sales_batch_numbers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `sales_returns`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sales_returns`;
CREATE TABLE `sales_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `return_number` varchar(50) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_rep_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `return_type` enum('full','partial') DEFAULT 'full',
  `reason` enum('defective','wrong_item','customer_request','other') DEFAULT 'customer_request',
  `reason_description` text DEFAULT NULL,
  `refund_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `refund_method` enum('cash','credit','exchange') DEFAULT 'cash',
  `status` enum('pending','approved','rejected','processed') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_number` (`return_number`),
  KEY `invoice_id` (`invoice_id`),
  KEY `sale_id` (`sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_rep_id` (`sales_rep_id`),
  KEY `status` (`status`),
  KEY `sales_returns_ibfk_5` (`approved_by`),
  KEY `sales_returns_ibfk_6` (`processed_by`),
  KEY `sales_returns_ibfk_7` (`created_by`),
  CONSTRAINT `sales_returns_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_returns_ibfk_4` FOREIGN KEY (`sales_rep_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_returns_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_6` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_returns_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `sales_returns`

-- --------------------------------------------------------
-- Table structure for table `sesame_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sesame_stock`;
CREATE TABLE `sesame_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالكيلوجرام',
  `converted_to_tahini_quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'إجمالي كمية التحويل إلى طحينة بالكيلوجرام',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الكيلو',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`),
  CONSTRAINT `sesame_stock_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `sesame_stock` WRITE;
/*!40000 ALTER TABLE `sesame_stock` DISABLE KEYS */;
INSERT INTO `sesame_stock` (`id`, `supplier_id`, `quantity`, `converted_to_tahini_quantity`, `unit_price`, `notes`, `created_at`, `updated_at`) VALUES
('1', '5', '0.000', '200.000', NULL, NULL, '2025-12-10 02:25:51', '2025-12-10 05:56:32');
/*!40000 ALTER TABLE `sesame_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `sessions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`),
  KEY `last_activity` (`last_activity`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`id`, `user_id`, `session_id`, `ip_address`, `user_agent`, `created_at`, `expires_at`, `last_activity`) VALUES
('35', '2', '9d5f9b391abb8273134c5f4fcdc56ace', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2025-12-16 01:52:06', '2025-12-23 02:14:03', '2025-12-16 02:14:03');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `shipping_companies`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `shipping_companies`;
CREATE TABLE `shipping_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `shipping_companies_created_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shipping_companies_updated_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `shipping_companies` WRITE;
/*!40000 ALTER TABLE `shipping_companies` DISABLE KEYS */;
INSERT INTO `shipping_companies` (`id`, `name`, `contact_person`, `phone`, `email`, `address`, `balance`, `status`, `notes`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
('1', '11', NULL, NULL, NULL, NULL, '0.00', 'active', NULL, '1', '1', '2025-12-09 23:41:08', '2025-12-09 23:43:35'),
('2', 'تليجراف', 'حسن', '011000', NULL, NULL, '10000.00', 'active', NULL, '1', '2', '2025-12-10 06:59:11', '2025-12-11 06:05:07');
/*!40000 ALTER TABLE `shipping_companies` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `shipping_company_order_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `shipping_company_order_items`;
CREATE TABLE `shipping_company_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_id` (`batch_id`),
  CONSTRAINT `shipping_company_order_items_order_fk` FOREIGN KEY (`order_id`) REFERENCES `shipping_company_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shipping_company_order_items_product_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `shipping_company_order_items` WRITE;
/*!40000 ALTER TABLE `shipping_company_order_items` DISABLE KEYS */;
INSERT INTO `shipping_company_order_items` (`id`, `order_id`, `product_id`, `batch_id`, `quantity`, `unit_price`, `total_price`, `created_at`) VALUES
('1', '1', '7', NULL, '1.00', '1000.00', '1000.00', '2025-12-09 23:41:53'),
('2', '2', '7', NULL, '1.00', '1000.00', '1000.00', '2025-12-09 23:42:17'),
('3', '3', '2', '2', '1.00', '1000.00', '1000.00', '2025-12-09 23:43:09'),
('4', '4', '2', '2', '1.00', '1000.00', '1000.00', '2025-12-09 23:43:27'),
('5', '5', '9', NULL, '20.00', '500.00', '10000.00', '2025-12-10 07:00:17'),
('6', '5', '7', NULL, '9.00', '1000.00', '9000.00', '2025-12-10 07:00:17'),
('7', '6', '9', NULL, '20.00', '500.00', '10000.00', '2025-12-10 07:01:26'),
('8', '7', '7', '7', '1.00', '1000.00', '1000.00', '2025-12-11 05:53:26'),
('9', '8', '7', NULL, '10.00', '1000.00', '10000.00', '2025-12-11 06:03:50'),
('10', '9', '7', NULL, '10.00', '1000.00', '10000.00', '2025-12-11 06:05:07');
/*!40000 ALTER TABLE `shipping_company_order_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `shipping_company_orders`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `shipping_company_orders`;
CREATE TABLE `shipping_company_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `shipping_company_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('assigned','in_transit','delivered','cancelled') NOT NULL DEFAULT 'assigned',
  `handed_over_at` timestamp NULL DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `shipping_company_id` (`shipping_company_id`),
  KEY `customer_id` (`customer_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `status` (`status`),
  KEY `shipping_company_orders_created_fk` (`created_by`),
  KEY `shipping_company_orders_updated_fk` (`updated_by`),
  CONSTRAINT `shipping_company_orders_company_fk` FOREIGN KEY (`shipping_company_id`) REFERENCES `shipping_companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shipping_company_orders_created_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shipping_company_orders_customer_fk` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shipping_company_orders_invoice_fk` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shipping_company_orders_updated_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `shipping_company_orders` WRITE;
/*!40000 ALTER TABLE `shipping_company_orders` DISABLE KEYS */;
INSERT INTO `shipping_company_orders` (`id`, `order_number`, `shipping_company_id`, `customer_id`, `invoice_id`, `total_amount`, `status`, `handed_over_at`, `delivered_at`, `notes`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
('1', 'SHIP-202512-0001', '1', '1', '14', '1000.00', 'cancelled', '2025-12-09 23:41:53', NULL, NULL, '1', '1', '2025-12-09 23:41:53', '2025-12-09 23:42:03'),
('2', 'SHIP-202512-0002', '1', '1', '15', '1000.00', 'delivered', '2025-12-09 23:42:17', '2025-12-09 23:42:29', NULL, '1', '1', '2025-12-09 23:42:17', '2025-12-09 23:42:29'),
('3', 'SHIP-202512-0003', '1', '1', '16', '1000.00', 'cancelled', '2025-12-09 23:43:09', NULL, NULL, '1', '1', '2025-12-09 23:43:09', '2025-12-09 23:43:18'),
('4', 'SHIP-202512-0004', '1', '1', '17', '1000.00', 'delivered', '2025-12-09 23:43:27', '2025-12-09 23:43:35', NULL, '1', '1', '2025-12-09 23:43:27', '2025-12-09 23:43:35'),
('5', 'SHIP-202512-0005', '2', '8', '30', '19000.00', 'cancelled', '2025-12-10 07:00:17', NULL, NULL, '1', '1', '2025-12-10 07:00:17', '2025-12-10 07:01:07'),
('6', 'SHIP-202512-0006', '2', '8', '31', '10000.00', 'delivered', '2025-12-10 07:01:26', '2025-12-11 05:54:40', NULL, '1', '2', '2025-12-10 07:01:26', '2025-12-11 05:54:40'),
('7', 'SHIP-202512-0007', '2', '5', '33', '1000.00', 'delivered', '2025-12-11 05:53:26', '2025-12-11 05:54:21', NULL, '2', '2', '2025-12-11 05:53:26', '2025-12-11 05:54:21'),
('8', 'SHIP-202512-0008', '2', '4', '34', '10000.00', 'cancelled', '2025-12-11 06:03:50', NULL, NULL, '2', '2', '2025-12-11 06:03:50', '2025-12-11 06:04:21'),
('9', 'SHIP-202512-0009', '2', '4', '35', '10000.00', 'in_transit', '2025-12-11 06:05:07', NULL, NULL, '2', NULL, '2025-12-11 06:05:07', NULL);
/*!40000 ALTER TABLE `shipping_company_orders` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `supplier_balance_history`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `supplier_balance_history`;
CREATE TABLE `supplier_balance_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `change_amount` decimal(15,2) NOT NULL,
  `previous_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `new_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `type` enum('topup','payment') NOT NULL,
  `notes` text DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'ID of related record (financial transaction, etc)',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `type` (`type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `supplier_balance_history_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_balance_history_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `supplier_balance_history` WRITE;
/*!40000 ALTER TABLE `supplier_balance_history` DISABLE KEYS */;
INSERT INTO `supplier_balance_history` (`id`, `supplier_id`, `change_amount`, `previous_balance`, `new_balance`, `type`, `notes`, `reference_id`, `created_by`, `created_at`) VALUES
('1', '8', '1000.00', '0.00', '1000.00', 'topup', NULL, NULL, '1', '2025-12-09 19:59:29'),
('2', '8', '-1000.00', '1000.00', '0.00', 'payment', NULL, '3', '1', '2025-12-09 19:59:38'),
('3', '8', '1000.00', '0.00', '1000.00', 'topup', NULL, NULL, '1', '2025-12-10 01:56:59'),
('4', '8', '-500.00', '1000.00', '500.00', 'payment', NULL, '5', '1', '2025-12-10 01:57:23'),
('5', '8', '-400.00', '500.00', '100.00', 'payment', NULL, '7', '1', '2025-12-15 02:31:51'),
('6', '8', '-1.00', '100.00', '99.00', 'payment', NULL, '8', '1', '2025-12-15 02:32:26'),
('7', '8', '-1.00', '99.00', '98.00', 'payment', NULL, '9', '1', '2025-12-15 02:35:40');
/*!40000 ALTER TABLE `supplier_balance_history` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `suppliers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(20) DEFAULT NULL,
  `type` enum('honey','packaging','nuts','olive_oil','derivatives','beeswax','sesame') DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` (`id`, `supplier_code`, `type`, `name`, `contact_person`, `phone`, `email`, `address`, `balance`, `status`, `created_at`, `updated_at`) VALUES
('1', 'HNY001', 'honey', 'مايكل ', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:49:20', '2025-12-08 17:20:54'),
('2', 'HNY002', 'honey', 'عمرو ', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:50:53', '2025-12-08 17:20:56'),
('3', 'NUT001', 'nuts', ' مورد مكسرات', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:51:24', '2025-12-08 17:20:21'),
('4', 'PKG001', 'packaging', 'مورد ادوات تعبئه', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:51:39', '2025-12-08 17:20:16'),
('5', 'SES001', 'sesame', 'مورد سمسم', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:51:54', '2025-12-08 17:20:26'),
('6', 'OIL001', 'olive_oil', ' مورد زيت', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:52:09', '2025-12-08 17:20:35'),
('7', 'DRV001', 'derivatives', ' مورد مشتقات', NULL, NULL, NULL, NULL, '0.00', 'active', '2025-11-22 00:52:29', '2025-12-08 17:20:39'),
('8', 'WAX001', 'beeswax', 'مورد شمع', NULL, NULL, NULL, NULL, '98.00', 'active', '2025-11-22 00:52:43', '2025-12-15 02:35:40');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `system_daily_jobs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `system_daily_jobs`;
CREATE TABLE `system_daily_jobs` (
  `job_key` varchar(120) NOT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `last_notified_at` datetime DEFAULT NULL,
  `last_notification_hash` varchar(128) DEFAULT NULL,
  `last_file_path` varchar(512) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`job_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `system_daily_jobs` WRITE;
/*!40000 ALTER TABLE `system_daily_jobs` DISABLE KEYS */;
INSERT INTO `system_daily_jobs` (`job_key`, `last_sent_at`, `last_notified_at`, `last_notification_hash`, `last_file_path`, `updated_at`) VALUES
('daily_backup_telegram', '2025-12-12 01:44:21', NULL, NULL, 'backup_if0_40278066_co_db_2025-12-12_01-44-20.sql.gz', '2025-12-13 04:10:02'),
('daily_consumption_report', '2025-12-08 02:30:43', NULL, NULL, NULL, '2025-12-07 16:30:43'),
('low_stock_report', '2025-12-16 01:03:32', NULL, NULL, 'low_stock\\low-stock-report-20251216-010332.html', '2025-12-16 01:03:32'),
('packaging_low_stock_alert', '2025-12-16 01:03:33', NULL, NULL, NULL, '2025-12-16 01:03:33');
/*!40000 ALTER TABLE `system_daily_jobs` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `system_scheduled_jobs`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `system_scheduled_jobs`;
CREATE TABLE `system_scheduled_jobs` (
  `job_key` varchar(120) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`job_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `system_scheduled_jobs`

-- --------------------------------------------------------
-- Table structure for table `system_settings`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=293332 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` (`id`, `key`, `value`, `description`, `updated_at`) VALUES
('1', 'low_stock_report_status', '{\"date\":\"2025-12-16\",\"status\":\"already_sent\",\"completed_at\":\"2025-12-16 01:03:32\",\"counts\":{\"honey\":5,\"olive_oil\":0,\"beeswax\":0,\"derivatives\":0,\"nuts\":0},\"file_deleted\":false,\"report_path\":\"low_stock\\\\low-stock-report-20251216-010332.html\",\"viewer_path\":\"reports/view.php?type=low_stock&token=4bd99575e255d33e5ee0030b28c0716e\",\"access_token\":\"4bd99575e255d33e5ee0030b28c0716e\",\"report_url\":\"/reports/view.php?type=low_stock&token=4bd99575e255d33e5ee0030b28c0716e\",\"print_url\":\"/reports/view.php?type=low_stock&token=4bd99575e255d33e5ee0030b28c0716e&print=1\",\"absolute_report_url\":\"http://localhost:8000//reports/view.php?type=low_stock&token=4bd99575e255d33e5ee0030b28c0716e\",\"absolute_print_url\":\"http://localhost:8000//reports/view.php?type=low_stock&token=4bd99575e255d33e5ee0030b28c0716e&print=1\",\"checked_at\":\"2025-12-16 02:14:22\",\"last_sent_at\":\"2025-12-16 01:03:32\"}', NULL, '2025-12-16 02:14:22'),
('3', 'packaging_alert_status', '{\"date\":\"2025-12-16\",\"status\":\"already_sent\",\"completed_at\":\"2025-12-16 01:03:33\",\"counts\":{\"total_items\":34,\"by_type\":{\"أغطية\":8,\"أكياس\":1,\"طبات\":5,\"عبوات بلاستيكية\":7,\"عبوات زجاجية\":10,\"لوازم التعبئة\":2,\"ملصقات\":1}},\"preview\":[],\"report_path\":\"alerts\\\\packaging-low-stock-20251216-010332.html\",\"viewer_path\":\"reports/view.php?type=packaging&token=1a19e9e7582df0beceb2fb1eeec43f6c\",\"access_token\":\"1a19e9e7582df0beceb2fb1eeec43f6c\",\"report_url\":\"/reports/view.php?type=packaging&token=1a19e9e7582df0beceb2fb1eeec43f6c\",\"print_url\":\"/reports/view.php?type=packaging&token=1a19e9e7582df0beceb2fb1eeec43f6c&print=1\",\"absolute_report_url\":\"http://localhost:8000//reports/view.php?type=packaging&token=1a19e9e7582df0beceb2fb1eeec43f6c\",\"absolute_print_url\":\"http://localhost:8000//reports/view.php?type=packaging&token=1a19e9e7582df0beceb2fb1eeec43f6c&print=1\",\"file_deleted\":false,\"checked_at\":\"2025-12-16 02:14:22\",\"last_sent_at\":\"2025-12-16 01:03:33\"}', NULL, '2025-12-16 02:14:22'),
('5', 'daily_backup_status', '{\"date\":\"2025-12-16\",\"status\":\"running\",\"checked_at\":\"2025-12-16 02:14:22\",\"started_at\":\"2025-12-16 02:14:22\"}', NULL, '2025-12-16 02:14:22'),
('9198', 'daily_consumption_report_status', '{\"date\":\"2025-12-08\",\"target_date\":\"2025-12-07\",\"status\":\"completed_no_data\",\"checked_at\":\"2025-12-08 02:30:43\",\"started_at\":\"2025-12-08 02:30:43\",\"completed_at\":\"2025-12-08 02:30:43\",\"message\":\"لا توجد بيانات للفترة المحددة. يرجى اختيار فترة تحتوي على استهلاك أو تالف.\"}', NULL, '2025-12-07 16:30:43'),
('93068', 'salaries_initialized_2025_12', '1', NULL, '2025-12-08 23:55:34');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `tahini_stock`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `tahini_stock`;
CREATE TABLE `tahini_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000 COMMENT 'الكمية بالكيلوجرام',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'سعر الكيلو',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id_idx` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `tahini_stock` WRITE;
/*!40000 ALTER TABLE `tahini_stock` DISABLE KEYS */;
INSERT INTO `tahini_stock` (`id`, `supplier_id`, `quantity`, `unit_price`, `notes`, `created_at`, `updated_at`) VALUES
('1', '5', '200.000', NULL, 'إضافة باقي عملية التحويل: 0.400 كجم', '2025-12-10 05:56:32', '2025-12-10 05:57:27');
/*!40000 ALTER TABLE `tahini_stock` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `tasks`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('pending','received','in_progress','completed','cancelled') DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `related_type` varchar(50) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `due_date` (`due_date`),
  KEY `tasks_ibfk_3` (`product_id`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`id`, `title`, `description`, `assigned_to`, `created_by`, `priority`, `status`, `due_date`, `completed_at`, `received_at`, `started_at`, `related_type`, `related_id`, `product_id`, `quantity`, `notes`, `created_at`, `updated_at`) VALUES
('13', '1', NULL, '11', '1', 'normal', 'cancelled', NULL, NULL, '2025-12-14 15:12:57', NULL, 'manager_quality', NULL, NULL, NULL, 'العمال المخصصون: انتاج 2, انتاج 3, عامل الإنتاج الأول, عبدالله صالح\n[ASSIGNED_WORKERS_IDS]:11,16,4,19', '2025-12-14 15:05:35', '2025-12-15 02:05:13'),
('14', '2', NULL, '11', '1', 'normal', 'cancelled', NULL, NULL, '2025-12-14 15:12:15', NULL, 'manager_quality', NULL, NULL, NULL, 'العمال المخصصون: انتاج 2, انتاج 3, عامل الإنتاج الأول, عبدالله صالح\n[ASSIGNED_WORKERS_IDS]:11,16,4,19', '2025-12-14 15:07:28', '2025-12-14 15:13:33');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `telegram_invoices`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `telegram_invoices`;
CREATE TABLE `telegram_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL COMMENT 'معرف الفاتورة من جدول invoices',
  `invoice_number` varchar(100) DEFAULT NULL COMMENT 'رقم الفاتورة',
  `invoice_type` varchar(50) DEFAULT 'sales_pos_invoice' COMMENT 'نوع الفاتورة (sales_pos_invoice, manager_pos_invoice, etc.)',
  `token` varchar(32) NOT NULL COMMENT 'معرف أمني للوصول للفاتورة',
  `html_content` longtext NOT NULL COMMENT 'محتوى HTML للفاتورة',
  `relative_path` varchar(255) DEFAULT NULL COMMENT 'مسار الملف النسبي (إن وجد)',
  `filename` varchar(255) DEFAULT NULL COMMENT 'اسم الملف',
  `summary` text DEFAULT NULL COMMENT 'ملخص الفاتورة (JSON)',
  `telegram_sent` tinyint(1) DEFAULT 0 COMMENT 'تم الإرسال إلى Telegram',
  `sent_at` datetime DEFAULT NULL COMMENT 'تاريخ الإرسال إلى Telegram',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `invoice_id` (`invoice_id`),
  KEY `invoice_number` (`invoice_number`),
  KEY `invoice_type` (`invoice_type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `telegram_invoices_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول تخزين الفواتير المرسلة إلى Telegram';

LOCK TABLES `telegram_invoices` WRITE;
/*!40000 ALTER TABLE `telegram_invoices` DISABLE KEYS */;
INSERT INTO `telegram_invoices` (`id`, `invoice_id`, `invoice_number`, `invoice_type`, `token`, `html_content`, `relative_path`, `filename`, `summary`, `telegram_sent`, `sent_at`, `created_at`, `updated_at`) VALUES
('1', '1', 'INV-202512-0001', 'sales_pos_invoice', '111d7e3bd3cae872', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0001</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                    <div class=\"info-item\">هاتف: 123</div>\n                                                    <div class=\"info-item\">العنوان: 1234</div>\n                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات 2</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">0.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-060322-INV-202512-0001-111d7e3bd3cae872.html', 'pos-invoice-20251210-060322-INV-202512-0001-111d7e3bd3cae872.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 06:03:22', '2025-12-09 20:03:22', '2025-12-09 20:03:22'),
('2', '2', 'INV-202512-0002', 'sales_pos_invoice', 'c5a0f8bdc21dbb58', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0002</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات 2</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">0.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-064025-INV-202512-0002-c5a0f8bdc21dbb58.html', 'pos-invoice-20251210-064025-INV-202512-0002-c5a0f8bdc21dbb58.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":500,\"due_before_credit\":500,\"credit_used\":0,\"due\":500}', '1', '2025-12-10 06:40:25', '2025-12-09 20:40:25', '2025-12-09 20:40:25'),
('3', '3', 'INV-202512-0003', 'sales_pos_invoice', 'a9feaefede954a0b', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0003</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-partial\">مدفوع جزئياً</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات 2</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">500.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            500.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-065035-INV-202512-0003-a9feaefede954a0b.html', 'pos-invoice-20251210-065035-INV-202512-0003-a9feaefede954a0b.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":500,\"due_before_credit\":500,\"credit_used\":0,\"due\":500}', '1', '2025-12-10 06:50:35', '2025-12-09 20:50:35', '2025-12-09 20:50:35'),
('4', '4', 'INV-202512-0004', 'sales_pos_invoice', '95193514e9812788', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0004</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">4</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات 2</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            1,000.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-065159-INV-202512-0004-95193514e9812788.html', 'pos-invoice-20251210-065159-INV-202512-0004-95193514e9812788.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":0,\"due\":1000}', '1', '2025-12-10 06:51:59', '2025-12-09 20:51:59', '2025-12-09 20:51:59'),
('5', '5', 'INV-202512-0005', 'sales_pos_invoice', 'ef335bc8f78edad2', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0005</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">1,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-082609-INV-202512-0005-ef335bc8f78edad2.html', 'pos-invoice-20251210-082609-INV-202512-0005-ef335bc8f78edad2.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 08:26:09', '2025-12-09 22:26:09', '2025-12-09 22:26:09'),
('6', '6', 'INV-202512-0006', 'sales_pos_invoice', '684e8de46bbbfe26', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0006</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-partial\">مدفوع جزئياً</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">500.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            500.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-082654-INV-202512-0006-684e8de46bbbfe26.html', 'pos-invoice-20251210-082654-INV-202512-0006-684e8de46bbbfe26.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":500,\"due_before_credit\":500,\"credit_used\":0,\"due\":500}', '1', '2025-12-10 08:26:54', '2025-12-09 22:26:54', '2025-12-09 22:26:54'),
('7', '7', 'INV-202512-0007', 'sales_pos_invoice', 'd04811549f2eecea', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0007</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            1,000.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-082853-INV-202512-0007-d04811549f2eecea.html', 'pos-invoice-20251210-082853-INV-202512-0007-d04811549f2eecea.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":0,\"due\":1000}', '1', '2025-12-10 08:28:53', '2025-12-09 22:28:53', '2025-12-09 22:28:53'),
('8', '8', 'INV-202512-0008', 'sales_pos_invoice', '447e6639b95ca135', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0008</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">3</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">1,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-090605-INV-202512-0008-447e6639b95ca135.html', 'pos-invoice-20251210-090605-INV-202512-0008-447e6639b95ca135.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 09:06:05', '2025-12-09 23:06:05', '2025-12-09 23:06:05'),
('9', '9', 'INV-202512-0009', 'sales_pos_invoice', '1b9532b4ac76970a', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0009</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">5</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            1,000.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-091209-INV-202512-0009-1b9532b4ac76970a.html', 'pos-invoice-20251210-091209-INV-202512-0009-1b9532b4ac76970a.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":0,\"due\":1000}', '1', '2025-12-10 09:12:09', '2025-12-09 23:12:09', '2025-12-09 23:12:09'),
('10', '10', 'INV-202512-0010', 'sales_pos_invoice', 'caccecaa81c0f22b', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0010</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">5</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            1,000.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-091234-INV-202512-0010-caccecaa81c0f22b.html', 'pos-invoice-20251210-091234-INV-202512-0010-caccecaa81c0f22b.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":0,\"due\":1000}', '1', '2025-12-10 09:12:34', '2025-12-09 23:12:34', '2025-12-09 23:12:34'),
('11', '11', 'INV-202512-0011', 'sales_pos_invoice', '00bf5491da761a5d', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0011</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">6</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">1,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-091754-INV-202512-0011-00bf5491da761a5d.html', 'pos-invoice-20251210-091754-INV-202512-0011-00bf5491da761a5d.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 09:17:54', '2025-12-09 23:17:54', '2025-12-09 23:17:54'),
('12', '12', 'INV-202512-0012', 'sales_pos_invoice', '166c2c41f0e6d426', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0012</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">6</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                                <div class=\"summary-row\">\n                            <span>المدفوع من رصيد العميل</span>\n                            <strong class=\"text-info\">1,000.00 ج.م</strong>\n                        </div>\n                                        <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-092219-INV-202512-0012-166c2c41f0e6d426.html', 'pos-invoice-20251210-092219-INV-202512-0012-166c2c41f0e6d426.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":1000,\"credit_used\":1000,\"due\":0}', '1', '2025-12-10 09:22:19', '2025-12-09 23:22:19', '2025-12-09 23:22:19'),
('13', '13', 'INV-202512-0013', 'sales_pos_invoice', 'e697c8bf05c56320', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0013</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">6</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                                <div class=\"summary-row\">\n                            <span>المدفوع من رصيد العميل</span>\n                            <strong class=\"text-info\">1,000.00 ج.م</strong>\n                        </div>\n                                        <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-093534-INV-202512-0013-e697c8bf05c56320.html', 'pos-invoice-20251210-093534-INV-202512-0013-e697c8bf05c56320.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":1000,\"credit_used\":1000,\"due\":0}', '1', '2025-12-10 09:35:34', '2025-12-09 23:35:34', '2025-12-09 23:35:34'),
('14', '18', 'INV-202512-0018', 'manager_pos_invoice', 'ee2d9479f1e51769', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0018</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">0.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-094736-INV-202512-0018-ee2d9479f1e51769.html', 'pos-invoice-20251210-094736-INV-202512-0018-ee2d9479f1e51769.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 09:47:36', '2025-12-09 23:47:36', '2025-12-09 23:47:36'),
('15', '19', 'INV-202512-0019', 'manager_pos_invoice', '2b013b512ed6c479', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0019</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">0.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-094838-INV-202512-0019-2b013b512ed6c479.html', 'pos-invoice-20251210-094838-INV-202512-0019-2b013b512ed6c479.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":1000,\"due\":0}', '1', '2025-12-10 09:48:38', '2025-12-09 23:48:38', '2025-12-09 23:48:38'),
('16', '20', 'INV-202512-0020', 'manager_pos_invoice', 'e867f2bb24b0e48f', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0020</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-095406-INV-202512-0020-e867f2bb24b0e48f.html', 'pos-invoice-20251210-095406-INV-202512-0020-e867f2bb24b0e48f.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":0,\"due\":1000}', '1', '2025-12-10 09:54:07', '2025-12-09 23:54:06', '2025-12-09 23:54:07'),
('17', '21', 'INV-202512-0021', 'manager_pos_invoice', 'dcd9a2ee34c22523', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0021</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                                <div class=\"summary-row\">\n                            <span>المدفوع من رصيد العميل</span>\n                            <strong class=\"text-info\">1,000.00 ج.م</strong>\n                        </div>\n                                        <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-095451-INV-202512-0021-dcd9a2ee34c22523.html', 'pos-invoice-20251210-095451-INV-202512-0021-dcd9a2ee34c22523.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":1000,\"due\":0}', '1', '2025-12-10 09:54:51', '2025-12-09 23:54:51', '2025-12-09 23:54:51'),
('18', '22', 'INV-202512-0022', 'manager_pos_invoice', 'ce0ef34caae45646', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0022</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">3</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-095621-INV-202512-0022-ce0ef34caae45646.html', 'pos-invoice-20251210-095621-INV-202512-0022-ce0ef34caae45646.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":500,\"due_before_credit\":500,\"credit_used\":0,\"due\":500}', '1', '2025-12-10 09:56:22', '2025-12-09 23:56:21', '2025-12-09 23:56:22'),
('19', '23', 'INV-202512-0023', 'manager_pos_invoice', 'bd36aa4b1c3e6b11', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0023</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">3</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            1,000.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-102510-INV-202512-0023-bd36aa4b1c3e6b11.html', 'pos-invoice-20251210-102510-INV-202512-0023-bd36aa4b1c3e6b11.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":0,\"due_before_credit\":1000,\"credit_used\":0,\"due\":1000}', '1', '2025-12-10 10:25:10', '2025-12-10 00:25:10', '2025-12-10 00:25:10'),
('20', '24', 'INV-202512-0024', 'manager_pos_invoice', 'eeb7ef3e8c51034e', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0024</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">3</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">500.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            500.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-102540-INV-202512-0024-eeb7ef3e8c51034e.html', 'pos-invoice-20251210-102540-INV-202512-0024-eeb7ef3e8c51034e.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":500,\"due_before_credit\":500,\"credit_used\":0,\"due\":500}', '1', '2025-12-10 10:25:40', '2025-12-10 00:25:40', '2025-12-10 00:25:40'),
('21', '25', 'INV-202512-0025', 'sales_pos_invoice', '93bdd79cac64f458', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0025</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">2</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">1,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-103703-INV-202512-0025-93bdd79cac64f458.html', 'pos-invoice-20251210-103703-INV-202512-0025-93bdd79cac64f458.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 10:37:03', '2025-12-10 00:37:03', '2025-12-10 00:37:03'),
('22', '26', 'INV-202512-0026', 'sales_pos_invoice', 'b722b2ce855db27a', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0026</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">5</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: مبيعات1</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">1,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-103858-INV-202512-0026-b722b2ce855db27a.html', 'pos-invoice-20251210-103858-INV-202512-0026-b722b2ce855db27a.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 10:38:58', '2025-12-10 00:38:58', '2025-12-10 00:38:58'),
('23', '27', 'INV-202512-0027', 'sales_pos_invoice', 'b2186cca581020ec', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0027</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-paid\">مدفوعة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: 3</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">1,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-105035-INV-202512-0027-b2186cca581020ec.html', 'pos-invoice-20251210-105035-INV-202512-0027-b2186cca581020ec.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":1000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-10 10:50:35', '2025-12-10 00:50:35', '2025-12-10 00:50:35'),
('24', '28', 'INV-202512-0028', 'sales_pos_invoice', '615ea2cd26f15b52', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0028</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-partial\">مدفوع جزئياً</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: 3</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">500.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            500.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-105118-INV-202512-0028-615ea2cd26f15b52.html', 'pos-invoice-20251210-105118-INV-202512-0028-615ea2cd26f15b52.html', '{\"subtotal\":1000,\"prepaid\":0,\"net_total\":1000,\"paid\":500,\"due_before_credit\":500,\"credit_used\":0,\"due\":500}', '1', '2025-12-10 10:51:18', '2025-12-10 00:51:18', '2025-12-10 00:51:18'),
('25', '29', 'INV-202512-0029', 'manager_pos_invoice', '7a58e538c970d662', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0029</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>10/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">12</div>\n                                    <div class=\"info-item\">هاتف: .02221</div>\n                                                    <div class=\"info-item\">العنوان: 515</div>\n                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون صغير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            500.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            500.00 ج.م                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                صابون كبير                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"color: #9ca3af;\">-</span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            1.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            1,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>1,500.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>1,500.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">150.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-danger\">\n                            1,350.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251210-165704-INV-202512-0029-7a58e538c970d662.html', 'pos-invoice-20251210-165704-INV-202512-0029-7a58e538c970d662.html', '{\"subtotal\":1500,\"prepaid\":0,\"net_total\":1500,\"paid\":150,\"due_before_credit\":1350,\"credit_used\":0,\"due\":1350}', '1', '2025-12-10 16:57:05', '2025-12-10 06:57:04', '2025-12-10 06:57:05'),
('26', '32', 'INV-202512-0032', 'manager_pos_invoice', '99fc6c11b400cb7a', '\n<div class=\"invoice-wrapper\" id=\"invoicePrint\">\n    <div class=\"invoice-card\">\n        <header class=\"invoice-header\">\n            <div class=\"brand-block\">\n                <div class=\"logo-placeholder\">\n                    <img src=\"/v1/assets/icons/icon-192x192.svg\" alt=\"Logo\" class=\"company-logo-img\" onerror=\"this.onerror=null; this.src=\'/v1/assets/icons/icon-192x192.png\'; this.onerror=function(){this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';};\">\n                    <span class=\"logo-letter\" style=\"display:none;\">ش</span>\n                </div>\n                <div>\n                    <h1 class=\"company-name\">شركة البركة</h1>\n                    <div class=\"company-subtitle\">نظام إدارة المبيعات</div>\n                </div>\n            </div>\n            <div class=\"invoice-meta\">\n                <div class=\"invoice-title\">فاتورة مبيعات</div>\n                <div class=\"invoice-number\">رقم الفاتورة<span>INV-202512-0032</span></div>\n                <div class=\"invoice-meta-grid\">\n                    <div class=\"meta-item\">\n                        <span>تاريخ الإصدار</span>\n                        <strong>11/12/2025</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>تاريخ الاستحقاق</span>\n                        <strong>أجل غير مسمى</strong>\n                    </div>\n                    <div class=\"meta-item\">\n                        <span>الحالة</span>\n                        <strong class=\"status-draft\">مسودة</strong>\n                    </div>\n                </div>\n            </div>\n        </header>\n\n        <section class=\"info-grid\">\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات الشركة</div>\n                <div class=\"info-item\">نطاق التوزيع :  الاسكندريه - شحن لجميع انحاء الجمهوريه</div>\n                <div class=\"info-item\">01003533905</div>\n                <div class=\"info-item\">صفحة فيسبوك  : عسل نحل المصطفي</div>\n                <div class=\"info-item\"></div>\n            </div>\n            <div class=\"info-card\">\n                <div class=\"info-title\">بيانات العميل</div>\n                <div class=\"info-item name\">1</div>\n                                                                    <div class=\"info-item rep\">المسؤول عن عملية البيع: المدير العام</div>\n                            </div>\n        </section>\n\n        <section class=\"items-table\">\n            <table>\n                <thead>\n                    <tr>\n                        <th style=\"width: 30%;\">المنتج</th>\n                                                    <th style=\"width: 20%; text-align: center;\">رقم التشغيلة</th>\n                                                <th style=\"width: 12%; text-align: center;\">الكمية</th>\n                        <th style=\"width: 15%; text-align: end;\">سعر الوحدة</th>\n                        <th style=\"width: 15%; text-align: end;\">الإجمالي</th>\n                    </tr>\n                </thead>\n                <tbody>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251211-581612                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            12.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            12,000.00 ج.م                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251211-460851                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            6.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            6,000.00 ج.م                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251211-269689                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            6.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            6,000.00 ج.م                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251211-461225                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            6.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            6,000.00 ج.م                        </td>\n                    </tr>\n                                        <tr>\n                        <td>\n                            <div class=\"product-name\" style=\"font-weight: 600; margin-bottom: 4px;\">\n                                TEST                            </div>\n                                                    </td>\n                                                    <td style=\"text-align: center; vertical-align: middle;\">\n                                                                    <span style=\"font-size: 12px; color: #0f4c81; font-weight: 600; background: #e0f2fe; padding: 4px 8px; border-radius: 6px; display: inline-block;\">\n                                        251210-921358                                    </span>\n                                                            </td>\n                                                <td style=\"text-align: center; vertical-align: middle; font-weight: 600;\">\n                            2.00                        </td>\n                        <td style=\"text-align: end; vertical-align: middle;\">\n                            1,000.00 ج.م                        </td>\n                        <td style=\"text-align: end; vertical-align: middle; font-weight: 600; color: #0f4c81;\">\n                            2,000.00 ج.م                        </td>\n                    </tr>\n                                    </tbody>\n            </table>\n        </section>\n\n        <section class=\"summary-grid\">\n                            <div class=\"summary-card\">\n                    <div class=\"summary-title\">ملخص الفاتورة</div>\n                    <div class=\"summary-row\">\n                        <span>المجموع الفرعي</span>\n                        <strong>32,000.00 ج.م</strong>\n                    </div>\n                                        <div class=\"summary-row total\">\n                        <span>الإجمالي النهائي</span>\n                        <strong>32,000.00 ج.م</strong>\n                    </div>\n                                            <div class=\"summary-row\">\n                            <span>المدفوع</span>\n                            <strong class=\"text-success\">32,000.00 ج.م</strong>\n                        </div>\n                                                            <div class=\"summary-row due\">\n                        <span>المتبقي</span>\n                        <strong class=\"text-success\">\n                            0.00 ج.م                        </strong>\n                    </div>\n                </div>\n                                    <div class=\"summary-card qr-card\">\n                <div class=\"summary-title\">تابعنا على فيسبوك</div>\n                <div class=\"qr-wrapper\">\n                    <img src=\"https://api.qrserver.com/v1/create-qr-code/?size=180x180&amp;data=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1AHxSmFhEp%2F\" alt=\"Facebook QR Code\">\n                </div>\n                <div class=\"qr-note\">امسح الرمز لمتابعة صفحتنا على فيسبوك</div>\n            </div>\n                    </section>\n\n        <footer class=\"invoice-footer\">\n            <div class=\"thanks\">نشكركم على ثقتكم بنا</div>\n            <div class=\"terms\">\n                <div>يرجى التأكد من مطابقة المنتجات عند الاستلام.</div>\n                <div>لأي استفسارات يرجى التواصل على: 01003533905</div>\n            </div>\n        </footer>\n    </div>\n</div>\n\n<style>\n.invoice-wrapper {\n    font-family: \'Tajawal\', \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;\n    color: #1f2937;\n}\n\n.invoice-card {\n    background: #ffffff;\n    border-radius: 24px;\n    border: 1px solid #e2e8f0;\n    padding: 32px;\n    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);\n    position: relative;\n    overflow: hidden;\n}\n\n.invoice-card::before {\n    content: \'\';\n    position: absolute;\n    top: -40%;\n    left: -25%;\n    width: 60%;\n    height: 120%;\n    background: radial-gradient(circle at center, rgba(15, 76, 129, 0.12), transparent 70%);\n    z-index: 0;\n}\n\n.invoice-card > * {\n    position: relative;\n    z-index: 1;\n}\n\n.invoice-header {\n    display: flex;\n    justify-content: space-between;\n    align-items: flex-start;\n    gap: 24px;\n    margin-bottom: 32px;\n}\n\n.brand-block {\n    display: flex;\n    align-items: center;\n    gap: 18px;\n}\n\n.logo-placeholder {\n    width: 74px;\n    height: 74px;\n    border-radius: 20px;\n    background: linear-gradient(135deg, #0f4c81, #0a2d4a);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    color: #fff;\n    font-size: 30px;\n    font-weight: 700;\n    box-shadow: 0 12px 24px rgba(15, 76, 129, 0.25);\n    overflow: hidden;\n    position: relative;\n}\n\n.company-logo-img {\n    width: 100%;\n    height: 100%;\n    object-fit: contain;\n    padding: 8px;\n}\n\n.logo-letter {\n    transform: translateY(2px);\n}\n\n.company-name {\n    font-size: 28px;\n    font-weight: 700;\n    margin: 0;\n    color: #0f172a;\n}\n\n.company-subtitle {\n    font-size: 14px;\n    color: #475569;\n    margin-top: 6px;\n}\n\n.invoice-meta {\n    text-align: left;\n}\n\n.invoice-title {\n    font-size: 20px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-number {\n    font-size: 14px;\n    color: #64748b;\n    margin-bottom: 10px;\n}\n\n.invoice-number span {\n    display: block;\n    font-size: 20px;\n    font-weight: 700;\n    color: #0f172a;\n}\n\n.invoice-meta-grid {\n    display: grid;\n    grid-template-columns: repeat(3, minmax(160px, 1fr));\n    gap: 12px;\n}\n\n.meta-item {\n    background: #f8fafc;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n    border-radius: 12px;\n    padding: 12px 16px;\n}\n\n.meta-item span {\n    display: block;\n    font-size: 12px;\n    color: #64748b;\n    margin-bottom: 6px;\n}\n\n.meta-item strong {\n    font-size: 15px;\n    color: #0f172a;\n}\n\n.status-draft { color: #eab308; }\n.status-approved { color: #10b981; }\n.status-paid { color: #059669; }\n.status-partial { color: #f97316; }\n.status-cancelled { color: #ef4444; }\n\n.info-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin-bottom: 24px;\n}\n\n.info-card {\n    background: #f9fafb;\n    border: 1px solid #e2e8f0;\n    border-radius: 16px;\n    padding: 18px 22px;\n}\n\n.info-title {\n    font-size: 15px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 12px;\n}\n\n.info-item {\n    font-size: 14px;\n    color: #475569;\n    margin-bottom: 6px;\n    line-height: 1.6;\n}\n\n.info-item.name {\n    font-weight: 600;\n    color: #0f172a;\n}\n\n.info-item.rep {\n    margin-top: 10px;\n    color: #1d4ed8;\n}\n\n.items-table table {\n    width: 100%;\n    border-collapse: collapse;\n    border-radius: 18px;\n    overflow: hidden;\n    border: 1px solid rgba(15, 76, 129, 0.12);\n}\n\n.items-table thead {\n    background: linear-gradient(135deg, rgba(15, 76, 129, 0.1), rgba(15, 76, 129, 0.05));\n}\n\n.items-table th {\n    padding: 14px 12px;\n    font-size: 13px;\n    color: #0f4c81;\n    text-align: right;\n    border-bottom: 1px solid rgba(15, 76, 129, 0.12);\n    font-weight: 600;\n}\n\n.items-table th:first-child {\n    text-align: right;\n}\n\n.items-table td {\n    padding: 16px 12px;\n    font-size: 14px;\n    color: #1f2937;\n    border-bottom: 1px solid rgba(148, 163, 184, 0.25);\n    text-align: right;\n    vertical-align: middle;\n}\n\n.items-table tbody tr:last-child td {\n    border-bottom: none;\n}\n\n.items-table tbody tr:hover {\n    background-color: rgba(15, 76, 129, 0.02);\n}\n\n.items-table .product-name {\n    font-weight: 600;\n    margin-bottom: 6px;\n    color: #0f172a;\n}\n\n.items-table .product-unit {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.items-table .muted {\n    color: #9ca3af;\n    font-size: 13px;\n}\n\n.summary-grid {\n    display: grid;\n    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n    gap: 18px;\n    margin: 28px 0;\n}\n\n.summary-card {\n    background: #f8fafc;\n    border-radius: 18px;\n    border: 1px solid rgba(15, 76, 129, 0.1);\n    padding: 20px 22px;\n    min-height: 220px;\n    display: flex;\n    flex-direction: column;\n    gap: 12px;\n}\n\n.summary-card.qr-card {\n    align-items: center;\n    text-align: center;\n}\n\n.summary-title {\n    font-size: 15px;\n    font-weight: 700;\n    color: #0f4c81;\n}\n\n.summary-row {\n    display: flex;\n    justify-content: space-between;\n    font-size: 14px;\n    color: #1f2937;\n    gap: 12px;\n}\n\n.summary-row strong {\n    font-size: 15px;\n}\n\n.summary-row.total {\n    border-top: 1px dashed rgba(15, 76, 129, 0.2);\n    padding-top: 10px;\n    margin-top: 6px;\n}\n\n.summary-row.due {\n    font-weight: 600;\n}\n\n.text-success { color: #16a34a !important; }\n.text-danger { color: #dc2626 !important; }\n\n.qr-wrapper {\n    background: #fff;\n    padding: 12px;\n    border-radius: 16px;\n    border: 1px solid rgba(15, 76, 129, 0.15);\n    box-shadow: inset 0 2px 12px rgba(15, 23, 42, 0.05);\n}\n\n.qr-wrapper img {\n    width: 150px;\n    height: 150px;\n    display: block;\n}\n\n.qr-note {\n    font-size: 12px;\n    color: #64748b;\n}\n\n.notes-card .notes-content {\n    font-size: 13px;\n    color: #475569;\n    line-height: 1.8;\n    background: rgba(15, 76, 129, 0.05);\n    padding: 12px;\n    border-radius: 12px;\n    border: 1px solid rgba(15, 76, 129, 0.08);\n}\n\n.invoice-footer {\n    text-align: center;\n    padding-top: 18px;\n    border-top: 1px dashed rgba(148, 163, 184, 0.5);\n}\n\n.invoice-footer .thanks {\n    font-size: 16px;\n    font-weight: 600;\n    color: #0f4c81;\n    margin-bottom: 6px;\n}\n\n.invoice-footer .terms {\n    font-size: 12px;\n    color: #64748b;\n    line-height: 1.6;\n}\n\n@media print {\n    body {\n        background: #ffffff;\n        margin: 0;\n    }\n\n    .invoice-card {\n        box-shadow: none;\n        border: none;\n        padding: 24px;\n        border-radius: 0;\n    }\n\n    .invoice-card::before {\n        display: none;\n    }\n\n    .btn, .no-print, .card-header, .sidebar, .navbar {\n        display: none !important;\n    }\n\n    .invoice-wrapper {\n        margin: 0;\n    }\n}\n\n@media (max-width: 768px) {\n    .invoice-card {\n        padding: 24px 18px;\n        border-radius: 18px;\n    }\n\n    .invoice-header {\n        flex-direction: column;\n        align-items: flex-start;\n    }\n\n    .invoice-meta-grid {\n        grid-template-columns: repeat(2, minmax(140px, 1fr));\n    }\n\n    .info-grid, .summary-grid {\n        grid-template-columns: 1fr;\n    }\n}\n</style>\n', 'exports/sales-pos/pos-invoice-20251211-123747-INV-202512-0032-99fc6c11b400cb7a.html', 'pos-invoice-20251211-123747-INV-202512-0032-99fc6c11b400cb7a.html', '{\"subtotal\":32000,\"prepaid\":0,\"net_total\":32000,\"paid\":32000,\"due_before_credit\":0,\"credit_used\":0,\"due\":0}', '1', '2025-12-11 12:37:47', '2025-12-11 02:37:47', '2025-12-11 02:37:47');
/*!40000 ALTER TABLE `telegram_invoices` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `unified_product_templates`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `unified_product_templates`;
CREATE TABLE `unified_product_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL COMMENT 'اسم المنتج',
  `created_by` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `main_supplier_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `form_payload` longtext DEFAULT NULL COMMENT 'JSON يحتوي جميع مدخلات النموذج',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `status` (`status`),
  KEY `main_supplier_id` (`main_supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `unified_product_templates`

-- --------------------------------------------------------
-- Table structure for table `user_permissions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `granted` tinyint(1) DEFAULT 1,
  `granted_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission` (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  KEY `granted_by` (`granted_by`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_3` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Empty table `user_permissions`

-- --------------------------------------------------------
-- Table structure for table `user_status`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `user_status`;
CREATE TABLE `user_status` (
  `user_id` int(11) NOT NULL,
  `last_seen` datetime NOT NULL DEFAULT current_timestamp(),
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_status_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `user_status` WRITE;
/*!40000 ALTER TABLE `user_status` DISABLE KEYS */;
INSERT INTO `user_status` (`user_id`, `last_seen`, `is_online`) VALUES
('1', '2025-12-15 18:02:05', '0'),
('2', '2025-12-11 18:17:15', '0'),
('4', '2025-12-15 17:53:58', '0'),
('16', '2025-12-11 17:23:24', '0'),
('19', '2025-12-10 13:24:56', '0');
/*!40000 ALTER TABLE `user_status` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` enum('accountant','sales','production','manager') NOT NULL,
  `webauthn_enabled` tinyint(1) DEFAULT 0,
  `full_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_photo` longtext DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `warning_count` int(11) DEFAULT 0,
  `delay_count` int(11) DEFAULT 0,
  `can_check_in` tinyint(1) DEFAULT 1,
  `can_check_out` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `webauthn_enabled`, `full_name`, `phone`, `profile_photo`, `hourly_rate`, `status`, `warning_count`, `delay_count`, `can_check_in`, `can_check_out`, `created_at`, `updated_at`) VALUES
('1', 'admin', 'admin@company.com', '$2y$10$cIXyIRjYeF.YHoKQfUIgluq8mWJ.qNlvr7iz0c1QcWbRrdI0yqNHS', 'manager', '1', 'المدير العام', '01000000004', NULL, '0.00', 'active', '0', '0', '1', '1', '2025-11-03 22:14:12', '2025-12-12 12:22:12'),
('2', 'a', 'accountant@company.com', '$2y$10$uX9v.mRKgvVCXWEDfnPwHebLdTviE/T6xUChWUBYtyruZ5GwtIKN2', 'accountant', '1', 'Mohamed elsyed', '01271292854', NULL, '25.00', 'active', '0', '1', '1', '1', '2025-11-03 22:14:12', '2025-12-11 05:40:38'),
('4', 'p', 'production@company.com', '$2y$10$91kPMaWrc859vTduCzBvNeoTwDRhn5G.MW0Xkt03EfPxI0btk7zaS', 'production', '1', 'عامل الإنتاج الأول', '01000000001', NULL, '20.00', 'active', '0', '2', '1', '1', '2025-11-03 22:14:12', '2025-12-14 15:23:50'),
('10', 's', 'sales@company.com', '$2y$10$oojc53FoNZfmCpvKJhtAZeAq1UFuz.2k1APHRdVFNM0tLl/gpmhMm', 'sales', '1', 'مبيعات1', '0111111111110', NULL, '15.00', 'active', '0', '1', '1', '1', '2025-12-07 14:33:52', '2025-12-10 06:16:43'),
('11', 'p2', '', '$2y$10$msOY2/N2Kfer9aJosIjf7Oavn.pEfFzHC5ts7/pM6XAlz1h2LSCV.', 'production', '0', 'انتاج 2', '', NULL, '20.00', 'active', '0', '2', '1', '1', '2025-12-08 23:07:24', '2025-12-11 07:17:04'),
('16', 'p3', 'p3@6937cd7a55bc2.local', '$2y$10$nDHhEc75dYg49t7.kusc0erEO4NLmDD.gn5yPUEDikM4.xK68.nHS', 'production', '0', 'انتاج 3', '', NULL, '20.00', 'active', '0', '1', '1', '1', '2025-12-08 23:19:22', '2025-12-11 07:23:01'),
('17', 's2', 's2@6937cda446073.local', '$2y$10$lMSgJCwVUB1ABICX4oNHP.ss1VA4bC6Q6sajj.q0yL2deyuDxC7gO', 'sales', '0', 'مبيعات 2', '', NULL, '15.00', 'active', '0', '0', '1', '1', '2025-12-08 23:20:04', NULL),
('18', 's3', 's3@6939328902b15.local', '$2y$10$eTRAnNTD00OqbRBtHCWJE.gjdkBSON/yYAmFwp/.0biIGftPLYsXi', 'sales', '0', '3', '', NULL, '15.00', 'active', '0', '0', '1', '1', '2025-12-10 00:42:49', NULL),
('19', 'p4', 'p4@693945b7a1043.local', '$2y$10$iCn2K9I8qZMrDs715vYJVOpbcgKcURaZR.jnr4KawrDjrjQj6v/h6', 'production', '0', 'عبدالله صالح', '', NULL, '20.00', 'active', '0', '0', '1', '1', '2025-12-10 02:04:39', NULL),
('20', 's5', 's5@69398824c8bff.local', '$2y$10$uLGm9AXskJsKy.uhAqvdnusoIdgWEIDMvEmAXDpkdlWLQCfeWSaB6', 'sales', '0', '', '', NULL, '15.00', 'active', '0', '0', '1', '1', '2025-12-10 06:48:04', NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `vehicle_inventory`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `vehicle_inventory`;
CREATE TABLE `vehicle_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` int(11) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_category` varchar(100) DEFAULT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `product_unit_price` decimal(15,2) DEFAULT NULL,
  `manager_unit_price` decimal(15,2) DEFAULT NULL,
  `finished_batch_id` int(11) DEFAULT NULL,
  `finished_batch_number` varchar(100) DEFAULT NULL,
  `finished_production_date` date DEFAULT NULL,
  `finished_quantity_produced` decimal(12,2) DEFAULT NULL,
  `finished_workers` text DEFAULT NULL,
  `product_snapshot` longtext DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated_by` int(11) DEFAULT NULL,
  `last_updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_product_batch_unique` (`vehicle_id`,`product_id`,`finished_batch_id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `vehicle_inventory_ibfk_4` (`last_updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `vehicle_inventory` WRITE;
/*!40000 ALTER TABLE `vehicle_inventory` DISABLE KEYS */;
INSERT INTO `vehicle_inventory` (`id`, `vehicle_id`, `warehouse_id`, `product_id`, `product_name`, `product_category`, `product_unit`, `product_unit_price`, `manager_unit_price`, `finished_batch_id`, `finished_batch_number`, `finished_production_date`, `finished_quantity_produced`, `finished_workers`, `product_snapshot`, `quantity`, `last_updated_by`, `last_updated_at`, `created_at`) VALUES
('1', '1', '2', '3', '1', 'finished', 'قطعة', '0.00', '0.00', '1', '251210-990828', '2025-12-10', '50.00', NULL, '{\"id\":3,\"name\":\"1\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"20.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-10 05:35:03\",\"updated_at\":\"2025-12-10 05:48:20\"}', '0.00', '1', '2025-12-09 19:57:37', '2025-12-09 19:39:46'),
('2', '1', '2', '4', 'TEST', 'finished', 'قطعة', '1000.00', '1000.00', '2', '251210-921358', '2025-12-10', '1.00', NULL, '{\"id\":4,\"name\":\"TEST\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"1000.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"9.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-10 05:56:25\",\"updated_at\":\"2025-12-10 09:43:27\"}', '11.00', '18', '2025-12-10 00:50:34', '2025-12-09 19:58:19'),
('3', '1', '2', '7', 'صابون كبير', 'منتجات خارجية', 'قطعة', '1000.00', '1000.00', NULL, NULL, NULL, NULL, NULL, '{\"id\":7,\"name\":\"صابون كبير\",\"category\":\"منتجات خارجية\",\"unit\":\"قطعة\",\"unit_price\":\"1000.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"97.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-10 06:57:06\",\"updated_at\":\"2025-12-10 10:26:07\"}', '14.00', '18', '2025-12-10 00:51:18', '2025-12-09 20:57:39'),
('4', '2', '3', '3', '1', 'finished', 'قطعة', '0.00', '0.00', '1', '251210-990828', '2025-12-10', '55.00', NULL, '{\"id\":3,\"name\":\"1\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"0.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"40.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-10 05:35:03\",\"updated_at\":\"2025-12-10 05:57:37\"}', '10.00', '1', '2025-12-10 06:54:24', '2025-12-10 06:51:28'),
('5', '2', '3', '20', 'عسل ك سنبله', 'finished', 'قطعة', '150.00', '150.00', '15', '251211-923972', '2025-12-11', '18.00', NULL, '{\"id\":20,\"name\":\"عسل ك سنبله\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"150.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-11 17:55:29\",\"updated_at\":\"2025-12-11 17:55:33\"}', '10.00', '1', '2025-12-11 08:22:49', '2025-12-11 08:22:49'),
('6', '2', '3', '30', 'ك', 'finished', 'قطعة', '100.00', '100.00', '19', '251215-082617', '2025-12-15', '0.00', NULL, '{\"id\":30,\"name\":\"ك\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"100.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-14 15:47:16\",\"updated_at\":\"2025-12-14 15:51:39\"}', '0.00', '1', '2025-12-15 02:51:20', '2025-12-15 02:49:33'),
('7', '1', '2', '30', 'ك', 'finished', 'قطعة', '100.00', '100.00', '19', '251215-082617', '2025-12-15', '6.00', NULL, '{\"id\":30,\"name\":\"ك\",\"category\":\"finished\",\"unit\":\"قطعة\",\"unit_price\":\"100.00\",\"description\":null,\"status\":\"active\",\"quantity\":\"0.00\",\"min_stock\":\"0.00\",\"created_at\":\"2025-12-14 15:47:16\",\"updated_at\":\"2025-12-14 15:51:39\"}', '6.00', '1', '2025-12-15 03:38:53', '2025-12-15 03:38:53');
/*!40000 ALTER TABLE `vehicle_inventory` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `vehicles`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `vehicles`;
CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_number` varchar(50) NOT NULL,
  `vehicle_type` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL COMMENT 'مندوب المبيعات صاحب السيارة',
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `vehicle_number` (`vehicle_number`),
  KEY `driver_id` (`driver_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `vehicles_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` (`id`, `vehicle_number`, `vehicle_type`, `model`, `year`, `driver_id`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
('1', '1000', '1000', '1000', '2025', '18', 'active', '', '1', '2025-12-09 19:39:13', '2025-12-10 00:43:05'),
('2', '2145 س ل م', 'تويوتا', '1', '2025', '10', 'active', '', '1', '2025-12-10 02:08:29', NULL),
('3', '526', '', '', NULL, NULL, 'active', '', '1', '2025-12-15 02:06:06', NULL);
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `warehouse_transfer_items`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `warehouse_transfer_items`;
CREATE TABLE `warehouse_transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`),
  KEY `batch_id` (`batch_id`),
  KEY `batch_number` (`batch_number`),
  CONSTRAINT `warehouse_transfer_items_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `warehouse_transfers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfer_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `warehouse_transfer_items` WRITE;
/*!40000 ALTER TABLE `warehouse_transfer_items` DISABLE KEYS */;
INSERT INTO `warehouse_transfer_items` (`id`, `transfer_id`, `product_id`, `batch_id`, `batch_number`, `quantity`, `notes`, `created_at`) VALUES
('1', '1', '3', '1', '251210-990828', '40.00', NULL, '2025-12-09 19:39:35'),
('2', '2', '3', '1', '251210-990828', '10.00', NULL, '2025-12-09 19:40:45'),
('3', '3', '3', '1', '251210-990828', '10.00', NULL, '2025-12-09 19:48:20'),
('4', '4', '3', '1', '251210-990828', '20.00', NULL, '2025-12-09 19:57:37'),
('5', '5', '4', '2', '251210-921358', '10.00', NULL, '2025-12-09 19:58:19'),
('6', '6', '4', '2', '251210-921358', '5.00', NULL, '2025-12-09 19:58:32'),
('7', '7', '4', '2', '251210-921358', '15.00', NULL, '2025-12-09 19:58:49'),
('8', '8', '7', NULL, NULL, '50.00', NULL, '2025-12-09 20:57:39'),
('9', '9', '7', NULL, NULL, '10.00', NULL, '2025-12-09 20:57:56'),
('10', '10', '7', NULL, NULL, '10.00', NULL, '2025-12-09 21:06:17'),
('11', '11', '7', NULL, NULL, '10.00', NULL, '2025-12-09 21:07:36'),
('12', '12', '4', '2', '251210-921358', '1.00', NULL, '2025-12-09 21:09:14'),
('13', '13', '4', '2', '251210-921358', '1.00', NULL, '2025-12-09 21:09:31'),
('14', '14', '7', NULL, NULL, '10.00', NULL, '2025-12-09 21:16:41'),
('15', '15', '7', NULL, NULL, '120.00', NULL, '2025-12-09 21:16:55'),
('16', '16', '7', NULL, NULL, '110.00', NULL, '2025-12-09 21:17:14'),
('17', '17', '3', '1', '251210-990828', '35.00', NULL, '2025-12-10 06:51:28'),
('18', '18', '3', '1', '251210-990828', '20.00', NULL, '2025-12-10 06:52:32'),
('19', '19', '3', '1', '251210-990828', '5.00', NULL, '2025-12-10 06:54:24'),
('20', '20', '20', '15', '251211-923972', '10.00', NULL, '2025-12-11 08:22:14'),
('21', '21', '30', '19', '251215-082617', '6.00', NULL, '2025-12-15 02:49:12'),
('22', '22', '30', '19', '251215-082617', '6.00', NULL, '2025-12-15 02:51:20'),
('23', '23', '30', '19', '251215-082617', '6.00', NULL, '2025-12-15 03:00:30');
/*!40000 ALTER TABLE `warehouse_transfer_items` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `warehouse_transfers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `warehouse_transfers`;
CREATE TABLE `warehouse_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_number` varchar(50) NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `transfer_date` date NOT NULL,
  `transfer_type` enum('to_vehicle','from_vehicle','between_warehouses') DEFAULT 'to_vehicle',
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','completed','cancelled') DEFAULT 'pending',
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfer_number` (`transfer_number`),
  KEY `from_warehouse_id` (`from_warehouse_id`),
  KEY `to_warehouse_id` (`to_warehouse_id`),
  KEY `transfer_date` (`transfer_date`),
  KEY `status` (`status`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `warehouse_transfers_ibfk_1` FOREIGN KEY (`from_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_2` FOREIGN KEY (`to_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_3` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `warehouse_transfers_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `warehouse_transfers` WRITE;
/*!40000 ALTER TABLE `warehouse_transfers` DISABLE KEYS */;
INSERT INTO `warehouse_transfers` (`id`, `transfer_number`, `from_warehouse_id`, `to_warehouse_id`, `transfer_date`, `transfer_type`, `reason`, `status`, `requested_by`, `approved_by`, `approved_at`, `rejection_reason`, `notes`, `created_at`, `updated_at`) VALUES
('1', 'TRF-202512-0001', '1', '2', '2025-12-10', 'to_vehicle', NULL, 'completed', '4', '1', '2025-12-09 19:39:46', NULL, NULL, '2025-12-09 19:39:35', '2025-12-09 19:39:46'),
('2', 'TRF-202512-0002', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 19:40:45', NULL, '', '2025-12-09 19:40:45', '2025-12-09 19:40:45'),
('3', 'TRF-202512-0003', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 19:48:20', NULL, '', '2025-12-09 19:48:20', '2025-12-09 19:48:20'),
('4', 'TRF-202512-0004', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 19:57:37', NULL, '', '2025-12-09 19:57:37', '2025-12-09 19:57:37'),
('5', 'TRF-202512-0005', '1', '2', '2025-12-10', 'to_vehicle', 'نقل منتجات من مخزن الشركة إلى مخزن السيارة', 'completed', '1', '1', '2025-12-09 19:58:19', NULL, '', '2025-12-09 19:58:19', '2025-12-09 19:58:19'),
('6', 'TRF-202512-0006', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 19:58:32', NULL, '', '2025-12-09 19:58:32', '2025-12-09 19:58:32'),
('7', 'TRF-202512-0007', '1', '2', '2025-12-10', 'to_vehicle', 'نقل منتجات من مخزن الشركة إلى مخزن السيارة', 'completed', '1', '1', '2025-12-09 19:58:49', NULL, '', '2025-12-09 19:58:49', '2025-12-09 19:58:49'),
('8', 'TRF-202512-0008', '1', '2', '2025-12-10', 'to_vehicle', 'نقل منتجات من مخزن الشركة إلى مخزن السيارة', 'completed', '1', '1', '2025-12-09 20:57:39', NULL, '', '2025-12-09 20:57:39', '2025-12-09 20:57:39'),
('9', 'TRF-202512-0009', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 20:57:56', NULL, '', '2025-12-09 20:57:56', '2025-12-09 20:57:56'),
('10', 'TRF-202512-0010', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 21:06:17', NULL, '', '2025-12-09 21:06:17', '2025-12-09 21:06:17'),
('11', 'TRF-202512-0011', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 21:07:36', NULL, '', '2025-12-09 21:07:36', '2025-12-09 21:07:36'),
('12', 'TRF-202512-0012', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 21:09:14', NULL, '', '2025-12-09 21:09:14', '2025-12-09 21:09:14'),
('13', 'TRF-202512-0013', '1', '2', '2025-12-10', 'to_vehicle', 'نقل منتجات من مخزن الشركة إلى مخزن السيارة', 'completed', '1', '1', '2025-12-09 21:09:31', NULL, '', '2025-12-09 21:09:31', '2025-12-09 21:09:31'),
('14', 'TRF-202512-0014', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 21:16:41', NULL, '', '2025-12-09 21:16:41', '2025-12-09 21:16:41'),
('15', 'TRF-202512-0015', '1', '2', '2025-12-10', 'to_vehicle', 'نقل منتجات من مخزن الشركة إلى مخزن السيارة', 'completed', '1', '1', '2025-12-09 21:16:55', NULL, '', '2025-12-09 21:16:55', '2025-12-09 21:16:55'),
('16', 'TRF-202512-0016', '2', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات 2) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-09 21:17:14', NULL, '', '2025-12-09 21:17:14', '2025-12-09 21:17:14'),
('17', 'TRF-202512-0017', '1', '3', '2025-12-10', 'to_vehicle', 'نقل منتجات من مخزن الشركة إلى مخزن السيارة', 'completed', '1', '1', '2025-12-10 06:51:28', NULL, '', '2025-12-10 06:51:28', '2025-12-10 06:51:28'),
('18', 'TRF-202512-0018', '3', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات1) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-10 06:52:32', NULL, '', '2025-12-10 06:52:32', '2025-12-10 06:52:32'),
('19', 'TRF-202512-0019', '3', '1', '2025-12-10', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات1) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-10 06:54:24', NULL, '', '2025-12-10 06:54:24', '2025-12-10 06:54:24'),
('20', 'TRF-202512-0020', '1', '3', '2025-12-11', 'to_vehicle', NULL, 'completed', '4', '1', '2025-12-11 08:22:49', NULL, NULL, '2025-12-11 08:22:14', '2025-12-11 08:22:49'),
('21', 'TRF-202512-0021', '1', '3', '2025-12-15', 'to_vehicle', NULL, 'completed', '4', '1', '2025-12-15 02:49:33', NULL, NULL, '2025-12-15 02:49:12', '2025-12-15 02:49:33'),
('22', 'TRF-202512-0022', '3', '1', '2025-12-15', 'from_vehicle', 'نقل منتجات من بضاعة المندوب (مبيعات1) إلى المخزن الرئيسي', 'completed', '1', '1', '2025-12-15 02:51:20', NULL, '', '2025-12-15 02:51:20', '2025-12-15 02:51:20'),
('23', 'TRF-202512-0023', '1', '2', '2025-12-15', 'to_vehicle', NULL, 'completed', '4', '1', '2025-12-15 03:38:53', NULL, NULL, '2025-12-15 03:00:29', '2025-12-15 03:38:53');
/*!40000 ALTER TABLE `warehouse_transfers` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `warehouses`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `warehouses`;
CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `warehouse_type` enum('main','vehicle') DEFAULT 'main',
  `vehicle_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `warehouse_type` (`warehouse_type`),
  KEY `vehicle_id` (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` (`id`, `name`, `location`, `description`, `warehouse_type`, `vehicle_id`, `status`, `created_at`, `updated_at`) VALUES
('1', 'المخزن الرئيسي', 'الموقع الرئيسي للشركة', 'تم إنشاء هذا المخزن تلقائياً لطلبات الشحن', 'main', NULL, 'active', '2025-12-08 17:30:10', NULL),
('2', 'مخزن سيارة 1000', 'سيارة', NULL, 'vehicle', '1', 'active', '2025-12-09 19:39:13', NULL),
('3', 'مخزن سيارة 2145 س ل م', 'سيارة', NULL, 'vehicle', '2', 'active', '2025-12-10 02:08:29', NULL),
('4', 'مخزن سيارة 526', 'سيارة', NULL, 'vehicle', '3', 'active', '2025-12-15 02:06:06', NULL);
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

-- --------------------------------------------------------
-- Table structure for table `webauthn_credentials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `webauthn_credentials`;
CREATE TABLE `webauthn_credentials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `credential_id` varchar(255) NOT NULL,
  `public_key` text NOT NULL,
  `counter` bigint(20) DEFAULT 0,
  `device_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_used` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_id` (`credential_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `webauthn_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `webauthn_credentials` WRITE;
/*!40000 ALTER TABLE `webauthn_credentials` DISABLE KEYS */;
INSERT INTO `webauthn_credentials` (`id`, `user_id`, `credential_id`, `public_key`, `counter`, `device_name`, `created_at`, `last_used`) VALUES
('1', '10', 'j2ZPuKN6nVAmX6dSZT55nD7cF5A=', 'pQECAyYgASFYIDkerU/Y39i3ls1fIwuVjU0WBhyHmyvuIzIVUUip7537IlgghAKyJlWnP2X8HHSspyRmyIABvtZcbUeriQwkoF+Zthw=', '0', 'iPhone', '2025-12-08 17:41:06', NULL),
('2', '4', 'EUChYQ8tCP+LPXqG7TSak95PfP0=', 'pQECAyYgASFYIFXj0evG0s7k8pwiwAOpk9+2Q8zQx0wLddKRIqZr0oSXIlggmhpKgvxffuNjPBoiarIqrBJce/GpswKo66O/iUc0H18=', '1', 'iPhone', '2025-12-08 17:44:59', '2025-12-08 17:57:28'),
('4', '2', 'l8whcT1Dssc1RZCwuKdf0X3mp5o=', 'pQECAyYgASFYIHJwb7klZBGmbmtnmQdbV68hWzBr5c+xc9DhBrOOKrwkIlggw+Jj14CP92d0VuAqfKD9BJtfi4amii7bAVnVOgurXmE=', '1', 'iPhone', '2025-12-11 05:40:38', '2025-12-11 05:41:33'),
('6', '1', 'B6iSyA82r8ybxQ07iIb3DL4c4OM=', 'pQECAyYgASFYIMq1+bDu7qMc7KX8e8i2jP34xLVPLh2NNYf/5biYxyLKIlggC1ORfmHqfkHaS9u7aaJyfkj2bR4j5Ug4gu0Xh4YcMsA=', '1', 'Mac', '2025-12-12 12:22:12', '2025-12-12 12:22:22');
/*!40000 ALTER TABLE `webauthn_credentials` ENABLE KEYS */;
UNLOCK TABLES;

SET FOREIGN_KEY_CHECKS=1;
